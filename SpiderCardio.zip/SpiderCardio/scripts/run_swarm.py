"""Spider-Swarm feature selection + hyperparameter adaptation (Section 3.3, Table 3).
Also runs the comparator meta-heuristics with the identical budget (Section 4.1).

    python scripts/run_swarm.py                              # Spider-Swarm
    python scripts/run_swarm.py --optimizers pso ga gwo aco  # comparators
"""
import logging
from pathlib import Path

import numpy as np
import pandas as pd
from _cli import config, parser

from spidercardio.optim import SearchSpace, SpiderCardioFitness, XGBSurrogateFitness, feature_relevance, get_optimizer
from spidercardio.pipeline import prepare, save_json, setup

log = logging.getLogger("swarm")

MANUSCRIPT_HYPER = {"lr": 3e-4, "capsule_dim": 16, "gru_hidden": 128, "dropout": 0.35,
                    "routing_iterations": 3, "batch_size": 64, "optimizer": "adamw"}


def main():
    p = parser(__doc__)
    p.add_argument("--optimizers", nargs="*", default=None)
    a = p.parse_args()
    cfg = config(a)
    out = setup(cfg, "swarm")
    prep = prepare(cfg)
    names = prep.feature_names
    rel = feature_relevance(prep.train_raw.last, prep.train_raw.y.astype(float), names)       # Eq. (12)
    pd.Series(rel).sort_values(key=abs, ascending=False).to_csv(out / "feature_relevance_eq12.csv")
    sc = cfg["swarm"]
    space = SearchSpace(names, min_features=sc.get("min_features", 5))
    fc = sc["fitness"]
    if fc["model"] == "xgboost":
        fitness = XGBSurrogateFitness(prep.train, prep.val, fc.get("weights"), cfg["seed"])
    else:
        fitness = SpiderCardioFitness(prep.train, prep.val, names, cfg["model"], cfg["train"], fc.get("weights"),
                                      fc.get("epochs", 5), fc.get("subsample", 0.3), rel, cfg["seed"],
                                      cfg["train"].get("device", "auto"))
    init_theta = space.encode(MANUSCRIPT_HYPER) if sc.get("seed_with_manuscript_config", True) else None
    for opt_name in a.optimizers or [sc["optimizer"]]:
        Opt = get_optimizer(opt_name)
        kw = dict(n_agents=sc["n_agents"], n_iter=sc["n_iter"], seed=cfg["seed"],
                  convergence_patience=sc.get("convergence_patience"), init_theta=init_theta)
        if opt_name == "spider_swarm":
            kw.update(sc.get("spider", {}))
        opt = Opt(space, fitness, **kw)
        res = opt.run()
        res.history.to_csv(out / f"{opt_name}_history.csv", index=False)
        h = res.history
        t3 = h[h["iteration"] % 10 == 0][["iteration", "selected_features", "best_fitness", "convergence_rate"]]
        t3.to_csv(out / f"table3_{opt_name}.csv", index=False)
        save_json({"optimizer": opt_name, "best_fitness": res.best_fitness, "best_hyper": res.best_hyper,
                   "selected_features": res.selected_features, "n_selected": len(res.selected_features),
                   "best_mask": res.best_mask, "n_evaluations": res.n_evaluations, "wall_time_s": res.wall_time_s,
                   "relevance": rel, **res.extra}, out / f"{opt_name}.json")
        log.info("%s: fitness %.4f, %d features, %d evaluations, %.1f s", opt_name, res.best_fitness,
                 len(res.selected_features), res.n_evaluations, res.wall_time_s)


if __name__ == "__main__":
    main()
