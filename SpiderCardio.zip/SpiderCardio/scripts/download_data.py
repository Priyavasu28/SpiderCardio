"""Download the open datasets (UCI Heart Disease, PTB-XL). MIMIC-IV must be fetched manually.

    python scripts/download_data.py --uci --ptbxl
"""
import subprocess
import urllib.request
from pathlib import Path

from _cli import config, parser

from spidercardio.data.sources.uci import UCI_BASE_URL, UCI_FILES

PTBXL_URL = "https://physionet.org/static/published-projects/ptb-xl/ptb-xl-a-large-publicly-available-electrocardiography-dataset-1.0.3.zip"


def main():
    p = parser(__doc__)
    p.add_argument("--uci", action="store_true")
    p.add_argument("--ptbxl", action="store_true")
    a = p.parse_args()
    cfg = config(a)
    if a.uci:
        d = Path(cfg["paths"]["uci_dir"])
        d.mkdir(parents=True, exist_ok=True)
        for f in UCI_FILES.values():
            print("downloading", f)
            urllib.request.urlretrieve(UCI_BASE_URL + f, d / f)
    if a.ptbxl:
        d = Path(cfg["paths"]["ptbxl_dir"]).parent
        d.mkdir(parents=True, exist_ok=True)
        z = d / "ptbxl.zip"
        print("downloading PTB-XL (~1.7 GB) ...")
        urllib.request.urlretrieve(PTBXL_URL, z)
        subprocess.run(["unzip", "-q", "-o", str(z), "-d", str(d)], check=True)
        print("unzipped; move/rename the extracted folder to", cfg["paths"]["ptbxl_dir"])
    print("MIMIC-IV: requires PhysioNet credentialing ->  wget -r -N -c -np --user <you> --ask-password "
          "https://physionet.org/files/mimiciv/2.2/  (place under", cfg["paths"]["mimic_dir"], ")")


if __name__ == "__main__":
    main()
