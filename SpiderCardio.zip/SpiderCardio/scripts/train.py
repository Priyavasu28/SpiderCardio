"""Train and evaluate one model on the held-out test partition (Table 8 row, Section 4).

    python scripts/train.py --model spidercardio      # uses results/swarm/spider_swarm.json if present
    python scripts/train.py --model xgboost
    python scripts/train.py --model spidercardio --no-swarm   # manuscript defaults, all 42 features
"""
import logging

import numpy as np
import pandas as pd
from _cli import config, parser

from spidercardio.evaluation.diagnostics import progression_sensitivity
from spidercardio.experiment import relevance_for, run_model, save_model
from spidercardio.pipeline import apply_selection, load_swarm, model_and_train_cfg, prepare, save_json, setup

log = logging.getLogger("train")


def main():
    p = parser(__doc__)
    p.add_argument("--model", default="spidercardio")
    p.add_argument("--no-swarm", action="store_true")
    p.add_argument("--tag", default=None)
    a = p.parse_args()
    cfg = config(a)
    out = setup(cfg, f"train/{a.tag or a.model}")
    prep = prepare(cfg)
    swarm = None if a.no_swarm else load_swarm(cfg)
    if swarm and cfg["swarm"].get("use_selected_features", True) and a.model == "spidercardio":
        prep = apply_selection(prep, swarm["selected_features"])
        log.info("using %d swarm-selected features", len(prep.feature_names))
    mc, tc = model_and_train_cfg(cfg, swarm if a.model == "spidercardio" else None)
    rel = relevance_for(prep.train_raw, prep.feature_names) if a.model == "spidercardio" else None
    r = run_model(a.model, prep.train, prep.val, prep.test, prep.feature_names, mc, tc, rel, cfg["seed"],
                  measure_latency=True)
    rep = r["report"]
    rep["progression"] = progression_sensitivity(prep.test.y, r["proba"].argmax(1), prep.test.prev_y, prep.test.source)
    rep["features"] = prep.feature_names
    save_json(rep, out / "metrics.json")
    np.savez_compressed(out / "test_predictions.npz", proba=r["proba"], y=prep.test.y, record_id=prep.test.record_id,
                        source=prep.test.source)
    if r["history"]:
        pd.DataFrame(r["history"]).to_csv(out / "history.csv", index=False)
    save_model(r["model"], out / "model.pt")
    b, s = rep["binary"], rep["staging"]
    print(f"[{a.model}] binary CAD: acc {b['accuracy']:.4f} prec {b['precision']:.4f} rec {b['recall']:.4f} "
          f"spec {b['specificity']:.4f} F1 {b['f1']:.4f} MCC {b['mcc']:.4f} AUC {b['auc']:.4f}")
    print(f"[{a.model}] 4-stage: acc {s['accuracy']:.4f} macro-F1 {s['f1']:.4f} MCC {s['mcc']:.4f} AUC {s['auc']:.4f}")


if __name__ == "__main__":
    main()
