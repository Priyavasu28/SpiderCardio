"""Wall-clock training time per epoch and single-sample inference latency, averaged over
independent runs after one warm-up epoch (Section 3.7).

    python scripts/measure_timing.py --epochs 5
"""
import numpy as np
import pandas as pd
import torch
from _cli import config, parser

from spidercardio.experiment import relevance_for
from spidercardio.models.factory import build_model
from spidercardio.pipeline import apply_selection, load_swarm, model_and_train_cfg, prepare, save_json, setup
from spidercardio.training.trainer import TrainConfig, fit, inference_latency


def main():
    p = parser(__doc__)
    p.add_argument("--epochs", type=int, default=5)
    a = p.parse_args()
    cfg = config(a)
    out = setup(cfg, "timing")
    prep = prepare(cfg)
    swarm = load_swarm(cfg)
    if swarm:
        prep = apply_selection(prep, swarm["selected_features"])
    mc, tc = model_and_train_cfg(cfg, swarm)
    rows = []
    for run in range(cfg["timing"]["runs"]):
        m = build_model("spidercardio", prep.feature_names, mc, relevance_for(prep.train_raw, prep.feature_names))
        res = fit(m, prep.train, prep.val, TrainConfig.from_dict({**tc, "max_epochs": a.epochs + 1,
                                                                   "patience": 10 ** 6, "seed": run, "verbose": False}))
        lat = inference_latency(m, prep.test, device=tc.get("device", "auto"))
        rows.append({"run": run, "epoch_time_s": float(np.mean(res.epoch_times)), "latency_ms": lat[0]})
    df = pd.DataFrame(rows)
    df.to_csv(out / "timing_runs.csv", index=False)
    summ = {"epoch_time_s_mean": df.epoch_time_s.mean(), "epoch_time_s_sd": df.epoch_time_s.std(ddof=1),
            "latency_ms_mean": df.latency_ms.mean(), "latency_ms_sd": df.latency_ms.std(ddof=1),
            "device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else "cpu"}
    save_json(summ, out / "timing_summary.json")
    print(summ)


if __name__ == "__main__":
    main()
