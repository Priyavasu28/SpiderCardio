"""Stratified, patient-grouped 10-fold CV inside the 70 % development partition (Sections 3.1, 3.7).

    python scripts/cross_validate.py --model spidercardio
"""
from _cli import config, parser

from spidercardio.experiment import cross_validate, relevance_for
from spidercardio.pipeline import apply_selection, load_swarm, model_and_train_cfg, prepare, setup


def main():
    p = parser(__doc__)
    p.add_argument("--model", default="spidercardio")
    p.add_argument("--no-swarm", action="store_true")
    a = p.parse_args()
    cfg = config(a)
    out = setup(cfg, f"cv/{a.model}")
    prep = prepare(cfg, balance=False)
    swarm = None if a.no_swarm else load_swarm(cfg)
    if swarm and a.model == "spidercardio" and cfg["swarm"].get("use_selected_features", True):
        prep = apply_selection(prep, swarm["selected_features"])
    mc, tc = model_and_train_cfg(cfg, swarm if a.model == "spidercardio" else None)
    rel = relevance_for(prep.train_raw, prep.feature_names) if a.model == "spidercardio" else None
    folds, summary = cross_validate(a.model, prep, mc, tc, cfg, rel, cfg["seed"])
    folds.to_csv(out / "folds.csv", index=False)
    summary.to_csv(out / "summary_mean_sd.csv")
    print(summary.T.to_string())


if __name__ == "__main__":
    main()
