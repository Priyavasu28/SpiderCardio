"""Create SIMULATED panel ratings so the audit-scoring code can be tested end to end.
NEVER use the output as evidence - real ratings must come from the cardiologist panel."""
import numpy as np
import pandas as pd
from pathlib import Path
from _cli import config, parser

from spidercardio.pipeline import read_cohort


def main():
    cfg = config(parser(__doc__).parse_args())
    ex = Path(cfg["paths"]["results"]) / "explain"
    t = pd.read_csv(ex / "audit_ratings_template.csv", dtype=str)
    truth = read_cohort(cfg).set_index("record_id")["stage"]
    rng = np.random.default_rng(0)
    for k in (1, 2, 3):
        st = truth.loc[t.record_id].to_numpy()
        noisy = np.clip(st + (rng.random(len(st)) < 0.1) * rng.choice([-1, 1], len(st)), 0, 3)
        t[f"rater{k}"] = [f"C{s + 1}" for s in noisy]
        t[f"rater{k}_top3"] = "chol_ratio;st_depression;vessel_blockage_score"
        for c in [c for c in t.columns if c.startswith(f"rater{k}_dir_")]:
            t[c] = rng.choice(["1", "-1", ""], len(t), p=[0.6, 0.2, 0.2])
    t.to_csv(ex / "audit_ratings_SIMULATED.csv", index=False)
    print("wrote", ex / "audit_ratings_SIMULATED.csv")


if __name__ == "__main__":
    main()
