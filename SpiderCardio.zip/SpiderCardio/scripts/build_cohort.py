"""Harmonize UCI + PTB-XL + MIMIC-IV into the 42-attribute schema, derive the four-level
target, split 70/15/15 at patient level, and write Table 2 + released split identifiers.

    python scripts/build_cohort.py                       # real data (default.yaml)
    python scripts/build_cohort.py --config configs/smoke.yaml   # synthetic demo cohort
"""
import logging
from pathlib import Path

import yaml
from _cli import config, parser

from spidercardio.data.harmonize import harmonize
from spidercardio.data.preprocessing import missing_report
from spidercardio.data.schema import FEATURES
from spidercardio.data.splits import patient_split, save_split_ids
from spidercardio.pipeline import setup, stage_table, write_cohort

log = logging.getLogger("build_cohort")


def main():
    a = parser(__doc__).parse_args()
    cfg = config(a)
    out = setup(cfg, "cohort")
    srcs = cfg["data"]["sources"]
    if "synthetic" in srcs:
        from spidercardio.data.synthetic import make_synthetic_cohort
        Path(cfg["paths"]["waveform_h5"]).parent.mkdir(parents=True, exist_ok=True)
        df = make_synthetic_cohort(cfg.get("synthetic", {}).get("n_patients", 1500), seed=cfg["seed"],
                                   waveform_h5=cfg["paths"]["waveform_h5"])
    else:
        frames = []
        if "uci" in srcs:
            from spidercardio.data.sources.uci import load_uci
            frames.append(load_uci(cfg["paths"]["uci_dir"]))
        if "ptbxl" in srcs:
            from spidercardio.data.sources.ptbxl import load_ptbxl
            Path(cfg["paths"]["waveform_h5"]).parent.mkdir(parents=True, exist_ok=True)
            frames.append(load_ptbxl(cfg["paths"]["ptbxl_dir"], waveform_h5=cfg["paths"]["waveform_h5"],
                                     n_jobs=cfg["data"].get("ptbxl_n_jobs", 1)))
        if "mimic" in srcs:
            from spidercardio.data.sources.mimic import load_mimic
            frames.append(load_mimic(cfg["paths"]["mimic_dir"]))
        rules = yaml.safe_load(Path(cfg["data"]["label_rules"]).read_text())
        df = harmonize(frames, rules, cfg["data"]["max_missing_fraction"])
    path = write_cohort(df, cfg)
    split = patient_split(df, tuple(cfg["data"]["split"]), seed=cfg["seed"])
    save_split_ids(df, split, cfg["paths"]["splits"])
    t2 = stage_table(df, split)
    t2.to_csv(out / "table2_stage_distribution.csv", index=False)
    missing_report(df, FEATURES).to_csv(out / "missingness_by_source.csv")
    df.groupby("source").size().to_csv(out / "records_by_source.csv")
    log.info("cohort written to %s (%d records, %d patients)", path, len(df), df.patient_id.nunique())
    print(t2.to_string(index=False))


if __name__ == "__main__":
    main()
