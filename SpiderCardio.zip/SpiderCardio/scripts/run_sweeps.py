"""Module-level sweeps on the VALIDATION partition (Tables 4-6) and the matched-capacity
embedding comparators requested in Section 3.2 (MLP, polynomial, factorization machine).

    python scripts/run_sweeps.py --sweep embedding      # Table 4
    python scripts/run_sweeps.py --sweep comparators    # Sec. 3.2 comparison at 512-d budget
    python scripts/run_sweeps.py --sweep routing        # Table 5
    python scripts/run_sweeps.py --sweep seqlen         # Table 6
"""
import logging

import numpy as np
import pandas as pd
from _cli import config, parser

from spidercardio.data.schema import DEPENDENCY_PAIRS
from spidercardio.evaluation import diagnostics as dg
from spidercardio.evaluation.metrics import full_report
from spidercardio.experiment import relevance_for, run_model
from spidercardio.pipeline import apply_selection, load_swarm, model_and_train_cfg, prepare, setup
from spidercardio.training.trainer import predict_proba

log = logging.getLogger("sweeps")


def _train(prep, mc, tc, rel, seed, train=None, val=None):
    train = prep.train if train is None else train
    val = prep.val if val is None else val
    r = run_model("spidercardio", train, val, val, prep.feature_names, mc, tc, rel, seed)
    return r["model"], r["report"]


def main():
    p = parser(__doc__)
    p.add_argument("--sweep", choices=["embedding", "comparators", "routing", "seqlen"], required=True)
    a = p.parse_args()
    cfg = config(a)
    out = setup(cfg, f"sweeps/{a.sweep}")
    sw = cfg["sweeps"]
    max_len = max(sw["seq_lens"]) if a.sweep == "seqlen" else None
    prep = prepare(cfg, max_seq_len=max_len)
    swarm = load_swarm(cfg)
    if swarm and cfg["swarm"].get("use_selected_features", True):
        prep = apply_selection(prep, swarm["selected_features"])
    mc, tc = model_and_train_cfg(cfg, swarm)
    rel = relevance_for(prep.train_raw, prep.feature_names)
    dev = tc.get("device", "auto")
    rows = []
    if a.sweep in ("embedding", "comparators"):
        grid = [("hyperscalar", d) for d in sw["embedding_dims"]] if a.sweep == "embedding" else \
            [(e, 512) for e in sw["embedding_comparators"]]
        for emb, D in grid:
            m_cfg = {**mc, "embedding": emb, "hyperscalar_hidden": [min(128, D), min(256, D), D]}
            model, rep = _train(prep, m_cfg, tc, rel, cfg["seed"])
            nr = dg.noise_resistance(model, prep.val, cfg["diagnostics"]["noise_sigma"], device=dev)
            rows.append({"embedding": emb, "dimension": D,
                         "representation_accuracy": 100 * rep["binary"]["accuracy"],
                         "staging_accuracy": 100 * rep["staging"]["accuracy"],
                         "stability_score": 100 * dg.representation_stability(model, prep.val, device=dev),
                         "noise_resistance": nr["noise_resistance"]})
            log.info(rows[-1])
    elif a.sweep == "routing":
        for r_it in sw["routing_iterations"]:
            model, rep = _train(prep, {**mc, "routing_iterations": r_it}, tc, rel, cfg["seed"])
            dp = dg.dependency_preservation(model, prep.val, prep.feature_names, DEPENDENCY_PAIRS, device=dev)
            fa = dg.feature_agreement(model, prep.val, device=dev)
            rows.append({"routing_iterations": r_it, "spatial_accuracy": 100 * rep["binary"]["accuracy"],
                         "staging_accuracy": 100 * rep["staging"]["accuracy"],
                         "dependency_preservation": 100 * dp["dependency_preservation"],
                         "feature_agreement_raw": fa["feature_agreement_raw"],
                         "feature_agreement_vs_uniform": fa["feature_agreement_vs_uniform"]})
            log.info(rows[-1])
    else:
        for L in sw["seq_lens"]:
            tr, va = prep.train.with_seq_len(L), prep.val.with_seq_len(L)
            keep_tr, keep_va = tr.mask[:, -1], va.mask[:, -1]
            model, rep = _train(prep, mc, tc, rel, cfg["seed"], tr, va)
            pred = predict_proba(model, va, dev).argmax(1)
            ps = dg.progression_sensitivity(va.y, pred, va.prev_y, va.source)
            rows.append({"sequence_length": L, "temporal_accuracy": 100 * rep["binary"]["accuracy"],
                         "staging_accuracy": 100 * rep["staging"]["accuracy"],
                         "progression_sensitivity": 100 * ps["progression_sensitivity"],
                         "n_transitions": ps["n_transitions"],
                         "sequence_stability": 100 * dg.sequence_stability(model, va, dev)})
            assert keep_tr.all() and keep_va.all()
            log.info(rows[-1])
    name = {"embedding": "table4_embedding_dimension", "comparators": "table4b_embedding_comparators",
            "routing": "table5_routing_iterations", "seqlen": "table6_sequence_length"}[a.sweep]
    pd.DataFrame(rows).round(4).to_csv(out / f"{name}.csv", index=False)
    print(pd.DataFrame(rows).round(2).to_string(index=False))


if __name__ == "__main__":
    main()
