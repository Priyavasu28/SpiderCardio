"""Post-hoc SHAP explanations, Table 7 importance scores, clinician-facing treatment-support
suggestions (Algorithm 3) and the blinded cardiologist-audit workbook (Section 3.9).

Requires a trained model:  python scripts/train.py --model spidercardio
"""
import logging
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from _cli import config, parser

from spidercardio.evaluation.audit import sample_audit_set
from spidercardio.experiment import relevance_for
from spidercardio.explain.shap_explainer import (explain_gradient, explain_permutation, global_importance,
                                                 select_class, top_k_features)
from spidercardio.explain.treatment import suggest
from spidercardio.models.factory import build_model
from spidercardio.pipeline import apply_selection, load_swarm, model_and_train_cfg, prepare, save_json, setup
from spidercardio.training.trainer import predict_proba

log = logging.getLogger("explain")


def main():
    p = parser(__doc__)
    p.add_argument("--model-dir", default=None, help="defaults to <results>/train/spidercardio")
    a = p.parse_args()
    cfg = config(a)
    out = setup(cfg, "explain")
    prep = prepare(cfg)
    swarm = load_swarm(cfg)
    if swarm and cfg["swarm"].get("use_selected_features", True):
        prep = apply_selection(prep, swarm["selected_features"])
    mc, tc = model_and_train_cfg(cfg, swarm)
    names = prep.feature_names
    model = build_model("spidercardio", names, mc, relevance_for(prep.train_raw, names))
    mdir = Path(a.model_dir or Path(cfg["paths"]["results"]) / "train" / "spidercardio")
    model.load_state_dict(torch.load(mdir / "model.pt", map_location="cpu"))
    dev = tc.get("device", "auto")
    ec = cfg["explain"]

    test = prep.test
    proba = predict_proba(model, test, dev)
    audit = sample_audit_set(test.record_id, test.y, ec["audit_size"], cfg["seed"])
    rng = np.random.default_rng(cfg["seed"])
    extra = rng.choice(len(test), min(ec["n_explain"], len(test)), replace=False)
    pos = {r: i for i, r in enumerate(test.record_id)}
    idx = np.unique(np.concatenate([extra, [pos[r] for r in audit["record_id"]]]))
    sub = test.subset(idx)
    log.info("explaining %d test records with %s SHAP", len(sub), ec["method"])
    if ec["method"] == "permutation":
        sv = explain_permutation(model, prep.train_raw, sub, device=dev)
    else:
        sv = explain_gradient(model, prep.train_raw, sub, ec["n_background"], ec["nsamples"], cfg["seed"], dev)
    pred = proba[idx].argmax(1)
    phi = select_class(sv, pred)
    np.savez_compressed(out / "shap_values.npz", shap_values=sv, phi_predicted=phi, record_id=sub.record_id,
                        features=np.array(names), proba=proba[idx], y=sub.y)
    gi = global_importance(phi, names)
    gi.to_csv(out / "table7_shap_importance.csv", index=False)

    # ---- treatment-support suggestions -----------------------------------
    w = gi.set_index("feature").loc[names, "importance_score"].to_numpy()
    raw = prep.df.set_index("record_id")
    sugg, md = [], ["# Clinician-facing treatment-support suggestions (audit subset)\n",
                    "> Decision support only - requires clinician review.\n"]
    audit_ids = set(audit["record_id"])
    for j, rid in enumerate(sub.record_id):
        rv = raw.loc[rid].to_dict() if rid in raw.index else {}
        s = suggest(rid, proba[idx][j], phi[j], names, w, rv)
        d = s.to_dict()
        d["dominant_factors"] = ";".join(f for f, _ in s.dominant_factors)
        d["secondary_factors"] = ";".join(f for f, _ in s.secondary_factors)
        d["true_stage"] = int(sub.y[j])
        d["in_audit_set"] = rid in audit_ids
        sugg.append(d)
        if rid in audit_ids:
            md.append(s.to_markdown())
    pd.DataFrame(sugg).to_csv(out / "treatment_support_suggestions.csv", index=False)
    (out / "patient_reports_audit_set.md").write_text("\n".join(md))
    top3 = top_k_features(phi, names, sub.record_id, ec["top_k"])
    save_json({k: v for k, v in top3.items() if k in audit_ids}, out / "shap_top3_audit_set.json")
    pd.DataFrame(phi, index=sub.record_id, columns=names).to_csv(out / "shap_phi_predicted_class.csv")

    # ---- blinded audit workbook (no model outputs) ------------------------
    from spidercardio.data.schema import FEATURES
    blind = raw.loc[audit["record_id"], ["source", *FEATURES]].reset_index()
    blind.to_csv(out / "audit_cases_blinded.csv", index=False)
    top_feats = gi["feature"].head(10).tolist()
    tmpl = pd.DataFrame({"record_id": audit["record_id"]})
    for k in (1, 2, 3):
        tmpl[f"rater{k}"] = ""
        tmpl[f"rater{k}_top3"] = ""
        for f in top_feats:
            tmpl[f"rater{k}_dir_{f}"] = ""
    tmpl["consensus"] = ""
    tmpl.to_csv(out / "audit_ratings_template.csv", index=False)
    print(gi.head(10).to_string(index=False))
    print(f"wrote suggestions for {len(sugg)} records; audit set {len(audit)} cases -> {out}")


if __name__ == "__main__":
    main()
