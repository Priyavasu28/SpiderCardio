#!/usr/bin/env bash
# End-to-end pipeline on SYNTHETIC data (CPU, a few minutes). Numbers are meaningless.
set -euo pipefail
cd "$(dirname "$0")/.."
C="--config configs/smoke.yaml"
python scripts/build_cohort.py $C
python scripts/run_swarm.py $C
python scripts/train.py $C --model spidercardio
python scripts/explain_and_recommend.py $C
python scripts/simulate_audit_ratings.py $C          # synthetic ratings - pipeline test only
python scripts/evaluate_audit.py $C --ratings results_smoke/explain/audit_ratings_SIMULATED.csv
python scripts/run_benchmark.py $C --models xgboost cnn
python scripts/make_figures.py $C
echo "smoke test OK"
