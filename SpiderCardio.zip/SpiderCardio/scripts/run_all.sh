#!/usr/bin/env bash
# Full reproduction on the real harmonized cohort (GPU strongly recommended).
set -euo pipefail
cd "$(dirname "$0")/.."
C="--config configs/default.yaml"
python scripts/build_cohort.py $C                                # Table 2, split identifiers
python scripts/run_swarm.py $C                                   # Table 3, Fig. 2
python scripts/run_swarm.py $C --optimizers pso ga gwo aco       # optimizer comparison (Sec. 4.1)
python scripts/train.py $C --model spidercardio                  # main model, per-source results
python scripts/cross_validate.py $C --model spidercardio         # 10-fold mean +/- SD
python scripts/run_benchmark.py $C                               # Table 8 + DeLong / McNemar
python scripts/run_ablation.py $C                                # Table 9
for s in embedding comparators routing seqlen; do python scripts/run_sweeps.py $C --sweep $s; done   # Tables 4-6
python scripts/explain_and_recommend.py $C                       # Table 7 (SHAP), suggestions, audit workbook
python scripts/measure_timing.py $C                              # epoch time / latency
python scripts/make_figures.py $C
# after the cardiologist panel has filled results/explain/audit_ratings_template.csv:
# python scripts/evaluate_audit.py $C --ratings path/to/filled_ratings.csv
