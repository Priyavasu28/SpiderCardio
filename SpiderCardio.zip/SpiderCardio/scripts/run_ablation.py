"""Leave-one-component-out ablation (Table 9).

'Without Spider-Swarm' = manuscript default hyperparameters, all 42 features and
alpha = 1 (no relevance amplification). 'Without SHAP' needs no retraining: SHAP is
post hoc, so its predictive metrics equal the complete model by construction.
"""
import logging

import pandas as pd
from _cli import config, parser

from spidercardio.experiment import relevance_for, run_model
from spidercardio.models.factory import ABLATIONS
from spidercardio.pipeline import apply_selection, load_swarm, model_and_train_cfg, prepare, save_json, setup

log = logging.getLogger("ablation")
LABELS = {"no_hyperscalar": "Without Hyperscalar Expansion", "no_swarm": "Without Spider-Swarm Optimization",
          "no_capsule": "Without Capsule Learning", "no_gru": "Without GRU Temporal Modeling",
          "no_shap": "Without SHAP Explainability", "capsule_only": "Capsule Only", "gru_only": "GRU Only",
          "hyperscalar_capsule": "Hyperscalar + Capsule", "capsule_gru": "Capsule + GRU",
          "complete": "Complete SpiderCardio Framework"}


def main():
    a = parser(__doc__).parse_args()
    cfg = config(a)
    out = setup(cfg, "ablation")
    prep_all = prepare(cfg)
    swarm = load_swarm(cfg)
    prep = apply_selection(prep_all, swarm["selected_features"]) if swarm else prep_all
    mc, tc = model_and_train_cfg(cfg, swarm)
    rel = relevance_for(prep.train_raw, prep.feature_names)
    rows = []
    order = ["no_hyperscalar", "no_swarm", "no_capsule", "no_gru", "no_shap", "capsule_only", "gru_only",
             "hyperscalar_capsule", "capsule_gru", "complete"]
    results = {}
    for v in order:
        if v == "no_shap":
            continue
        if v == "no_swarm":
            r = run_model("complete", prep_all.train, prep_all.val, prep_all.test, prep_all.feature_names,
                          dict(cfg["model"]), dict(cfg["train"]), None, cfg["seed"])
        else:
            assert v in ABLATIONS
            r = run_model(v, prep.train, prep.val, prep.test, prep.feature_names, mc, tc, rel, cfg["seed"])
        results[v] = r["report"]
        log.info("%s: acc %.4f", v, r["report"]["binary"]["accuracy"])
    results["no_shap"] = results["complete"]          # post-hoc layer: identical by construction
    for v in order:
        b = results[v]["binary"]
        rows.append({"variant": LABELS[v] + (" *" if v == "no_shap" else ""), "accuracy": 100 * b["accuracy"],
                     "recall": 100 * b["recall"], "auc": 100 * b["auc"],
                     "staging_accuracy": 100 * results[v]["staging"]["accuracy"]})
    t9 = pd.DataFrame(rows).round(2)
    t9.to_csv(out / "table9_ablation.csv", index=False)
    save_json(results, out / "ablation_reports.json")
    print(t9.to_string(index=False))
    print("* SHAP is post hoc and not used at inference; metrics equal the complete model by construction.")


if __name__ == "__main__":
    main()
