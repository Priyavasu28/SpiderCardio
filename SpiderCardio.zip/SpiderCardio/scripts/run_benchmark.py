"""Comparative evaluation on the held-out test partition (Table 8) with paired
significance tests against SpiderCardio (DeLong for AUC, McNemar for accuracy).

    python scripts/run_benchmark.py
    python scripts/run_benchmark.py --models xgboost transformer
"""
import logging

import numpy as np
import pandas as pd
from _cli import config, parser

from spidercardio.evaluation.metrics import to_row
from spidercardio.evaluation.stats import delong_test, mcnemar_test
from spidercardio.experiment import relevance_for, run_model, tune_baseline
from spidercardio.pipeline import apply_selection, load_swarm, model_and_train_cfg, prepare, save_json, setup

log = logging.getLogger("benchmark")
DISPLAY = {"random_forest": "Random Forest", "xgboost": "XGBoost", "cnn": "CNN", "lstm": "LSTM", "gru": "GRU",
           "cnn_lstm": "CNN-LSTM", "densenet": "DenseNet", "transformer": "Transformer", "capsule": "Capsule Network",
           "capsule_gru_baseline": "Capsule-GRU", "resnet18_1d": "ResNet-18 (1-D)",
           "efficientnet_1d": "EfficientNet-B0 (1-D)", "spidercardio": "Proposed SpiderCardio"}


def main():
    p = parser(__doc__)
    p.add_argument("--models", nargs="*", default=None)
    a = p.parse_args()
    cfg = config(a)
    out = setup(cfg, "benchmark")
    prep_all = prepare(cfg)
    swarm = load_swarm(cfg)
    rows_b, rows_s, preds, info = [], [], {}, {}
    models = (a.models or cfg["baselines"]) + ["spidercardio"]
    for name in dict.fromkeys(models):
        if name == "spidercardio":
            prep = apply_selection(prep_all, swarm["selected_features"]) if swarm and cfg["swarm"].get("use_selected_features", True) else prep_all
            mc, tc = model_and_train_cfg(cfg, swarm)
            rel, tree_p = relevance_for(prep.train_raw, prep.feature_names), None
        else:
            prep = prep_all
            mc, tc = dict(cfg["model"]), dict(cfg["train"])
            best_tc, tree_p = tune_baseline(name, prep, mc, tc, cfg, cfg["seed"])
            tc = {**tc, **best_tc}
            rel = None
        r = run_model(name, prep.train, prep.val, prep.test, prep.feature_names, mc, tc, rel, cfg["seed"], tree_p,
                      measure_latency=name not in ("random_forest", "xgboost"))
        preds[name] = r["proba"]
        if r["history"]:
            pd.DataFrame(r["history"]).to_csv(out / f"history_{name}.csv", index=False)
        rows_b.append(to_row(DISPLAY.get(name, name), r["report"], "binary"))
        rows_s.append(to_row(DISPLAY.get(name, name), r["report"], "staging"))
        info[name] = {k: r["report"].get(k) for k in ["n_params", "train_time_s", "epochs_run", "best_epoch",
                                                       "epoch_time_mean_s", "latency_ms_mean", "latency_ms_sd",
                                                       "per_source"]}
        info[name]["train_config"] = tc
        info[name]["tree_params"] = tree_p
        pd.DataFrame(rows_b).round(4).to_csv(out / "table8_binary.csv", index=False)
        pd.DataFrame(rows_s).round(4).to_csv(out / "table8_staging.csv", index=False)
        log.info("%s done", name)
    np.savez_compressed(out / "test_probas.npz", y=prep_all.test.y, **preds)
    # paired tests vs SpiderCardio
    y = prep_all.test.y
    y_cad = (y >= 1).astype(int)
    ref = preds["spidercardio"]
    tests = []
    for name, pr in preds.items():
        if name == "spidercardio":
            continue
        dl = delong_test(y_cad, 1 - ref[:, 0], 1 - pr[:, 0])
        mn = mcnemar_test(y_cad, (1 - ref[:, 0] >= 0.5).astype(int), (1 - pr[:, 0] >= 0.5).astype(int))
        mn_s = mcnemar_test(y, ref.argmax(1), pr.argmax(1))
        tests.append({"comparator": DISPLAY.get(name, name), "delong_auc_spidercardio": dl["auc1"],
                      "delong_auc_comparator": dl["auc2"], "delong_p": dl["p_value"],
                      "mcnemar_binary_p": mn["p_value"], "mcnemar_staging_p": mn_s["p_value"]})
    pd.DataFrame(tests).to_csv(out / "significance_vs_spidercardio.csv", index=False)
    save_json(info, out / "model_info.json")
    print(pd.DataFrame(rows_b).round(2).to_string(index=False))


if __name__ == "__main__":
    main()
