"""Score the cardiologist reference audit (Section 3.9; Table 7 expert-agreement columns).

    python scripts/evaluate_audit.py --ratings audit_ratings_filled.csv
"""
import json
from pathlib import Path

import pandas as pd
from _cli import config, parser

from spidercardio.evaluation.audit import clinical_consistency, interpretation_reliability, treatment_concordance
from spidercardio.pipeline import save_json, setup


def main():
    p = parser(__doc__)
    p.add_argument("--ratings", required=True)
    a = p.parse_args()
    cfg = config(a)
    out = setup(cfg, "audit")
    ex = Path(cfg["paths"]["results"]) / "explain"
    ratings = pd.read_csv(a.ratings, dtype=str)
    sugg = pd.read_csv(ex / "treatment_support_suggestions.csv").set_index("record_id")["category"]
    conc = treatment_concordance(sugg, ratings)
    top3 = json.loads((ex / "shap_top3_audit_set.json").read_text())
    ir = interpretation_reliability(top3, ratings, cfg["explain"]["top_k"])
    phi = pd.read_csv(ex / "shap_phi_predicted_class.csv", index_col=0)
    num = ratings.copy()
    for c in num.columns:
        if "_dir_" in c:
            num[c] = pd.to_numeric(num[c], errors="coerce")
    cc = clinical_consistency(phi, num)
    save_json({"treatment_concordance": conc, "interpretation_reliability": ir, "clinical_consistency": cc},
              out / "audit_results.json")
    imp = pd.read_csv(ex / "table7_shap_importance.csv").head(10)
    rows = []
    for f in imp["feature"]:
        c = cc.get(f, {})
        r = ir["per_feature"].get(f)
        rows.append({"feature": f, "shap_importance": imp.set_index("feature").loc[f, "importance_score"],
                     "clinical_consistency_pct": 100 * c.get("value", float("nan")), "cc_N": c.get("N"),
                     "cc_wilson_95ci": c.get("wilson_95ci"),
                     "interpretation_reliability_pct": 100 * r[2] if r else float("nan"),
                     "ir_N": r[1] if r else 0, "ir_wilson_95ci": r[3] if r else None})
    pd.DataFrame(rows).to_csv(out / "table7_complete.csv", index=False)
    print(f"Treatment-support concordance: {conc['k']}/{conc['N']} = {100 * conc['concordance']:.2f}% "
          f"(95% Wilson CI {100 * conc['wilson_95ci'][0]:.2f}-{100 * conc['wilson_95ci'][1]:.2f}); "
          f"Fleiss kappa {conc['fleiss_kappa']:.3f} (95% CI {conc['fleiss_kappa_95ci'][0]:.3f}-{conc['fleiss_kappa_95ci'][1]:.3f})")
    print(pd.DataFrame(rows).round(2).to_string(index=False))


if __name__ == "__main__":
    main()
