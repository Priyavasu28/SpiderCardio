"""Regenerate manuscript figures from saved results (Figures 2, 5-18 + ROC / confusion matrices).
Each figure is skipped (with a message) if its inputs have not been produced yet.

    python scripts/make_figures.py
"""
import json
import logging
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from _cli import config, parser  # noqa: E402

from spidercardio.data.schema import STAGE_NAMES, display  # noqa: E402
from spidercardio.pipeline import read_cohort, setup  # noqa: E402

log = logging.getLogger("figures")
# Validated categorical slots (dataviz reference palette) and an ordinal blue ramp for stages
CAT = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300"]
STAGE = ["#86b6ef", "#3987e5", "#1c5cab", "#0d366b"]
INK, MUTED, GRID = "#1f1f1e", "#6b6a64", "#e4e3de"
plt.rcParams.update({"font.size": 10, "axes.edgecolor": MUTED, "axes.labelcolor": INK, "xtick.color": MUTED,
                     "ytick.color": MUTED, "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6,
                     "axes.spines.top": False, "axes.spines.right": False, "legend.frameon": False,
                     "savefig.dpi": 300, "savefig.bbox": "tight", "lines.linewidth": 2})


def save(fig, out, name):
    fig.savefig(out / f"{name}.png")
    fig.savefig(out / f"{name}.pdf")
    plt.close(fig)
    log.info("wrote %s", name)


def fig_swarm(res, out):
    files = sorted((res / "swarm").glob("*_history.csv"))
    if not files:
        return log.info("skip Fig 2: no swarm histories")
    fig, ax = plt.subplots(figsize=(6, 3.6))
    for i, f in enumerate(files):
        h = pd.read_csv(f)
        name = f.stem.replace("_history", "")
        ax.plot(h["iteration"], h["best_fitness"], color=CAT[i % len(CAT)], label=name.replace("_", "-").upper()
                if name != "spider_swarm" else "Spider-Swarm")
    ax.set_xlabel("Iteration")
    ax.set_ylabel("Best fitness (Eq. 10)")
    ax.legend()
    save(fig, out, "fig02_swarm_convergence")


def fig_learning(res, out):
    files = sorted((res / "benchmark").glob("history_*.csv"))
    if not files:
        return log.info("skip Figs 5/6: no benchmark histories")
    for col, name, lab in [("val_acc", "fig05_learning_stability", "Validation accuracy (4-stage)"),
                           ("train_loss", "fig06_training_loss", "Training loss (focal)")]:
        fig, ax = plt.subplots(figsize=(6.4, 3.8))
        k = 0
        for f in files:
            m = f.stem.replace("history_", "")
            h = pd.read_csv(f)
            is_main = m == "spidercardio"
            ax.plot(h["epoch"], h[col], color=CAT[1] if is_main else CAT[0], alpha=1 if is_main else 0.35,
                    linewidth=2.4 if is_main else 1.2, label="SpiderCardio" if is_main else ("Baselines" if k == 0 else None))
            k += 0 if is_main else 1
        ax.set_xlabel("Epoch")
        ax.set_ylabel(lab)
        ax.legend()
        save(fig, out, name)


def fig_cohort(df, out):
    d = df.copy()
    # Fig 7: interaction map
    sub = d.dropna(subset=["total_chol", "resting_sbp", "st_depression"])
    if len(sub):
        sub = sub.sample(min(4000, len(sub)), random_state=0)
        fig, ax = plt.subplots(figsize=(5.6, 4.2))
        for s in range(4):
            q = sub[sub.stage == s]
            ax.scatter(q.total_chol, q.resting_sbp, s=8 + 10 * q.st_depression.clip(0, 4), color=STAGE[s],
                       alpha=0.6, edgecolors="white", linewidths=0.4, label=STAGE_NAMES[s])
        ax.set_xlabel("Total cholesterol (mg/dL)")
        ax.set_ylabel("Resting SBP (mmHg)")
        ax.legend(title="Stage (marker size = ST depression)")
        save(fig, out, "fig07_biomarker_interaction")
    # Fig 8 histograms, Fig 9 frequency polygons, Fig 10 boxplots, Fig 11 densities
    cols = [c for c in ["total_chol", "resting_sbp", "max_hr", "st_depression"] if d[c].notna().sum() > 20]
    if cols:
        fig, axes = plt.subplots(1, len(cols), figsize=(3.2 * len(cols), 3))
        for ax, c, col in zip(np.atleast_1d(axes), cols, CAT):
            ax.hist(d[c].dropna(), bins=40, color=col, edgecolor="white", linewidth=0.5)
            ax.set_title(display(c), color=INK)
        save(fig, out, "fig08_attribute_frequency")
        fig, axes = plt.subplots(1, len(cols), figsize=(3.2 * len(cols), 3))
        for ax, c in zip(np.atleast_1d(axes), cols):
            bins = np.linspace(d[c].quantile(0.01), d[c].quantile(0.99), 25)
            for s in range(4):
                h, e = np.histogram(d.loc[d.stage == s, c].dropna(), bins=bins, density=True)
                ax.plot((e[:-1] + e[1:]) / 2, h, color=STAGE[s], marker="o", markersize=3, label=STAGE_NAMES[s])
            ax.set_title(display(c), color=INK)
        h_, l_ = np.atleast_1d(axes)[0].get_legend_handles_labels()
        fig.legend(h_, l_, loc="lower center", ncol=4, bbox_to_anchor=(0.5, -0.08))
        save(fig, out, "fig09_frequency_polygons")
        fig, axes = plt.subplots(1, len(cols), figsize=(3.2 * len(cols), 3))
        for ax, c in zip(np.atleast_1d(axes), cols):
            data = [d.loc[d.stage == s, c].dropna() for s in range(4)]
            bp = ax.boxplot(data, patch_artist=True, widths=0.6, flierprops={"markersize": 2, "alpha": 0.4})
            for patch, col in zip(bp["boxes"], STAGE):
                patch.set_facecolor(col)
            ax.set_xticks(range(1, 5), [n[:4] for n in STAGE_NAMES])
            ax.set_title(display(c), color=INK)
        save(fig, out, "fig10_biomarker_dispersion")
        from scipy.stats import gaussian_kde
        fig, axes = plt.subplots(1, len(cols), figsize=(3.2 * len(cols), 3))
        for ax, c, col in zip(np.atleast_1d(axes), cols, CAT):
            v = d[c].dropna().to_numpy()
            if v.std() > 0:
                xs = np.linspace(np.quantile(v, 0.005), np.quantile(v, 0.995), 200)
                ax.fill_between(xs, gaussian_kde(v)(xs), color=col, alpha=0.25)
                ax.plot(xs, gaussian_kde(v)(xs), color=col)
            ax.set_title(display(c), color=INK)
        save(fig, out, "fig11_feature_density")
    # Fig 16 correlation heatmap (diverging, gray midpoint)
    from matplotlib.colors import LinearSegmentedColormap
    feats = ["chol_ratio", "total_chol", "resting_sbp", "st_depression", "max_hr", "diabetes", "hypertension",
             "fasting_glucose", "ecg_morphology_index", "vessel_blockage_score", "age"]
    feats = [f for f in feats if d[f].notna().sum() > 20]
    C = d[feats + ["stage"]].corr()
    cmap = LinearSegmentedColormap.from_list("div", ["#2a78d6", "#efeee9", "#eb6834"])
    fig, ax = plt.subplots(figsize=(6.4, 5.4))
    im = ax.imshow(C, cmap=cmap, vmin=-1, vmax=1)
    ax.set_xticks(range(len(C)), [display(c) for c in C.columns], rotation=60, ha="right")
    ax.set_yticks(range(len(C)), [display(c) for c in C.columns])
    ax.grid(False)
    fig.colorbar(im, ax=ax, label="Pearson r")
    save(fig, out, "fig16_correlation_heatmap")
    # Fig 17 stage distribution
    cnt = d.stage.value_counts().reindex(range(4), fill_value=0)
    fig, ax = plt.subplots(figsize=(5, 3.2))
    ax.bar(STAGE_NAMES, cnt.values, color=STAGE, edgecolor="white", linewidth=2)
    for i, v in enumerate(cnt.values):
        ax.text(i, v, f"{v:,}\n({100 * v / cnt.sum():.2f}%)", ha="center", va="bottom", fontsize=8, color=INK)
    ax.set_ylabel("Records")
    save(fig, out, "fig17_stage_distribution")


def fig_models(res, out):
    t = res / "benchmark" / "table8_binary.csv"
    if t.exists():
        df = pd.read_csv(t).sort_values("accuracy")
        fig, ax = plt.subplots(figsize=(6.4, 0.35 * len(df) + 1))
        colors = [CAT[1] if "SpiderCardio" in m else CAT[0] for m in df.model]
        ax.barh(df.model, df.accuracy, color=colors, height=0.7)
        for y, v in enumerate(df.accuracy):
            ax.text(v, y, f" {v:.2f}", va="center", fontsize=8, color=INK)
        ax.set_xlim(max(0, df.accuracy.min() - 10), 100)
        ax.set_xlabel("Test accuracy, binary CAD (%)")
        save(fig, out, "fig12_model_comparison")
    p = res / "benchmark" / "test_probas.npz"
    if p.exists():
        from sklearn.metrics import confusion_matrix, roc_curve
        z = np.load(p, allow_pickle=True)
        y = z["y"]
        fig, ax = plt.subplots(figsize=(4.6, 4.2))
        keys = [k for k in z.files if k != "y"]
        others = [k for k in keys if k != "spidercardio"]
        for i, k in enumerate(others[:5] + ["spidercardio"]):
            fpr, tpr, _ = roc_curve(y >= 1, 1 - z[k][:, 0])
            ax.plot(fpr, tpr, color=CAT[1] if k == "spidercardio" else CAT[[0, 2, 3, 4, 5][i % 5]], label=k)
        ax.plot([0, 1], [0, 1], color=MUTED, linestyle="--", linewidth=1)
        ax.set_xlabel("False-positive rate")
        ax.set_ylabel("True-positive rate")
        ax.legend(fontsize=7)
        save(fig, out, "fig_roc_binary")
        if "spidercardio" in keys:
            cm = confusion_matrix(y, z["spidercardio"].argmax(1), labels=range(4))
            fig, ax = plt.subplots(figsize=(4.2, 3.8))
            ax.imshow(cm / cm.sum(1, keepdims=True).clip(1), cmap="Blues", vmin=0, vmax=1)
            for i in range(4):
                for j in range(4):
                    ax.text(j, i, cm[i, j], ha="center", va="center", fontsize=8,
                            color="white" if cm[i, j] > cm[i].sum() / 2 else INK)
            ax.set_xticks(range(4), STAGE_NAMES)
            ax.set_yticks(range(4), STAGE_NAMES)
            ax.set_xlabel("Predicted stage")
            ax.set_ylabel("Reference stage")
            ax.grid(False)
            save(fig, out, "fig_confusion_staging")


def fig_shap(res, out):
    t = res / "explain" / "table7_shap_importance.csv"
    if not t.exists():
        return log.info("skip Fig 13: run explain_and_recommend.py")
    df = pd.read_csv(t).head(12).iloc[::-1]
    fig, ax = plt.subplots(figsize=(5.6, 4))
    ax.barh([display(f) for f in df.feature], df.importance_score, color=CAT[0], height=0.7)
    ax.set_xlabel("SHAP importance (mean |SHAP|, scaled to max = 1)")
    save(fig, out, "fig13_shap_ranking")


def fig_temporal(res, df, out):
    p = res / "train" / "spidercardio" / "test_predictions.npz"
    if not p.exists():
        return log.info("skip Fig 14: run train.py")
    z = np.load(p, allow_pickle=True)
    t = pd.DataFrame({"record_id": z["record_id"], "p_high": z["proba"][:, 2:].sum(1), "y_high": z["y"] >= 2})
    t = t.merge(df[["record_id", "time_index"]], on="record_id")
    g = t.groupby("time_index").agg(pred=("p_high", "mean"), obs=("y_high", "mean"), n=("p_high", "size"))
    g = g[g.n >= 20]
    if len(g) < 2:
        return log.info("skip Fig 14: too few longitudinal records")
    fig, ax = plt.subplots(figsize=(5.6, 3.4))
    ax.plot(g.index, g.obs, color=CAT[0], marker="o", label="Observed share high/critical")
    ax.plot(g.index, g.pred, color=CAT[1], marker="o", label="Mean predicted P(high or critical)")
    ax.set_xlabel("Visit index within patient")
    ax.set_ylabel("Proportion / probability")
    ax.legend()
    save(fig, out, "fig14_temporal_risk_evolution")


def fig_ecg_spectrum(cfg, out):
    root = Path(cfg["paths"]["ptbxl_dir"])
    if not (root / "ptbxl_database.csv").exists():
        return log.info("skip Fig 18: PTB-XL not available")
    import wfdb
    from scipy.signal import welch
    from spidercardio.data.ecg import wavelet_denoise
    rec = pd.read_csv(root / "ptbxl_database.csv").iloc[0]
    sig, meta = wfdb.rdsamp(str(root / rec["filename_hr"]))
    fs = int(meta["fs"])
    raw = sig[:, 1]
    clean = wavelet_denoise(raw, fs)
    fig, ax = plt.subplots(figsize=(5.6, 3.4))
    for s, lab, col in [(raw, "Raw lead II", CAT[0]), (clean, "Wavelet-denoised", CAT[1])]:
        f, pxx = welch(s, fs, nperseg=1024)
        ax.semilogy(f, pxx, color=col, label=lab)
    ax.set_xlim(0, 100)
    ax.set_xlabel("Frequency (Hz)")
    ax.set_ylabel("PSD (mV²/Hz)")
    ax.legend()
    save(fig, out, "fig18_ecg_spectrum")


def main():
    a = parser(__doc__).parse_args()
    cfg = config(a)
    out = setup(cfg, "figures")
    res = Path(cfg["paths"]["results"])
    df = read_cohort(cfg)
    for fn, args in [(fig_swarm, (res, out)), (fig_learning, (res, out)), (fig_cohort, (df, out)),
                     (fig_models, (res, out)), (fig_shap, (res, out)), (fig_temporal, (res, df, out)),
                     (fig_ecg_spectrum, (cfg, out))]:
        try:
            fn(*args)
        except Exception as e:  # keep going - one missing input must not block the others
            log.warning("%s failed: %s", fn.__name__, e)


if __name__ == "__main__":
    main()
