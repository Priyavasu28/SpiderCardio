# SpiderCardio

**Explainable Spider-Swarm Optimized Hyperscalar Capsule-GRU Framework for CAD Risk Staging and Clinician-Facing Treatment-Support Suggestions**

Official implementation accompanying the manuscript by D. Rajapriya and M. Vigenesh.

> **Scope.** This is research software for retrospective, computational evaluation on public datasets. The
> treatment-support output is a rule-based, clinician-facing *decision-support suggestion*. It is not a treatment
> directive and has not been prospectively or clinically validated.

---

## Pipeline

```
UCI Heart Disease ─┐
PTB-XL (ECG)  ─────┼─► harmonize to 42-attribute schema ─► derived 4-stage label (low/moderate/high/critical)
MIMIC-IV (hosp) ───┘        │  wavelet ECG denoising, KNN imputation, z-score (fit on train only)
                            ▼
              patient-level 70/15/15 split  ─► ADASYN inside training partition / folds only
                            ▼
      Spider-Swarm optimisation  z = [b ∈ {0,1}^42, θ]  (40 agents × 120 iterations, Eq. 9–12)
                            ▼
  Hyperscalar expansion (128→256→512, clinical pair crosses, swarm-relevance amplification α_ij)
                            ▼
  Primary capsules 64×8D ─► dynamic routing (3 iters, LayerNorm) ─► 32×16D cardiovascular capsules
                            ▼
  Stacked GRU 128 → 64 (Eqs. 17–20) + temporal attention over the patient timeline ─► softmax over 4 stages
                            ▼
  Post-hoc SHAP (GradientExplainer, 500 background) ─► rule-based suggestion C1–C4 + priority + T_c (Eq. 23)
```

## Installation

```bash
git clone https://github.com/<user>/SpiderCardio.git && cd SpiderCardio
python -m venv .venv && source .venv/bin/activate
pip install torch            # pick the CUDA build for your GPU from pytorch.org
pip install -r requirements.txt
pytest -q                     # 28 unit tests
bash scripts/smoke_test.sh    # full pipeline on synthetic data, CPU, ~10 min
```

Tested with Python 3.11, PyTorch 2.2+, CUDA 12.1.

## Data

| Source | Access | Where to put it |
|---|---|---|
| UCI Heart Disease [36] | open | `python scripts/download_data.py --uci` → `data/raw/uci/` |
| PTB-XL v1.0.3 [37] | open | `python scripts/download_data.py --ptbxl` → `data/raw/ptb-xl/1.0.3/` |
| MIMIC-IV v2.2 [38] | **PhysioNet credentialed** (CITI training + DUA) | `data/raw/mimiciv/2.2/hosp/*.csv.gz` |

No patient-level data are included in this repository. MIMIC-IV-derived records cannot be redistributed. Users with
credentials regenerate them with `scripts/build_cohort.py`. Released split files (`data/splits/*_ids.csv`) contain
record identifiers only. See [`docs/DATA.md`](docs/DATA.md) for the harmonization and labelling rules.

## Reproducing the manuscript

```bash
bash scripts/run_all.sh          # or run the steps one by one:
```

| Step | Command | Produces |
|---|---|---|
| Harmonize, label, split | `scripts/build_cohort.py` | cohort, **Table 2**, split IDs |
| Spider-Swarm | `scripts/run_swarm.py` | selected features, tuned hyper-parameters, **Table 3**, Fig. 2 |
| Optimizer comparison | `scripts/run_swarm.py --optimizers pso ga gwo aco` | Section 4.1 supplementary |
| Main model | `scripts/train.py --model spidercardio` | test metrics, per-source results, checkpoint |
| 10-fold CV | `scripts/cross_validate.py` | mean ± SD over folds |
| Baselines | `scripts/run_benchmark.py` | **Table 8** (all columns incl. specificity and MCC), DeLong / McNemar |
| Ablation | `scripts/run_ablation.py` | **Table 9** |
| Sweeps | `scripts/run_sweeps.py --sweep embedding / comparators / routing / seqlen` | **Tables 4–6**, MLP / polynomial / FM comparison |
| Explainability | `scripts/explain_and_recommend.py` | SHAP (**Table 7**), suggestions, blinded audit workbook |
| Audit scoring | `scripts/evaluate_audit.py --ratings filled.csv` | concordance k/N + Wilson CI, Fleiss' κ, Table 7 expert columns |
| Timing | `scripts/measure_timing.py` | s/epoch, ms/sample (mean ± SD over runs) |
| Figures | `scripts/make_figures.py` | Figs. 2, 5–18, ROC, confusion matrix (PNG and PDF) |

Every setting is in `configs/default.yaml`. You can override any value from the command line, for example
`--set train.max_epochs=60 swarm.n_iter=60`. Each run writes `config_used.yaml` and a log to its results folder.

## Repository layout

```
spidercardio/
  data/        schema.py (42 attributes) · labeling.py (4-stage rule) · ecg.py (wavelet denoise, ECG features)
               sources/{uci,ptbxl,mimic}.py · harmonize.py · preprocessing.py · sequences.py · splits.py · balancing.py
  models/      hyperscalar.py · capsules.py · temporal.py · spidercardio.py · losses.py · baselines_nn.py · factory.py
  optim/       search_space.py · spider_swarm.py · metaheuristics.py (PSO/GA/GWO/ACO) · fitness.py
  training/    trainer.py
  explain/     shap_explainer.py · treatment.py
  evaluation/  metrics.py · diagnostics.py · audit.py · stats.py
scripts/       one script per experiment (see table above)
configs/       default.yaml · smoke.yaml · label_rules.yaml · mimic_codes.yaml
docs/          METHODS_TO_CODE.md · DATA.md
```

## Synthetic data

`configs/smoke.yaml` builds a synthetic cohort in the same schema, so that every script can be tested without
credentialed data. Numbers produced on it are meaningless. Never report them.

## Citation

```bibtex
@article{rajapriya_spidercardio,
  author  = {Rajapriya, D. and Vigenesh, M.},
  title   = {Explainable Spider-Swarm Optimized Hyperscalar Capsule-GRU Framework for CAD Risk Staging
             and Clinician-Facing Treatment-Support Suggestions},
  journal = {<journal>}, year = {<year>}, doi = {<doi>}
}
```

## License

MIT (see `LICENSE`). Dataset licences and the MIMIC-IV data use agreement apply separately.
