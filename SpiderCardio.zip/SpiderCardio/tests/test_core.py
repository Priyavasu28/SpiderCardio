import numpy as np
import pandas as pd
import pytest
import torch

from spidercardio.data.balancing import adasyn_sequences
from spidercardio.data.labeling import derive_stage
from spidercardio.data.preprocessing import Preprocessor
from spidercardio.data.schema import FEATURES
from spidercardio.data.sequences import build_sequences
from spidercardio.data.splits import assert_no_patient_leakage, grouped_cv_folds, patient_split
from spidercardio.data.synthetic import make_synthetic_cohort
from spidercardio.evaluation.audit import fleiss_kappa, treatment_concordance
from spidercardio.evaluation.metrics import full_report, wilson_ci
from spidercardio.evaluation.stats import delong_test, mcnemar_test
from spidercardio.explain.treatment import STAGE_TO_CATEGORY, confidence_score, suggest
from spidercardio.models.capsules import RoutingCapsules, squash
from spidercardio.models.factory import ABLATIONS, build_model
from spidercardio.models.temporal import MaskedGRU
from spidercardio.optim import SearchSpace, SpiderSwarmOptimizer, get_optimizer


@pytest.fixture(scope="module")
def cohort():
    return make_synthetic_cohort(250, seed=3)


@pytest.fixture(scope="module")
def seqs(cohort):
    pp = Preprocessor(FEATURES).fit(cohort)
    return build_sequences(cohort, pp.transform(cohort), 5)


def test_schema_has_42():
    assert len(FEATURES) == 42 and len(set(FEATURES)) == 42


def test_label_rule_examples():
    df = pd.DataFrame({
        "lbl_vessels": [0, 1, 2, 3, np.nan, 0], "lbl_cad": [0, 1, 1, 1, np.nan, 0],
        "lbl_acs": [0, 0, 0, 0, 1, 0], "st_depression": [0, 0.5, 0, 0, 0, 1.5],
        "age": [40] * 6, "diabetes": [0] * 6, "hypertension": [0] * 6, "chol_ratio": [3] * 6})
    s = derive_stage(df)
    assert s.tolist()[:5] == [0, 1, 2, 3, 3]
    assert np.isnan(s.iloc[5])          # no stenosis but ischaemic ECG -> unassignable


def test_split_no_leakage(cohort):
    sp = patient_split(cohort)
    assert_no_patient_leakage(*(cohort.loc[sp == p, "patient_id"] for p in ["train", "val", "test"]))
    folds = grouped_cv_folds(cohort.stage.values, cohort.patient_id.values, 5)
    for tr, te in folds:
        assert not set(cohort.patient_id.values[tr]) & set(cohort.patient_id.values[te])


def test_sequences_right_aligned(seqs, cohort):
    assert seqs.X.shape[1:] == (5, 42)
    assert seqs.mask[:, -1].all()
    n_hist = seqs.mask.sum(1)
    assert n_hist.max() <= 5 and n_hist.min() >= 1


def test_adasyn_balances(seqs):
    b = adasyn_sequences(seqs, seed=0)
    c = np.bincount(b.y)
    assert (c == c.max()).all()
    assert b.mask[:, -1].all()


def test_squash_norm_below_one():
    v = squash(torch.randn(10, 16) * 5)
    assert (v.norm(dim=-1) < 1).all()


def test_routing_coupling_sums_to_one():
    r = RoutingCapsules(8, 4, 5, 6, iterations=3)
    v, c = r(torch.randn(3, 8, 4))
    assert v.shape == (3, 5, 6)
    assert torch.allclose(c.sum(2), torch.ones(3, 8), atol=1e-5)


def test_masked_gru_ignores_padding():
    g = MaskedGRU(4, 8)
    x = torch.randn(2, 5, 4)
    m = torch.ones(2, 5, dtype=torch.bool)
    m[0, :2] = False
    x2 = x.clone()
    x2[0, :2] = 99.0                    # garbage in padded steps must not matter
    assert torch.allclose(g(x, m)[0, -1], g(x2, m)[0, -1])


@pytest.mark.parametrize("name", ["spidercardio", *ABLATIONS, "cnn", "lstm", "transformer", "densenet", "capsule"])
def test_models_forward(name, seqs):
    m = build_model(name, FEATURES).eval()
    out = m(torch.from_numpy(seqs.X[:4]), torch.from_numpy(seqs.mask[:4]), None)
    assert out.shape == (4, 4) and torch.isfinite(out).all()


def test_swarm_finds_planted_subset():
    names = [f"f{i}" for i in range(12)]
    good = np.zeros(12, bool)
    good[[1, 4, 7]] = True
    def fit(mask, hyper):  # optimum: exactly the planted features and lr near 1e-3
        return (mask == good).mean() - 0.1 * abs(np.log10(hyper["lr"]) + 3)
    sp = SearchSpace(names, min_features=2)
    res = SpiderSwarmOptimizer(sp, fit, n_agents=20, n_iter=60, seed=0, convergence_patience=None).run()
    assert res.best_fitness > 0.8
    for n in ["pso", "ga", "gwo", "aco"]:
        r = get_optimizer(n)(sp, fit, n_agents=10, n_iter=10, seed=0).run()
        assert np.isfinite(r.best_fitness)


def test_search_space_roundtrip():
    sp = SearchSpace(FEATURES)
    hyper = {"lr": 3e-4, "capsule_dim": 16, "gru_hidden": 128, "dropout": 0.35,
             "routing_iterations": 3, "batch_size": 64, "optimizer": "adamw"}
    dec = sp.decode(sp.encode(hyper))
    assert dec["capsule_dim"] == 16 and dec["gru_hidden"] == 128 and dec["optimizer"] == "adamw"
    assert abs(dec["lr"] - 3e-4) / 3e-4 < 1e-6


def test_metrics_and_ci():
    y = np.array([0, 1, 2, 3] * 25)
    p = np.eye(4)[y] * 0.9 + 0.025
    rep = full_report(y, p)
    assert rep["staging"]["accuracy"] == 1 and rep["binary"]["auc"] == 1
    lo, hi = wilson_ci(95, 100)
    assert 0.88 < lo < 0.95 < hi < 0.99


def test_stats():
    rng = np.random.default_rng(0)
    y = rng.integers(0, 2, 300)
    p1 = y * 0.6 + rng.random(300) * 0.5
    r = delong_test(y, p1, p1)
    assert r["p_value"] > 0.99
    assert mcnemar_test(y, y, 1 - y)["p_value"] < 1e-6


def test_fleiss_and_concordance():
    R = np.array([["C1", "C1", "C1"], ["C2", "C2", "C3"], ["C4", "C4", "C4"]], dtype=object)
    assert fleiss_kappa(R) > 0.5
    audit = pd.DataFrame({"record_id": ["a", "b", "c"], "rater1": R[:, 0], "rater2": R[:, 1], "rater3": R[:, 2]})
    out = treatment_concordance(pd.Series(["C1", "C2", "C3"], index=["a", "b", "c"]), audit)
    assert out["k"] == 2 and out["N"] == 3


def test_treatment_mapping():
    assert STAGE_TO_CATEGORY == {0: "C1", 1: "C2", 2: "C3", 3: "C4"}
    phi = np.array([0.3, -0.1, 0.05])
    s = suggest("r1", np.array([0.1, 0.1, 0.1, 0.7]), phi, ["a", "b", "c"], np.ones(3),
                {"vessel_blockage_score": 1.0, "st_depression": 2.5, "diabetes": 1})
    assert s.category == "C4" and s.priority.startswith("highest")
    assert abs(confidence_score(phi, np.ones(3)) - 0.25 / 3) < 1e-9
