# Manuscript → code map

| Manuscript | Code |
|---|---|
| Sec. 3.1 harmonized 42-attribute schema | `spidercardio/data/schema.py` |
| Sec. 3.1 derived 4-level label rule | `spidercardio/data/labeling.py`, thresholds in `configs/label_rules.yaml` |
| Eq. 1 z-score, Eq. 2 min-max, Eq. 3 neighbourhood imputation | `data/preprocessing.py` (`Preprocessor`, fitted on train only) |
| Eq. 4 wavelet ECG reconstruction S(t)=A(t)+D(t) | `data/ecg.py::wavelet_denoise` |
| >10 % missing → discard | `data/harmonize.py::harmonize` (`max_missing_fraction`) |
| Patient-level 70/15/15, stratified grouped 10-fold CV | `data/splits.py` |
| ADASYN inside training folds only | `data/balancing.py`, called in `pipeline.prepare` and `experiment.cross_validate` |
| Eq. 5 projection 128-256-512 + BN + GELU, Eq. 8 dropout 0.35 | `models/hyperscalar.py::HyperscalarExpansion.projection` |
| Eq. 6 constrained pair cross, Eq. 7 per-pair α from Eq. 12 | `HyperscalarExpansion.forward`, `alpha` buffer |
| MLP / polynomial / FM comparators (Sec. 3.2) | `models/hyperscalar.py`, `run_sweeps.py --sweep comparators` |
| Eq. 13 primary capsules (64×8D) | `models/capsules.py::PrimaryCapsules` |
| Eq. 14 squash, Eq. 15 routing softmax, Eq. 16 agreement | `models/capsules.py::squash`, `RoutingCapsules` (32×16D, 3 iterations, LayerNorm) |
| Focal loss | `models/losses.py` |
| Eqs. 17–20 GRU (128, 64), temporal dropout 0.25, attention | `models/temporal.py` (`PaperGRUCell` written exactly as the equations) |
| Eq. 22 stage softmax; binary CAD = 1 − P(low) | `models/spidercardio.py`, `evaluation/metrics.py::full_report` |
| Eq. 9 position update, web-link term, binary sigmoid vibration, local freeze | `optim/spider_swarm.py` |
| Eq. 10 fitness, Eq. 12 relevance | `optim/fitness.py` |
| Eq. 11 exploration schedule 0.9 → 0.2 | `SpiderSwarmOptimizer.exploration` |
| PSO / GA / GWO / ACO comparators | `optim/metaheuristics.py` |
| AdamW, cosine, clip 1.0, patience 15, max 120 epochs, timing | `training/trainer.py` |
| Eq. 21 SHAP (GradientExplainer; permutation cross-check) | `explain/shap_explainer.py` |
| Algorithms 2–3, C1–C4, adaptive priority, Eq. 23 T_c | `explain/treatment.py` |
| Sec. 3.8.1 metrics, Wilson CI | `evaluation/metrics.py` |
| Sec. 3.8.2 diagnostic metrics (1)–(5), Sequence Stability | `evaluation/diagnostics.py` |
| Sec. 3.8.2 (6)–(7), Sec. 3.9 audit, Fleiss' κ | `evaluation/audit.py` |
| Limitation (vii): DeLong, McNemar | `evaluation/stats.py`, `run_benchmark.py` |
| Table 9 ablation variants | `models/factory.py::ABLATIONS`, `run_ablation.py` |

## Definitions this implementation had to fix (the manuscript leaves them open)

Make sure the paper text matches these, or change the code:

1. **Explainer for the Capsule-GRU network.** The code uses `shap.GradientExplainer`, not TreeSHAP, with 500
   background sequences. Attributions are summed over time steps.
2. **Fitness function.** The default is exactly Eq. 10 (0.4·Acc + 0.3·Recall + 0.3·AUC on validation).
   Redundancy and stability terms are available but weighted 0. Concordance is *not* part of the fitness, because
   the audit cases come from the untouched test set.
3. **α_ij = 1 + λ·√(|R_i||R_j|)** with λ = 1.
4. **Clinical Consistency.** This is the share of audited cases with a panel direction annotation in which the sign
   of the SHAP value matches the panel's majority direction.
5. **Sequence Stability.** This is the share of multi-visit records whose predicted stage does not change when the
   oldest visit is removed.
6. **Dependency Preservation.** Capsule-response correlation for the physiological pairs, relative to random pairs,
   under a 1-SD perturbation.
7. **Feature Agreement.** The code reports raw coupling c_ij. The rows sum to 1 over 32 output capsules, so the raw
   values are about 0.03. A "relative to uniform" value is also reported. The 87–95 % values in Table 5 cannot come
   from raw c_ij.
8. **Convergence rate (Table 3).** Swarm consensus, computed as 1 − mean normalised distance to the global best.
9. **Binary CAD target.** Stage ≥ moderate.
10. **ADASYN target.** The default oversamples every class up to the majority class size. Near-uniform classes of
    about 8,400 each (Section 4) need `balance.target=8400 balance.majority_undersample=true`.
