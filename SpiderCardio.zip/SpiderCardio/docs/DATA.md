# Data harmonization and labelling

## Sources → schema

* **UCI** (`sources/uci.py`). The four processed files: Cleveland, Hungarian, Switzerland and VA. The fluoroscopy
  count `ca` becomes the *feature* `num_vessels`. The angiographic diagnosis `num` is used *only* as a label source
  (`lbl_vessels`). A value of 0 for `chol` or `trestbps` is treated as missing.
* **PTB-XL** (`sources/ptbxl.py`). 500 Hz records are wavelet-denoised. Lead II gives rhythm and HRV. ST deviation
  is measured in V5 at J+60 ms against the PR baseline. SCP statements with likelihood ≥ 50 give:
  * ischaemia (`ISC*`)
  * MI (diagnostic class MI)
  * acute injury (`INJ*` → `lbl_acs`)
  * LVH

  Multiple ECGs of one `patient_id` are ordered by date to form a longitudinal sequence. A 10 s lead-II segment at
  100 Hz is stored for the waveform baselines.
* **MIMIC-IV** (`sources/mimic.py`). One record per admission, built from:
  * labs (median per admission; peak troponin)
  * OMR blood pressure and BMI
  * ICD-9/10 flags from `configs/mimic_codes.yaml`

  Verify the item IDs against your `d_labitems`.

Features that a source cannot supply are *structurally* missing. They are imputed inside the training fold and do
not count toward the >10 % corrupted-record rule.

## Four-level label (`labeling.py`)

| Stage | Rule (evaluated low → high; higher overwrites) |
|---|---|
| Low | no documented stenosis (`lbl_vessels == 0` or `lbl_cad == 0`) **and** no ischaemic ECG (flag or ST depression ≥ 1 mm) |
| Moderate | documented CAD evidence: single vessel, intermediate stenosis, CAD code, or prior MI |
| High | multi-vessel / CABG status, **or** CAD evidence + ischaemic ECG + burden ≥ 2, **or** CAD evidence + high-risk ECG (ST depression ≥ 2 mm or ST elevation), **or** ischaemic ECG + burden ≥ 2 with no angiographic information |
| Critical | ACS / acute injury codes, left-main, or ≥ 3 vessels |

Burden adds one point each for: age ≥ 55, diabetes, hypertension, and total cholesterol / HDL ≥ 5. Records that fit
no row are excluded. Several rule inputs are also model inputs (Limitation ii).
