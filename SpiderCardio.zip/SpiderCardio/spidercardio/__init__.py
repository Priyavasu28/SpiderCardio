"""SpiderCardio: Explainable Spider-Swarm Optimized Hyperscalar Capsule-GRU framework
for CAD risk staging and clinician-facing treatment-support suggestions."""
__version__ = "1.0.0"
