"""High-level helpers shared by the experiment scripts."""
from __future__ import annotations

import json
import logging
import random
from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import yaml

from .data.balancing import adasyn_sequences
from .data.preprocessing import Preprocessor
from .data.schema import FEATURES, TARGET
from .data.sequences import SequenceData, build_sequences
from .data.splits import assert_no_patient_leakage, patient_split

log = logging.getLogger("spidercardio")
ROOT = Path(__file__).resolve().parents[1]


# ---------------------------------------------------------------- config / io
def deep_update(base: dict, upd: dict) -> dict:
    out = deepcopy(base)
    for k, v in (upd or {}).items():
        out[k] = deep_update(out[k], v) if isinstance(v, dict) and isinstance(out.get(k), dict) else v
    return out


def load_config(path: str | Path, overrides: list[str] | None = None) -> dict:
    path = Path(path)
    cfg = yaml.safe_load(path.read_text())
    if "inherit" in cfg:
        parent = load_config(path.parent / cfg.pop("inherit"))
        cfg = deep_update(parent, cfg)
    for o in overrides or []:                         # key.sub=value
        k, v = o.split("=", 1)
        node = cfg
        *parents, leaf = k.split(".")
        for p in parents:
            node = node.setdefault(p, {})
        node[leaf] = yaml.safe_load(v)
    return cfg


def setup(cfg: dict, name: str = "run") -> Path:
    seed = int(cfg.get("seed", 42))
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    out = Path(cfg["paths"]["results"]) / name
    out.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s",
                        handlers=[logging.StreamHandler(), logging.FileHandler(out / "log.txt")], force=True)
    (out / "config_used.yaml").write_text(yaml.safe_dump(cfg, sort_keys=False))
    return out


def save_json(obj, path):
    def conv(o):
        if isinstance(o, (np.integer,)):
            return int(o)
        if isinstance(o, (np.floating,)):
            return float(o)
        if isinstance(o, np.ndarray):
            return o.tolist()
        if isinstance(o, (np.bool_,)):
            return bool(o)
        return str(o)
    Path(path).write_text(json.dumps(obj, indent=2, default=conv))


def read_cohort(cfg) -> pd.DataFrame:
    p = Path(cfg["paths"]["cohort"])
    if p.suffix == ".parquet":
        try:
            return pd.read_parquet(p)
        except (ImportError, ValueError):
            p = p.with_suffix(".csv")
    return pd.read_csv(p)


def write_cohort(df: pd.DataFrame, cfg) -> Path:
    p = Path(cfg["paths"]["cohort"])
    p.parent.mkdir(parents=True, exist_ok=True)
    if p.suffix == ".parquet":
        try:
            df.to_parquet(p, index=False)
            return p
        except ImportError:
            p = p.with_suffix(".csv")
    df.to_csv(p, index=False)
    return p


# ---------------------------------------------------------------- data
@dataclass
class Prepared:
    df: pd.DataFrame
    split: pd.Series
    pre: Preprocessor
    train_raw: SequenceData       # before ADASYN
    train: SequenceData           # after ADASYN (training fold only)
    val: SequenceData
    test: SequenceData
    feature_names: list
    feature_idx: np.ndarray


def prepare(cfg: dict, df: pd.DataFrame | None = None, balance: bool = True,
            max_seq_len: int | None = None) -> Prepared:
    df = read_cohort(cfg) if df is None else df
    dcfg = cfg["data"]
    split = patient_split(df, tuple(dcfg["split"]), seed=cfg.get("seed", 42))
    assert_no_patient_leakage(*(df.loc[split == s, "patient_id"] for s in ["train", "val", "test"]))
    pre = Preprocessor(FEATURES, dcfg.get("scaling", "zscore"), dcfg.get("knn_neighbors", 5),
                       seed=cfg.get("seed", 42)).fit(df[split == "train"])
    T = max_seq_len or dcfg["max_seq_len"]
    wave = cfg["paths"].get("waveform_h5") if dcfg.get("use_waveforms") else None
    if wave and not Path(wave).exists():
        log.warning("waveform file %s not found - waveform baselines fall back to tabular input", wave)
        wave = None
    parts = {}
    for s in ["train", "val", "test"]:
        sub = df[split == s].reset_index(drop=True)
        parts[s] = build_sequences(sub, pre.transform(sub), T, wave)
    tr = parts["train"]
    bal = cfg.get("balance", {})
    if balance and bal.get("method", "adasyn") == "adasyn":
        tr_bal = adasyn_sequences(tr, k=bal.get("k", 5), target=bal.get("target", "max"),
                                  majority_undersample=bal.get("majority_undersample", False),
                                  seed=cfg.get("seed", 42))
        log.info("ADASYN (training partition only): %s -> %s", np.bincount(tr.y).tolist(), np.bincount(tr_bal.y).tolist())
    else:
        tr_bal = tr
    return Prepared(df, split, pre, tr, tr_bal, parts["val"], parts["test"], list(FEATURES), np.arange(len(FEATURES)))


def apply_selection(p: Prepared, selected: list[str]) -> Prepared:
    idx = np.array([FEATURES.index(f) for f in selected])
    return Prepared(p.df, p.split, p.pre, p.train_raw.select_features(idx), p.train.select_features(idx),
                    p.val.select_features(idx), p.test.select_features(idx), list(selected), idx)


def load_swarm(cfg) -> dict | None:
    path = Path(cfg["paths"]["results"]) / "swarm" / f"{cfg['swarm']['optimizer']}.json"
    if path.exists():
        return json.loads(path.read_text())
    return None


def model_and_train_cfg(cfg: dict, swarm: dict | None):
    """Merge config with swarm-selected hyperparameters (if enabled)."""
    mc, tc = dict(cfg["model"]), dict(cfg["train"])
    if swarm and cfg["swarm"].get("use_tuned_hyperparameters", True):
        h = swarm["best_hyper"]
        mc.update(capsule_dim=h["capsule_dim"], gru_hidden=[h["gru_hidden"], max(16, h["gru_hidden"] // 2)],
                  hyperscalar_dropout=h["dropout"], routing_iterations=h["routing_iterations"])
        tc.update(lr=h["lr"], batch_size=h["batch_size"], optimizer=h["optimizer"])
    return mc, tc


def stage_table(df: pd.DataFrame, split: pd.Series) -> pd.DataFrame:
    """Table 2."""
    from .data.schema import STAGE_NAMES
    rows = []
    for name, sel in [("Training (70%)", split == "train"), ("Validation (15%)", split == "val"),
                      ("Test (15%)", split == "test"), ("Total", split.notna())]:
        c = df.loc[sel, TARGET].value_counts().reindex(range(4), fill_value=0)
        n = int(c.sum())
        row = {"partition": name}
        for k, s in enumerate(STAGE_NAMES):
            row[f"{s}_n"] = int(c[k])
            row[f"{s}_pct"] = round(100 * c[k] / n, 2) if n else 0
        row["total"] = n
        rows.append(row)
    return pd.DataFrame(rows)
