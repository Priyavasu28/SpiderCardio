"""Derived four-level CAD risk label (Section 3.1).

Ordinal rule, applied after schema harmonization:

* **Critical** - documented acute coronary syndrome, three-vessel / left-main
  equivalent disease, or equivalent high-acuity encounter codes.
* **High** - multi-vessel disease, or combined ischaemic ECG plus metabolic burden.
* **Moderate** - single-vessel or equivalent intermediate burden without
  high-risk ECG markers.
* **Low** - no documented significant stenosis and no ischaemic ECG criterion.

Records that cannot be assigned are returned as NaN and excluded from
supervised staging. All thresholds live in ``configs/label_rules.yaml`` so
the rule is auditable and can be changed without touching code.

NOTE (Limitation ii): several rule inputs are also model inputs, so staging
accuracy partly measures recovery of this rule.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

DEFAULT_RULES = {
    "burden": {"age": 55, "chol_ratio": 5.0},        # each satisfied criterion adds 1
    "ischemic_st_depression_mm": 1.0,                # ST depression >= 1 mm => ischaemic ECG
    "high_risk_st_depression_mm": 2.0,               # ST depression >= 2 mm => high-risk ECG
    "high_burden_min": 2,                            # ischaemic ECG + burden >= this => High
    "prior_mi_is_moderate": True,                    # prior MI without other criteria => Moderate
}


def _col(df: pd.DataFrame, name: str) -> pd.Series:
    if name in df.columns:
        return df[name]
    return pd.Series(np.nan, index=df.index)


def metabolic_burden(df: pd.DataFrame, rules: dict | None = None) -> pd.Series:
    r = {**DEFAULT_RULES, **(rules or {})}
    b = (_col(df, "age") >= r["burden"]["age"]).astype(int)
    b += (_col(df, "diabetes") == 1).astype(int)
    b += (_col(df, "hypertension") == 1).astype(int)
    b += (_col(df, "chol_ratio") >= r["burden"]["chol_ratio"]).astype(int)
    return b


def derive_stage(df: pd.DataFrame, rules: dict | None = None) -> pd.Series:
    """Return a float Series with values {0,1,2,3} or NaN (unassignable)."""
    r = {**DEFAULT_RULES, **(rules or {})}
    stdep = _col(df, "st_depression")
    ischemic = (_col(df, "ischemic_ecg_flag") == 1) | (stdep >= r["ischemic_st_depression_mm"])
    high_risk_ecg = (stdep >= r["high_risk_st_depression_mm"]) | (_col(df, "st_elevation") >= 1.0)
    burden = metabolic_burden(df, r)

    vessels = _col(df, "lbl_vessels")
    cad = _col(df, "lbl_cad")
    acs = _col(df, "lbl_acs") == 1
    left_main = _col(df, "lbl_left_main") == 1
    multivessel = (_col(df, "lbl_multivessel") == 1) | (vessels == 2)
    intermediate = (_col(df, "lbl_stenosis_intermediate") == 1) | (vessels == 1)
    prior_mi = _col(df, "lbl_prior_mi") == 1

    no_stenosis = (vessels == 0) | ((cad == 0) & vessels.isna())

    evidence = (cad == 1) | intermediate | (prior_mi if r["prior_mi_is_moderate"] else False)
    heavy = burden >= r["high_burden_min"]
    no_angio_info = vessels.isna() & cad.isna()

    stage = pd.Series(np.nan, index=df.index, dtype=float)
    # Evaluated from lowest to highest so that higher criteria overwrite lower ones.
    stage[no_stenosis & ~ischemic] = 0                                   # Low
    stage[evidence] = 1                                                  # Moderate
    stage[multivessel | (evidence & ischemic & heavy) | (evidence & high_risk_ecg)
          | (no_angio_info & ischemic & heavy)] = 2                      # High
    stage[acs | left_main | (vessels >= 3)] = 3                          # Critical
    return stage


def binary_cad(stage: pd.Series | np.ndarray) -> np.ndarray:
    """Binary CAD target used for Table 8: CAD present iff stage >= moderate."""
    return (np.asarray(stage) >= 1).astype(int)
