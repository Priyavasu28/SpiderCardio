"""PTB-XL v1.0.3 adapter [37].

* Reads ``ptbxl_database.csv`` + ``scp_statements.csv`` and the 500 Hz WFDB records.
* Each ECG is wavelet-denoised (Eq. 4) and converted to ECG-derived descriptors.
* Records of the same ``patient_id`` are ordered by ``recording_date`` to form a
  longitudinal sequence (``time_index``).
* Diagnostic statements provide label-source flags (ischaemia, MI, acute injury).
* Optionally stores a 10 s lead-II waveform at 100 Hz (1000 samples) in HDF5 for
  the waveform-consuming baselines (CNN, DenseNet, Transformer, LSTM, CNN-LSTM).
"""
from __future__ import annotations

import ast
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.signal import decimate

from ..ecg import denoise_12lead, ecg_features

ACUTE_INJURY_CODES = {"INJAS", "INJAL", "INJIN", "INJLA", "INJIL"}   # acute ST-elevation injury
ISCHEMIC_PREFIXES = ("ISC",)                                       # ISC_, ISCAL, ISCIN, ...
LVH_CODES = {"LVH", "VCLVH"}


def _parse_codes(s: str, min_likelihood: float) -> set[str]:
    d = ast.literal_eval(s)
    return {k for k, v in d.items() if v >= min_likelihood or v == 0.0}


def load_ptbxl(root: str | Path, min_likelihood: float = 50.0, max_records: int | None = None,
               waveform_h5: str | Path | None = None, n_jobs: int = 1) -> pd.DataFrame:
    import wfdb  # local import: only needed for PTB-XL

    root = Path(root)
    db = pd.read_csv(root / "ptbxl_database.csv", index_col="ecg_id")
    scp = pd.read_csv(root / "scp_statements.csv", index_col=0)
    diag = scp[scp["diagnostic"] == 1]
    mi_codes = set(diag.index[diag["diagnostic_class"] == "MI"]) - ACUTE_INJURY_CODES
    if max_records:
        db = db.iloc[:max_records]

    def one(ecg_id_row):
        ecg_id, row = ecg_id_row
        sig, meta = wfdb.rdsamp(str(root / row["filename_hr"]))
        fs = int(meta["fs"])
        clean = denoise_12lead(sig, fs)
        feats = ecg_features(clean, fs)
        wave = decimate(clean[:, 1], fs // 100)[:1000].astype(np.float32) if waveform_h5 else None
        return ecg_id, feats, wave

    items = list(db.iterrows())
    if n_jobs > 1:
        from joblib import Parallel, delayed
        results = Parallel(n_jobs=n_jobs)(delayed(one)(it) for it in items)
    else:
        results = [one(it) for it in items]

    rows = []
    waves = {}
    for ecg_id, feats, wave in results:
        row = db.loc[ecg_id]
        codes = _parse_codes(row["scp_codes"], min_likelihood)
        ischemic = any(c.startswith(ISCHEMIC_PREFIXES) for c in codes)
        acute = bool(codes & ACUTE_INJURY_CODES)
        prior_mi = bool(codes & mi_codes)
        h, w = row.get("height"), row.get("weight")
        bmi = w / (h / 100) ** 2 if pd.notna(h) and pd.notna(w) and h > 0 else np.nan
        rec = {
            "patient_id": f"ptbxl:{int(row['patient_id'])}",
            "source": "ptbxl",
            "recording_date": row["recording_date"],
            "record_id": f"ptbxl:{ecg_id}",
            "age": row["age"] if row["age"] < 300 else 90,       # PTB-XL encodes >89 as 300
            "sex": 1 - row["sex"],                               # PTB-XL: 0 male -> schema: 1 male
            "bmi": bmi,
            **feats,
            "ischemic_ecg_flag": float(ischemic),
            "lvh_flag": float(bool(codes & LVH_CODES)),
            "restecg": 2.0 if codes & LVH_CODES else (1.0 if ischemic or "STTC" in codes or "NST_" in codes else 0.0),
            "lbl_acs": float(acute),
            "lbl_prior_mi": float(prior_mi),
            "lbl_cad": 1.0 if (ischemic or prior_mi or acute) else 0.0,
        }
        rows.append(rec)
        if wave is not None:
            waves[rec["record_id"]] = wave

    df = pd.DataFrame(rows)
    df["recording_date"] = pd.to_datetime(df["recording_date"])
    df = df.sort_values(["patient_id", "recording_date"])
    df["time_index"] = df.groupby("patient_id").cumcount()
    df = df.drop(columns="recording_date")

    if waveform_h5:
        import h5py
        with h5py.File(waveform_h5, "a") as f:
            for k, v in waves.items():
                if k not in f:
                    f.create_dataset(k, data=v, compression="gzip")
    return df
