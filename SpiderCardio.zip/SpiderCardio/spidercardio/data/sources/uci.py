"""UCI Heart Disease (Cleveland, Hungarian, Switzerland, VA Long Beach) adapter [36].

Feature/label separation: the fluoroscopy vessel count ``ca`` is a *feature*
(``num_vessels``) while the angiographic diagnosis ``num`` (0-4) is used only as
a label-source column (``lbl_vessels``), so the label is not a copy of an input.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

UCI_FILES = {
    "cleveland": "processed.cleveland.data",
    "hungarian": "processed.hungarian.data",
    "switzerland": "processed.switzerland.data",
    "va": "processed.va.data",
}
UCI_BASE_URL = "https://archive.ics.uci.edu/ml/machine-learning-databases/heart-disease/"
UCI_COLUMNS = ["age", "sex", "cp", "trestbps", "chol", "fbs", "restecg", "thalach",
               "exang", "oldpeak", "slope", "ca", "thal", "num"]


def load_uci(raw_dir: str | Path) -> pd.DataFrame:
    raw_dir = Path(raw_dir)
    frames = []
    for site, fname in UCI_FILES.items():
        path = raw_dir / fname
        if not path.exists():
            continue
        df = pd.read_csv(path, header=None, names=UCI_COLUMNS, na_values="?")
        df["site"] = site
        frames.append(df)
    if not frames:
        raise FileNotFoundError(f"No UCI files found in {raw_dir}. Run scripts/download_data.py --uci")
    raw = pd.concat(frames, ignore_index=True)
    # chol == 0 in the Switzerland subset denotes "not measured"
    raw.loc[raw["chol"] == 0, "chol"] = np.nan
    raw.loc[raw["trestbps"] == 0, "trestbps"] = np.nan

    out = pd.DataFrame({
        "patient_id": [f"uci:{s}:{i}" for i, s in zip(raw.index, raw["site"])],
        "source": "uci",
        "time_index": 0,
        "age": raw["age"],
        "sex": raw["sex"],                                   # 1 = male
        "chest_pain_type": raw["cp"],                        # 1..4 (4 = asymptomatic)
        "resting_sbp": raw["trestbps"],
        "total_chol": raw["chol"],
        "fbs_gt120": raw["fbs"],
        "restecg": raw["restecg"],                           # 0 normal, 1 ST-T, 2 LVH
        "max_hr": raw["thalach"],
        "exercise_angina": raw["exang"],
        "st_depression": raw["oldpeak"].clip(lower=0),       # mm
        "st_slope": raw["slope"].map({1: 0, 2: 1, 3: 2}),    # up / flat / down
        "num_vessels": raw["ca"],
        "thal": raw["thal"].map({3: 0, 6: 1, 7: 2}),
        "vessel_blockage_score": raw["ca"] / 3.0,
        # label-source columns
        "lbl_vessels": raw["num"].clip(upper=3),
        "lbl_cad": (raw["num"] > 0).astype(float),
    })
    out["record_id"] = out["patient_id"] + ":0"
    return out
