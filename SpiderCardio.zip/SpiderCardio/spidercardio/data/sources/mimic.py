"""MIMIC-IV v2.2 (hosp module) adapter [38].

Requires PhysioNet credentialed access. No MIMIC-derived data are distributed with
this repository (DUA). One harmonized record is produced per hospital admission;
admissions of the same ``subject_id`` are ordered by ``admittime`` to form the
longitudinal sequence used by the GRU and by the Progression-Sensitivity metric.

Item IDs and ICD prefixes are listed in ``configs/mimic_codes.yaml``; verify them
against your local ``d_labitems`` / ``d_icd_diagnoses`` tables.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import yaml

DEFAULT_CODES = Path(__file__).resolve().parents[3] / "configs" / "mimic_codes.yaml"


def _has(codes: pd.DataFrame, prefixes: dict) -> pd.Series:
    """Per-hadm flag: any diagnosis code starting with one of the version-specific prefixes."""
    m = pd.Series(False, index=codes.index)
    for ver, pref in prefixes.items():
        if not pref:
            continue
        m |= (codes["icd_version"] == int(ver)) & codes["icd_code"].str.startswith(tuple(pref))
    return codes.assign(_f=m).groupby("hadm_id")["_f"].any()


def _read(path: Path, **kw):
    for suffix in ("", ".gz"):
        p = Path(str(path) + suffix)
        if p.exists():
            return pd.read_csv(p, **kw)
    raise FileNotFoundError(path)


def load_mimic(mimic_dir: str | Path, codes_yaml: str | Path = DEFAULT_CODES,
               chunksize: int = 5_000_000, max_subjects: int | None = None) -> pd.DataFrame:
    hosp = Path(mimic_dir) / "hosp"
    cfg = yaml.safe_load(Path(codes_yaml).read_text())

    pts = _read(hosp / "patients.csv", usecols=["subject_id", "gender", "anchor_age", "anchor_year"])
    adm = _read(hosp / "admissions.csv", usecols=["subject_id", "hadm_id", "admittime"],
                parse_dates=["admittime"])
    dx = _read(hosp / "diagnoses_icd.csv", usecols=["subject_id", "hadm_id", "icd_code", "icd_version"],
               dtype={"icd_code": str})
    dx["icd_code"] = dx["icd_code"].str.strip()

    if cfg.get("cohort_requires_cardiac_code", True):
        # restrict to admissions with any cardiovascular / metabolic code of interest
        keep = _has(dx, cfg["icd"]["cohort"])
        adm = adm[adm["hadm_id"].isin(keep[keep].index)]
    if max_subjects:
        adm = adm[adm["subject_id"].isin(adm["subject_id"].drop_duplicates().iloc[:max_subjects])]
    dx = dx[dx["hadm_id"].isin(adm["hadm_id"])]

    flags = pd.DataFrame(index=adm["hadm_id"].values)
    for name in ["acs", "cad", "prior_mi", "cabg_status", "pci_status", "diabetes",
                 "htn_essential", "htn_organ", "htn_crisis", "smoking", "family_history"]:
        flags[name] = _has(dx, cfg["icd"][name]).reindex(flags.index).fillna(False).astype(float)

    # ---- labs (chunked) --------------------------------------------------
    item_map = {int(k): v for k, v in cfg["lab_itemids"].items()}
    labs = []
    for chunk in _read(hosp / "labevents.csv", usecols=["hadm_id", "itemid", "valuenum"],
                       chunksize=chunksize):
        c = chunk[chunk["itemid"].isin(item_map) & chunk["hadm_id"].isin(flags.index)]
        if len(c):
            labs.append(c)
    lab = pd.concat(labs) if labs else pd.DataFrame(columns=["hadm_id", "itemid", "valuenum"])
    lab["name"] = lab["itemid"].map(item_map)
    lab_w = lab.groupby(["hadm_id", "name"])["valuenum"].median().unstack()   # median per admission
    if "troponin" in lab_w:                                                    # peak troponin
        lab_w["troponin"] = lab.query("name == 'troponin'").groupby("hadm_id")["valuenum"].max()

    # ---- outpatient measurements (BMI, BP) from omr ------------------------
    omr = None
    try:
        omr = _read(hosp / "omr.csv", usecols=["subject_id", "chartdate", "result_name", "result_value"],
                    parse_dates=["chartdate"])
    except FileNotFoundError:
        pass

    df = adm.merge(pts, on="subject_id", how="left")
    df["age"] = df["anchor_age"] + (df["admittime"].dt.year - df["anchor_year"])
    df["sex"] = (df["gender"] == "M").astype(float)
    df = df.join(flags, on="hadm_id").join(lab_w, on="hadm_id")

    if omr is not None:
        bp = omr[omr["result_name"].str.startswith("Blood Pressure")].copy()
        sp = bp["result_value"].str.split("/", expand=True)
        bp["sbp"] = pd.to_numeric(sp[0], errors="coerce")
        bp["dbp"] = pd.to_numeric(sp[1], errors="coerce")
        bmi = omr[omr["result_name"].str.startswith("BMI")].copy()
        bmi["bmi"] = pd.to_numeric(bmi["result_value"], errors="coerce")
        df = df.sort_values("admittime")
        for src, cols in [(bp.sort_values("chartdate"), ["sbp", "dbp"]),
                          (bmi.sort_values("chartdate"), ["bmi"])]:
            df = pd.merge_asof(df, src[["subject_id", "chartdate", *cols]], left_on="admittime",
                               right_on="chartdate", by="subject_id", direction="backward",
                               tolerance=pd.Timedelta(days=365)).drop(columns="chartdate")

    for c in ["total_chol", "hdl", "ldl", "triglycerides", "glucose", "hba1c", "creatinine",
              "troponin", "sbp", "dbp", "bmi"]:
        if c not in df:
            df[c] = np.nan

    out = pd.DataFrame({
        "patient_id": "mimic:" + df["subject_id"].astype(str),
        "record_id": "mimic:" + df["hadm_id"].astype(str),
        "source": "mimic",
        "admittime": df["admittime"],
        "age": df["age"], "sex": df["sex"], "bmi": df["bmi"],
        "resting_sbp": df["sbp"], "resting_dbp": df["dbp"],
        "total_chol": df["total_chol"], "ldl": df["ldl"], "hdl": df["hdl"],
        "triglycerides": df["triglycerides"], "fasting_glucose": df["glucose"],
        "hba1c": df["hba1c"], "creatinine": df["creatinine"], "troponin": df["troponin"],
        "diabetes": df["diabetes"],
        "hypertension": ((df["htn_essential"] + df["htn_organ"] + df["htn_crisis"]) > 0).astype(float),
        "htn_severity": np.select([df["htn_crisis"] > 0, df["htn_organ"] > 0, df["htn_essential"] > 0],
                                  [3.0, 2.0, 1.0], 0.0),
        "smoking": df["smoking"], "family_history": df["family_history"],
        "prior_revascularization": ((df["cabg_status"] + df["pci_status"]) > 0).astype(float),
        "vessel_blockage_score": np.select([df["cabg_status"] > 0, df["pci_status"] > 0],
                                           [2 / 3, 1 / 3], np.nan),
        # label-source columns
        "lbl_acs": df["acs"],
        "lbl_cad": ((df["cad"] + df["acs"] + df["prior_mi"]) > 0).astype(float),
        "lbl_prior_mi": df["prior_mi"],
        "lbl_multivessel": df["cabg_status"],
    })
    out = out.sort_values(["patient_id", "admittime"])
    out["time_index"] = out.groupby("patient_id").cumcount()
    return out.drop(columns="admittime").reset_index(drop=True)
