"""Synthetic cohort in the harmonized schema - FOR SMOKE TESTS / CI ONLY.

Numbers produced on this data mean nothing clinically and must never be
reported. It exists so that the full pipeline (harmonize -> split -> swarm ->
train -> SHAP -> treatment support -> metrics -> figures) can be exercised
without credentialed data.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .harmonize import harmonize
from .schema import FEATURES


def make_synthetic_cohort(n_patients: int = 1500, max_visits: int = 6, seed: int = 0,
                          waveform_h5: str | None = None) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    rows = []
    for p in range(n_patients):
        n_vis = int(rng.integers(1, max_visits + 1))
        base = rng.normal(0, 1)
        age0 = rng.uniform(35, 80)
        sex = float(rng.random() < 0.6)
        diabetes = float(rng.random() < 0.25 + 0.1 * (base > 0.5))
        htn = float(rng.random() < 0.35 + 0.15 * (base > 0.0))
        smoke = float(rng.random() < 0.3)
        drift = rng.uniform(0.0, 0.5)
        for t in range(n_vis):
            sev = base + drift * t + 0.4 * diabetes + 0.3 * htn + 0.3 * smoke + rng.normal(0, 0.35)
            vessels = int(np.clip(np.floor((sev + 0.6) / 0.75), 0, 3))
            chol = rng.normal(190 + 22 * sev, 25)
            hdl = np.clip(rng.normal(52 - 4 * sev, 8), 20, 100)
            stdep = max(0.0, rng.normal(0.4 + 0.65 * max(sev, 0), 0.45))
            sbp = rng.normal(125 + 9 * sev + 8 * htn, 12)
            dbp = sbp - rng.normal(45, 8)
            glucose = rng.normal(98 + 25 * diabetes + 5 * sev, 12)
            maxhr = rng.normal(160 - 0.6 * (age0 + 2 * t) * 0.5 - 8 * sev, 12)
            morph = max(0.0, stdep + rng.normal(0.2 * diabetes, 0.3))
            rows.append({
                "patient_id": f"syn:{p}", "record_id": f"syn:{p}:{t}", "source": "synthetic",
                "time_index": t, "age": age0 + 2 * t, "sex": sex, "bmi": rng.normal(27 + sev, 4),
                "smoking": smoke, "family_history": float(rng.random() < 0.2 + 0.1 * (base > 0)),
                "resting_sbp": sbp, "resting_dbp": dbp, "resting_hr": rng.normal(72 + 3 * sev, 9),
                "max_hr": maxhr, "total_chol": chol, "ldl": chol * 0.62 + rng.normal(0, 8),
                "hdl": hdl, "triglycerides": rng.normal(140 + 25 * sev, 35),
                "fasting_glucose": glucose, "hba1c": rng.normal(5.6 + 1.2 * diabetes, 0.4),
                "diabetes": diabetes, "creatinine": rng.normal(0.95 + 0.08 * sev, 0.15),
                "hypertension": htn, "htn_severity": float(htn * rng.integers(1, 4)),
                "chest_pain_type": float(np.clip(4 - vessels + rng.integers(-1, 2), 1, 4)),
                "exercise_angina": float(rng.random() < 0.15 + 0.15 * vessels),
                "troponin": abs(rng.normal(0.01 + 0.05 * (sev > 2.0), 0.01)),
                "prior_revascularization": float(t > 0 and vessels >= 2 and rng.random() < 0.3),
                "num_vessels": float(np.clip(vessels + rng.integers(-1, 2) * (rng.random() < 0.2), 0, 3)),
                "thal": float(rng.choice([0, 1, 2], p=[0.6 - 0.1 * min(vessels, 3), 0.1, 0.3 + 0.1 * min(vessels, 3)])),
                "vessel_blockage_score": float(np.clip(vessels / 3 + rng.normal(0, 0.08), 0, 1)),
                "restecg": float(rng.choice([0, 1, 2], p=[0.6, 0.3, 0.1])),
                "st_depression": stdep, "st_slope": float(np.clip(round(stdep), 0, 2)),
                "st_elevation": float(sev > 2.6 and rng.random() < 0.5),
                "qrs_duration": rng.normal(92 + 3 * sev, 9), "pr_interval": rng.normal(160, 18),
                "qtc": rng.normal(420 + 6 * sev, 18), "t_wave_amp": rng.normal(2.5 - 0.8 * sev, 0.8),
                "ecg_morphology_index": morph, "ischemic_ecg_flag": float(stdep >= 1.0),
                "lvh_flag": float(rng.random() < 0.08 + 0.05 * htn), "rhythm_abnormal": float(rng.random() < 0.08),
                "hrv_sdnn": abs(rng.normal(45 - 5 * sev, 12)),
                "lbl_vessels": float(vessels), "lbl_cad": float(vessels > 0),
                "lbl_acs": float(sev > 2.9 and rng.random() < 0.6),
            })
    df = pd.DataFrame(rows)
    # sprinkle 3 % missingness
    feat = [f for f in FEATURES if f in df]
    mask = rng.random((len(df), len(feat))) < 0.03
    df[feat] = df[feat].mask(mask)

    if waveform_h5:
        import h5py
        with h5py.File(waveform_h5, "w") as f:
            tt = np.arange(1000) / 100.0
            for _, r in df.iterrows():
                hr = r["resting_hr"] if pd.notna(r["resting_hr"]) else 72
                beat = np.sin(2 * np.pi * hr / 60 * tt) ** 21
                st = -0.1 * (r["st_depression"] if pd.notna(r["st_depression"]) else 0)
                w = beat + st * (np.sin(2 * np.pi * hr / 60 * tt - 0.6) > 0.7) + rng.normal(0, 0.05, 1000)
                f.create_dataset(r["record_id"], data=w.astype(np.float32))
    return harmonize([df], max_missing_fraction=0.25)
