"""Harmonized 42-attribute cardiovascular schema (Section 3.1).

The schema stores the harmonized *predictors*. The derived ordinal target and the
label-source columns (prefixed ``lbl_``) are kept in separate columns and are
NEVER used as model inputs (see ``LABEL_COLUMNS``).

If your harmonization used a different attribute list, edit ``FEATURES`` here;
every other module reads the list from this file.
"""
from __future__ import annotations

# ---------------------------------------------------------------------------
# 42 harmonized predictors, grouped by clinical domain
# ---------------------------------------------------------------------------
DEMOGRAPHIC = ["age", "sex", "bmi", "smoking", "family_history"]                       # 5
VITALS = ["resting_sbp", "resting_dbp", "resting_hr", "max_hr", "pulse_pressure"]       # 5
LIPIDS = ["total_chol", "ldl", "hdl", "triglycerides", "chol_ratio"]                   # 5
GLYCAEMIC_RENAL = ["fasting_glucose", "fbs_gt120", "hba1c", "diabetes", "creatinine"]  # 5
CLINICAL = ["hypertension", "htn_severity", "chest_pain_type", "exercise_angina",
            "troponin", "prior_revascularization"]                                     # 6
VESSEL = ["num_vessels", "thal", "vessel_blockage_score"]                              # 3
ECG = ["restecg", "st_depression", "st_slope", "st_elevation", "qrs_duration",
       "pr_interval", "qtc", "t_wave_amp", "ecg_morphology_index", "ischemic_ecg_flag",
       "lvh_flag", "rhythm_abnormal", "hrv_sdnn"]                                     # 13

FEATURES: list[str] = DEMOGRAPHIC + VITALS + LIPIDS + GLYCAEMIC_RENAL + CLINICAL + VESSEL + ECG
assert len(FEATURES) == 42, len(FEATURES)
FEATURE_INDEX = {f: i for i, f in enumerate(FEATURES)}

BINARY_FEATURES = {"sex", "smoking", "family_history", "fbs_gt120", "diabetes", "hypertension",
                   "exercise_angina", "prior_revascularization", "ischemic_ecg_flag",
                   "lvh_flag", "rhythm_abnormal"}

# Identifier / bookkeeping columns of the harmonized table
ID_COLUMNS = ["record_id", "patient_id", "source", "time_index"]

# Label-source columns (never model inputs)
LABEL_COLUMNS = ["lbl_cad", "lbl_vessels", "lbl_acs", "lbl_left_main",
                 "lbl_multivessel", "lbl_prior_mi", "lbl_stenosis_intermediate"]
TARGET = "stage"            # 0 low, 1 moderate, 2 high, 3 critical
STAGE_NAMES = ["low", "moderate", "high", "critical"]
BINARY_TARGET = "cad"       # 1 if stage >= 1 (documented CAD burden)

# Features each source can genuinely supply. Features outside this list are
# *structurally* missing for that source; they are imputed but do not count
# towards the ">10 % missing => discard" rule (Section 3.1).
SOURCE_FEATURES: dict[str, list[str]] = {
    "uci": ["age", "sex", "chest_pain_type", "resting_sbp", "total_chol", "fbs_gt120",
            "restecg", "max_hr", "exercise_angina", "st_depression", "st_slope",
            "num_vessels", "thal", "vessel_blockage_score"],
    "ptbxl": ["age", "sex", "bmi", "resting_hr", "st_depression", "st_elevation", "qrs_duration",
              "pr_interval", "qtc", "t_wave_amp", "ecg_morphology_index", "ischemic_ecg_flag",
              "lvh_flag", "rhythm_abnormal", "hrv_sdnn", "restecg", "st_slope"],
    "mimic": ["age", "sex", "bmi", "resting_sbp", "resting_dbp", "resting_hr", "pulse_pressure",
              "total_chol", "ldl", "hdl", "triglycerides", "chol_ratio", "fasting_glucose",
              "fbs_gt120", "hba1c", "diabetes", "creatinine", "hypertension", "htn_severity",
              "troponin", "prior_revascularization", "smoking"],
    "synthetic": FEATURES,
}

# Physiology-constrained biomarker pairs for the hyperscalar feature cross
# (Section 3.2, design choice (i)). Edit in configs/*.yaml -> model.clinical_pairs.
DEFAULT_CLINICAL_PAIRS = [
    ("chol_ratio", "vessel_blockage_score"),
    ("st_depression", "max_hr"),
    ("diabetes", "ecg_morphology_index"),
]

# Pairs used by the "Dependency Preservation" diagnostic (Section 3.8.2 (3))
DEPENDENCY_PAIRS = [("chol_ratio", "vessel_blockage_score"), ("st_depression", "max_hr")]

# Human-readable names used in SHAP plots / Table 7
DISPLAY_NAMES = {
    "chol_ratio": "Cholesterol Ratio", "st_depression": "ST Depression",
    "vessel_blockage_score": "Vessel Blockage Score", "diabetes": "Diabetes Status",
    "resting_sbp": "Blood Pressure", "max_hr": "Maximum Heart Rate",
    "ecg_morphology_index": "ECG Morphology", "chest_pain_type": "Chest Pain Type",
    "age": "Age", "smoking": "Smoking Status", "fasting_glucose": "Fasting Blood Sugar",
    "num_vessels": "Number of Vessels", "total_chol": "Total Cholesterol", "htn_severity": "Hypertension Severity",
}


def display(name: str) -> str:
    return DISPLAY_NAMES.get(name, name.replace("_", " ").title())
