"""Fold-safe preprocessing (Section 3.1, Eqs. 1-3).

Every statistic (mean, sd, min, max, imputation neighbours) is fitted on the
training partition / fold only and then applied to validation and test data.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.impute import KNNImputer


class Preprocessor:
    """z-score (Eq. 1) or min-max (Eq. 2) scaling + neighbourhood-average imputation (Eq. 3).

    Imputation is performed in the scaled space with a KNN imputer, i.e. a missing
    value is replaced by the mean of that attribute over the N nearest complete
    neighbours (Eq. 3). Outliers are clipped to +/- ``clip`` after scaling.
    """

    def __init__(self, features: list[str], scaling: str = "zscore", knn_neighbors: int = 5,
                 clip: float = 6.0, max_impute_fit: int = 20000, seed: int = 0):
        assert scaling in {"zscore", "minmax"}
        self.features, self.scaling, self.k, self.clip = features, scaling, knn_neighbors, clip
        self.max_impute_fit, self.seed = max_impute_fit, seed

    def fit(self, df: pd.DataFrame) -> "Preprocessor":
        X = df[self.features].to_numpy(dtype=float)
        if self.scaling == "zscore":
            self.a_ = np.nanmean(X, axis=0)
            self.b_ = np.nanstd(X, axis=0)
        else:
            self.a_ = np.nanmin(X, axis=0)
            self.b_ = np.nanmax(X, axis=0) - self.a_
        self.a_ = np.nan_to_num(self.a_)
        self.b_ = np.where(~np.isfinite(self.b_) | (self.b_ < 1e-8), 1.0, self.b_)
        Z = self._scale(X)
        if len(Z) > self.max_impute_fit:     # cap neighbour bank for speed
            idx = np.random.default_rng(self.seed).choice(len(Z), self.max_impute_fit, replace=False)
            Z = Z[idx]
        self.imputer_ = KNNImputer(n_neighbors=self.k, keep_empty_features=True).fit(Z)
        return self

    def _scale(self, X):
        Z = (X - self.a_) / self.b_
        return np.clip(Z, -self.clip, self.clip) if self.scaling == "zscore" else Z

    def transform(self, df: pd.DataFrame) -> np.ndarray:
        Z = self._scale(df[self.features].to_numpy(dtype=float))
        Z = self.imputer_.transform(Z)
        return np.nan_to_num(Z).astype(np.float32)

    def inverse(self, Z: np.ndarray) -> np.ndarray:
        return Z * self.b_ + self.a_


def missing_report(df: pd.DataFrame, features: list[str]) -> pd.DataFrame:
    return (df.groupby("source")[features].apply(lambda g: g.isna().mean() * 100).T.round(1))
