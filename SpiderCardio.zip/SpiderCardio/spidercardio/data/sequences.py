"""Longitudinal sample construction.

One supervised sample per harmonized record: the record plus up to ``T-1``
previous records of the same patient (left-padded, right-aligned). The target is
the stage of the *last* record. Single-visit sources (e.g. UCI) yield sequences
of length 1. Patient-level grouping in ``splits.py`` guarantees that later time
points of a patient never leak into another partition / fold.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset

from .schema import BINARY_TARGET, TARGET


@dataclass
class SequenceData:
    X: np.ndarray            # (N, T, F) float32
    mask: np.ndarray         # (N, T) bool, True = observed step
    y: np.ndarray            # (N,) int stage 0..3
    cad: np.ndarray          # (N,) int binary CAD
    prev_y: np.ndarray       # (N,) int stage of previous record, -1 if none
    patient_id: np.ndarray
    record_id: np.ndarray
    source: np.ndarray
    wave: np.ndarray | None = None        # (N, L) float32 waveform for baselines
    meta: dict = field(default_factory=dict)

    def __len__(self):
        return len(self.y)

    def subset(self, idx) -> "SequenceData":
        idx = np.asarray(idx)
        return SequenceData(self.X[idx], self.mask[idx], self.y[idx], self.cad[idx], self.prev_y[idx],
                            self.patient_id[idx], self.record_id[idx], self.source[idx],
                            None if self.wave is None else self.wave[idx], dict(self.meta))

    def select_features(self, cols) -> "SequenceData":
        out = self.subset(np.arange(len(self)))
        out.X = self.X[:, :, cols]
        return out

    @property
    def last(self) -> np.ndarray:
        """Features of the target (last) record, shape (N, F)."""
        return self.X[:, -1, :]

    def with_seq_len(self, T: int) -> "SequenceData":
        out = self.subset(np.arange(len(self)))
        out.X, out.mask = self.X[:, -T:, :], self.mask[:, -T:]
        return out


def build_sequences(df: pd.DataFrame, Z: np.ndarray, max_len: int,
                    waveform_h5: str | None = None, wave_len: int = 1000) -> SequenceData:
    """``df`` rows must align with the scaled feature matrix ``Z`` (same order)."""
    df = df.reset_index(drop=True)
    order = df.sort_values(["patient_id", "time_index"]).index.to_numpy()
    N, F = len(df), Z.shape[1]
    X = np.zeros((N, max_len, F), dtype=np.float32)
    M = np.zeros((N, max_len), dtype=bool)
    prev = np.full(N, -1, dtype=int)
    pid = df["patient_id"].to_numpy()
    stages = df[TARGET].to_numpy()
    start = 0
    while start < N:
        p = pid[order[start]]
        end = start
        while end < N and pid[order[end]] == p:
            end += 1
        rows = order[start:end]
        for k, r in enumerate(rows):
            hist = rows[max(0, k - max_len + 1): k + 1]
            X[r, max_len - len(hist):] = Z[hist]
            M[r, max_len - len(hist):] = True
            if k > 0:
                prev[r] = stages[rows[k - 1]]
        start = end

    wave = None
    if waveform_h5:
        import h5py
        wave = np.zeros((N, wave_len), dtype=np.float32)
        with h5py.File(waveform_h5, "r") as f:
            for i, rid in enumerate(df["record_id"]):
                if rid in f:
                    w = f[rid][:wave_len]
                    wave[i, : len(w)] = (w - w.mean()) / (w.std() + 1e-6)   # z-scored segment
    return SequenceData(X, M, stages.astype(int), df[BINARY_TARGET].to_numpy().astype(int), prev,
                        pid, df["record_id"].to_numpy(), df["source"].to_numpy(), wave)


class TorchSequenceDataset(Dataset):
    def __init__(self, data: SequenceData):
        self.d = data

    def __len__(self):
        return len(self.d)

    def __getitem__(self, i):
        item = {"x": torch.from_numpy(self.d.X[i]), "mask": torch.from_numpy(self.d.mask[i]),
                "y": torch.tensor(self.d.y[i], dtype=torch.long)}
        if self.d.wave is not None:
            item["wave"] = torch.from_numpy(self.d.wave[i])
        return item
