"""Patient-level 70/15/15 split and stratified grouped 10-fold CV (Sections 3.1, 3.7)."""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedGroupKFold, train_test_split

from .schema import TARGET


def patient_split(df: pd.DataFrame, fractions=(0.70, 0.15, 0.15), seed: int = 42) -> pd.Series:
    """Return a Series (aligned with df) with values 'train' / 'val' / 'test'.

    Patients are stratified by their *maximum* stage, so every partition keeps the
    natural class mix (Table 2) and no patient appears in two partitions.
    """
    assert abs(sum(fractions) - 1) < 1e-6
    pat = df.groupby("patient_id")[TARGET].max()
    tr, rest = train_test_split(pat.index, train_size=fractions[0], stratify=pat.values, random_state=seed)
    rel = fractions[1] / (fractions[1] + fractions[2])
    va, te = train_test_split(rest, train_size=rel, stratify=pat.loc[rest].values, random_state=seed)
    lut = {**{p: "train" for p in tr}, **{p: "val" for p in va}, **{p: "test" for p in te}}
    return df["patient_id"].map(lut)


def grouped_cv_folds(y: np.ndarray, groups: np.ndarray, n_splits: int = 10, seed: int = 42):
    """Stratified (on CAD stage) and grouped (by patient) K-fold over the development set."""
    sgkf = StratifiedGroupKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    return list(sgkf.split(np.zeros(len(y)), y, groups))


def save_split_ids(df: pd.DataFrame, split: pd.Series, out_dir: str | Path) -> None:
    """Write record identifiers per partition (released with the paper; no data values)."""
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    for part in ["train", "val", "test"]:
        df.loc[split == part, ["record_id", "patient_id", "source", TARGET]].to_csv(
            out / f"{part}_ids.csv", index=False)


def assert_no_patient_leakage(*id_arrays) -> None:
    sets = [set(a) for a in id_arrays]
    for i in range(len(sets)):
        for j in range(i + 1, len(sets)):
            inter = sets[i] & sets[j]
            assert not inter, f"patient leakage between partitions {i} and {j}: {list(inter)[:5]}"
