"""Schema harmonization, record-quality filtering and derived labelling (Section 3.1)."""
from __future__ import annotations

import logging

import numpy as np
import pandas as pd

from .labeling import binary_cad, derive_stage
from .schema import FEATURES, ID_COLUMNS, LABEL_COLUMNS, SOURCE_FEATURES, TARGET, BINARY_TARGET

log = logging.getLogger(__name__)


def add_derived_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    if {"total_chol", "hdl"} <= set(df):
        ratio = df["total_chol"] / df["hdl"].replace(0, np.nan)
        df["chol_ratio"] = df["chol_ratio"].fillna(ratio) if "chol_ratio" in df else ratio
    if {"resting_sbp", "resting_dbp"} <= set(df):
        pp = df["resting_sbp"] - df["resting_dbp"]
        df["pulse_pressure"] = df["pulse_pressure"].fillna(pp) if "pulse_pressure" in df else pp
    if "fasting_glucose" in df:
        g = (df["fasting_glucose"] > 120).astype(float).where(df["fasting_glucose"].notna())
        df["fbs_gt120"] = df["fbs_gt120"].fillna(g) if "fbs_gt120" in df else g
    if "resting_sbp" in df and "htn_severity" in df:
        # fall back to a BP-based severity grade where no coded severity exists
        bp_grade = pd.cut(df["resting_sbp"], [-np.inf, 130, 140, 160, np.inf], labels=[0, 1, 2, 3]).astype(float)
        df["htn_severity"] = df["htn_severity"].fillna(bp_grade)
    return df


def harmonize(frames: list[pd.DataFrame], label_rules: dict | None = None,
              max_missing_fraction: float = 0.10) -> pd.DataFrame:
    """Concatenate source frames into the common schema and attach the derived target.

    * Missing predictors that a source *can* supply are counted; a record is discarded
      when more than ``max_missing_fraction`` of them are missing (corrupted record).
    * Structurally unavailable predictors stay NaN and are imputed later inside each
      training fold (no leakage).
    * Records that the ordinal rule cannot assign are excluded from supervised staging.
    """
    df = pd.concat(frames, ignore_index=True, sort=False)
    for c in FEATURES + LABEL_COLUMNS:
        if c not in df:
            df[c] = np.nan
    df = add_derived_features(df)

    keep = np.ones(len(df), dtype=bool)
    for src, idx in df.groupby("source").groups.items():
        avail = [f for f in SOURCE_FEATURES.get(src, FEATURES) if f in df]
        frac = df.loc[idx, avail].isna().mean(axis=1)
        bad = frac > max_missing_fraction
        keep[df.index.get_indexer(idx[bad.values])] = False
        log.info("source=%s records=%d discarded(>%.0f%% missing)=%d", src, len(idx),
                 100 * max_missing_fraction, int(bad.sum()))
    df = df[keep].copy()

    df[TARGET] = derive_stage(df, label_rules)
    n_unassigned = int(df[TARGET].isna().sum())
    df = df[df[TARGET].notna()].copy()
    df[TARGET] = df[TARGET].astype(int)
    df[BINARY_TARGET] = binary_cad(df[TARGET])
    log.info("unassignable records excluded: %d ; final cohort: %d", n_unassigned, len(df))

    # re-index time within patient after exclusions
    df = df.sort_values(["patient_id", "time_index"])
    df["time_index"] = df.groupby("patient_id").cumcount()
    cols = ID_COLUMNS + FEATURES + LABEL_COLUMNS + [TARGET, BINARY_TARGET]
    return df[cols].reset_index(drop=True)


def stage_distribution(df: pd.DataFrame, by: str | None = None) -> pd.DataFrame:
    """Table 2 helper: counts and percentages per stage (optionally per partition)."""
    from .schema import STAGE_NAMES
    g = [by] if by else []
    t = df.groupby(g + [TARGET]).size().unstack(fill_value=0) if by else \
        df[TARGET].value_counts().sort_index().to_frame().T
    t.columns = [STAGE_NAMES[int(c)] for c in t.columns]
    t["total"] = t.sum(axis=1)
    pct = t[STAGE_NAMES].div(t["total"], axis=0) * 100
    return t.join(pct.add_suffix("_pct").round(2))
