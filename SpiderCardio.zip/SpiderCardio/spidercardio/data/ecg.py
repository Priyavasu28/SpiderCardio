"""ECG denoising (Eq. 4) and ECG-derived descriptors for the harmonized schema.

* Adaptive wavelet filtering: multilevel DWT; the deepest approximation band is
  removed (baseline drift) and detail bands are soft-thresholded with the
  universal (VisuShrink) threshold estimated from the median absolute deviation,
  so that QRS and ST-segment morphology are retained (Section 3.1).
  Reconstruction follows S(t) = A(t) + D(t).
* Simple, dependency-light delineation (R peaks, J point, PR baseline) produces
  heart rate, HRV (SDNN), QRS duration, PR interval, QTc, ST deviation at J+60 ms,
  T-wave amplitude and a scalar ECG morphology index.

The delineator is deliberately transparent rather than state of the art; swap in
NeuroKit2 / PTB-XL+ features if you have them (see docs/DATA.md).
"""
from __future__ import annotations

import numpy as np
import pywt
from scipy.signal import butter, filtfilt, find_peaks

PTBXL_LEADS = ["I", "II", "III", "AVR", "AVL", "AVF", "V1", "V2", "V3", "V4", "V5", "V6"]


def wavelet_denoise(sig: np.ndarray, fs: int = 500, wavelet: str = "db6",
                    level: int | None = None, remove_baseline: bool = True) -> np.ndarray:
    """Denoise a 1-D ECG signal. Returns an array of the same length."""
    sig = np.asarray(sig, dtype=float)
    if level is None:
        # deepest level whose approximation band is below ~0.5 Hz (baseline wander)
        level = int(np.clip(np.floor(np.log2(fs / 0.5)) - 1, 1,
                            pywt.dwt_max_level(len(sig), pywt.Wavelet(wavelet).dec_len)))
    coeffs = pywt.wavedec(sig, wavelet, level=level)
    sigma = np.median(np.abs(coeffs[-1])) / 0.6745 + 1e-12
    thr = sigma * np.sqrt(2 * np.log(len(sig)))
    out = [np.zeros_like(coeffs[0]) if remove_baseline else coeffs[0]]          # A(t)
    out += [pywt.threshold(c, thr, mode="soft") for c in coeffs[1:]]           # D(t)
    rec = pywt.waverec(out, wavelet)
    return rec[: len(sig)]


def denoise_12lead(x: np.ndarray, fs: int = 500) -> np.ndarray:
    """x: (n_samples, n_leads)."""
    return np.stack([wavelet_denoise(x[:, i], fs) for i in range(x.shape[1])], axis=1)


def _bandpass(sig, fs, lo=5.0, hi=15.0):
    b, a = butter(2, [lo / (fs / 2), hi / (fs / 2)], btype="band")
    return filtfilt(b, a, sig)


def detect_r_peaks(sig: np.ndarray, fs: int) -> np.ndarray:
    """Pan-Tompkins-style detector (band-pass, derivative, squaring, integration)."""
    f = _bandpass(sig, fs)
    d = np.gradient(f) ** 2
    win = max(1, int(0.15 * fs))
    integ = np.convolve(d, np.ones(win) / win, mode="same")
    peaks, _ = find_peaks(integ, height=0.35 * np.percentile(integ, 99), distance=int(0.3 * fs))
    # refine to local maximum of |signal|
    half = int(0.05 * fs)
    refined = []
    for p in peaks:
        lo, hi = max(0, p - half), min(len(sig), p + half)
        refined.append(lo + int(np.argmax(np.abs(sig[lo:hi]))))
    return np.unique(np.array(refined, dtype=int))


def ecg_features(x: np.ndarray, fs: int = 500, rhythm_lead: int = 1, st_lead: int = 10) -> dict:
    """Extract ECG-derived descriptors from a denoised (n_samples, n_leads) array.

    ST deviation is measured in the V5 lead (index 10) at J+60 ms relative to the
    PR-segment isoelectric level; amplitudes are returned in millimetres
    (1 mV = 10 mm). ``st_depression`` is the positive magnitude of a negative
    deviation, ``st_elevation`` a binary flag (>= 1 mm).
    """
    nan = float("nan")
    out = {k: nan for k in ["resting_hr", "hrv_sdnn", "qrs_duration", "pr_interval", "qtc",
                            "st_depression", "st_elevation", "t_wave_amp", "ecg_morphology_index",
                            "st_slope", "rhythm_abnormal"]}
    sig = x[:, rhythm_lead]
    r = detect_r_peaks(sig, fs)
    if len(r) < 3:
        return out
    rr = np.diff(r) / fs
    hr = 60.0 / np.median(rr)
    out["resting_hr"] = float(hr)
    out["hrv_sdnn"] = float(np.std(rr) * 1000)
    out["rhythm_abnormal"] = float(np.std(rr) / np.mean(rr) > 0.15 or hr < 50 or hr > 100)

    st = x[:, st_lead]
    ms = lambda v: int(v * fs / 1000)  # noqa: E731
    beats = [p for p in r if p - ms(250) > 0 and p + ms(450) < len(st)]
    if not beats:
        return out
    seg = np.stack([st[p - ms(250): p + ms(450)] for p in beats])
    tmpl = np.median(seg, axis=0)                      # median beat
    rp = ms(250)
    base = np.median(tmpl[rp - ms(120): rp - ms(60)])  # PR isoelectric level
    # J point: first point after R where slope flattens
    slope = np.abs(np.gradient(tmpl))
    search = slope[rp + ms(20): rp + ms(120)]
    j = rp + ms(20) + int(np.argmax(search < 0.15 * slope[rp - ms(40): rp + ms(40)].max()))
    st60 = tmpl[min(j + ms(60), len(tmpl) - 1)] - base
    mm = 10.0  # mV -> mm
    out["st_depression"] = float(max(0.0, -st60 * mm))
    out["st_elevation"] = float(st60 * mm >= 1.0)
    st80 = tmpl[min(j + ms(80), len(tmpl) - 1)] - base
    sl = (st80 - (tmpl[j] - base)) * mm
    out["st_slope"] = float(0 if sl > 0.2 else (1 if abs(sl) <= 0.2 else 2))  # up/flat/down
    t_win = tmpl[j + ms(100): min(len(tmpl), j + ms(350))]
    if len(t_win):
        t_idx = int(np.argmax(np.abs(t_win - base)))
        out["t_wave_amp"] = float((t_win[t_idx] - base) * mm)
        t_end = j + ms(100) + t_idx + ms(80)
        qt = (t_end - (rp - ms(40))) / fs
        out["qtc"] = float(1000 * qt / np.sqrt(np.median(rr)))      # Bazett, ms
    q_on = rp - ms(40) + int(np.argmax(slope[rp - ms(60): rp] > 0.15 * slope.max()))
    out["qrs_duration"] = float(1000 * (j - q_on) / fs)
    pw = tmpl[max(0, rp - ms(250)): rp - ms(80)]
    if len(pw):
        p_peak = max(0, rp - ms(250)) + int(np.argmax(pw))
        out["pr_interval"] = float(1000 * (q_on - p_peak + ms(40)) / fs)
    # Morphology index: z-combination of ST deviation, T inversion and QRS widening
    out["ecg_morphology_index"] = float(
        out["st_depression"] + max(0.0, -out["t_wave_amp"]) * 0.5
        + max(0.0, (out["qrs_duration"] - 100) / 20.0))
    return out
