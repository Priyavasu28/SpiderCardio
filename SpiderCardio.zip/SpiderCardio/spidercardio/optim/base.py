"""Shared bookkeeping for population-based optimizers (Spider-Swarm and comparators)."""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from .search_space import SearchSpace

log = logging.getLogger(__name__)


@dataclass
class OptimResult:
    best_mask: np.ndarray
    best_theta: np.ndarray
    best_fitness: float
    best_hyper: dict
    selected_features: list[str]
    history: pd.DataFrame
    n_evaluations: int
    wall_time_s: float
    extra: dict = field(default_factory=dict)


class PopulationOptimizer:
    name = "base"

    def __init__(self, space: SearchSpace, fitness_fn, n_agents: int = 40, n_iter: int = 120,
                 seed: int = 0, convergence_patience: int | None = 30, init_theta: np.ndarray | None = None,
                 log_every: int = 10):
        self.space, self.fitness_fn = space, fitness_fn
        self.A, self.T = n_agents, n_iter
        self.rng = np.random.default_rng(seed)
        self.patience = convergence_patience
        self.init_theta = init_theta
        self.log_every = log_every
        self._cache: dict = {}
        self.n_evals = 0

    # --------------------------------------------------------------
    def init_population(self):
        d, h = self.space.d, self.space.h
        B = (self.rng.random((self.A, d)) < self.rng.uniform(0.5, 0.95, (self.A, 1))).astype(int)
        B[0] = 1                                         # one agent starts from the full feature set
        B = np.stack([self.space.repair(b, self.rng) for b in B])
        Th = self.rng.random((self.A, h))
        if self.init_theta is not None:
            Th[0] = self.init_theta
        return B, Th

    def evaluate(self, b: np.ndarray, theta: np.ndarray) -> float:
        hyper = self.space.decode(theta)
        key = (b.tobytes(), tuple(sorted((k, str(v) if isinstance(v, str) else round(float(v), 6))
                                         for k, v in hyper.items())))
        if key not in self._cache:
            self._cache[key] = float(self.fitness_fn(b.astype(bool), hyper))
            self.n_evals += 1
        return self._cache[key]

    @staticmethod
    def convergence_rate(B, Th, b_best, th_best) -> float:
        """Swarm consensus in [0,1]: 1 - mean normalised L1 distance of agents to the global best.
        (Definition used for the 'Convergence Rate' column of Table 3.)"""
        dist = np.abs(B - b_best).mean(1) * B.shape[1] + np.abs(Th - th_best).mean(1) * Th.shape[1]
        return float(1 - dist.mean() / (B.shape[1] + Th.shape[1]))

    def run(self) -> OptimResult:  # pragma: no cover - implemented by subclasses
        raise NotImplementedError

    def _result(self, b, th, f, hist, t0, **extra) -> OptimResult:
        return OptimResult(b.astype(int), th, f, self.space.decode(th), self.space.selected(b),
                           pd.DataFrame(hist), self.n_evals, time.perf_counter() - t0, extra)

    def _log(self, it, f, b):
        if self.log_every and (it % self.log_every == 0 or it == 1):
            log.info("[%s] iter %3d  best fitness %.4f  features %d", self.name, it, f, int(b.sum()))
