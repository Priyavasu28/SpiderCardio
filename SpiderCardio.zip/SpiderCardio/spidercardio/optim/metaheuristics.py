"""Comparator meta-heuristics with the identical mixed encoding and budget
(40 agents x 120 iterations; Section 4.1 supplementary experiments).

* PSO  - binary PSO with sigmoid transfer + standard continuous PSO.
* GA   - tournament selection, uniform crossover, bit-flip / Gaussian mutation, elitism.
* GWO  - Grey Wolf Optimizer (alpha/beta/delta leaders), sigmoid transfer for bits.
* ACO  - pheromone vector on attributes (binary) + ACO_R Gaussian kernel (continuous).
"""
from __future__ import annotations

import time

import numpy as np

from .base import OptimResult, PopulationOptimizer


def _sig(x):
    return 1 / (1 + np.exp(-x))


class _Loop(PopulationOptimizer):
    def step(self, B, Th, F, ctx, t):  # pragma: no cover
        raise NotImplementedError

    def run(self) -> OptimResult:
        t0 = time.perf_counter()
        B, Th = self.init_population()
        F = np.array([self.evaluate(B[i], Th[i]) for i in range(self.A)])
        g = int(np.argmax(F))
        GB, GTh, GF = B[g].copy(), Th[g].copy(), F[g]
        ctx = {"PB": B.copy(), "PTh": Th.copy(), "PF": F.copy(), "VB": np.zeros(B.shape), "VTh": np.zeros(Th.shape)}
        hist, stag = [], 0
        for t in range(1, self.T + 1):
            ctx.update(GB=GB, GTh=GTh, GF=GF)
            B, Th = self.step(B, Th, F, ctx, t)
            B = np.stack([self.space.repair(b, self.rng) for b in B])
            Th = np.clip(Th, 0, 1)
            F = np.array([self.evaluate(B[i], Th[i]) for i in range(self.A)])
            imp = F > ctx["PF"]
            ctx["PB"][imp], ctx["PTh"][imp], ctx["PF"][imp] = B[imp], Th[imp], F[imp]
            g = int(np.argmax(F))
            if F[g] > GF + 1e-9:
                GB, GTh, GF, stag = B[g].copy(), Th[g].copy(), F[g], 0
            else:
                stag += 1
            hist.append({"iteration": t, "best_fitness": GF, "mean_fitness": float(F.mean()),
                         "selected_features": int(GB.sum()),
                         "convergence_rate": self.convergence_rate(B, Th, GB, GTh), "evaluations": self.n_evals})
            self._log(t, GF, GB)
            if self.patience and stag >= self.patience:
                break
        return self._result(GB, GTh, GF, hist, t0)


class PSOOptimizer(_Loop):
    name = "pso"

    def __init__(self, *a, w=0.72, c1=1.49, c2=1.49, **k):
        super().__init__(*a, **k)
        self.w, self.c1, self.c2 = w, c1, c2

    def step(self, B, Th, F, ctx, t):
        r1, r2 = self.rng.random(B.shape), self.rng.random(B.shape)
        ctx["VB"] = np.clip(self.w * ctx["VB"] + self.c1 * r1 * (ctx["PB"] - B) + self.c2 * r2 * (ctx["GB"] - B), -4, 4)
        B = (self.rng.random(B.shape) < _sig(ctx["VB"])).astype(int)
        r1, r2 = self.rng.random(Th.shape), self.rng.random(Th.shape)
        ctx["VTh"] = self.w * ctx["VTh"] + self.c1 * r1 * (ctx["PTh"] - Th) + self.c2 * r2 * (ctx["GTh"] - Th)
        return B, Th + ctx["VTh"]


class GAOptimizer(_Loop):
    name = "ga"

    def __init__(self, *a, p_cx=0.9, p_mut_bit=None, sigma=0.1, elite=2, tournament=3, **k):
        super().__init__(*a, **k)
        self.p_cx, self.p_mut = p_cx, p_mut_bit
        self.sigma, self.elite, self.tk = sigma, elite, tournament

    def _pick(self, F):
        c = self.rng.choice(len(F), self.tk, replace=False)
        return c[np.argmax(F[c])]

    def step(self, B, Th, F, ctx, t):
        pm = self.p_mut or 1.0 / B.shape[1]
        order = np.argsort(-F)
        nB, nTh = [B[i].copy() for i in order[: self.elite]], [Th[i].copy() for i in order[: self.elite]]
        while len(nB) < self.A:
            a, b = self._pick(F), self._pick(F)
            if self.rng.random() < self.p_cx:
                m = self.rng.random(B.shape[1]) < 0.5
                cb = np.where(m, B[a], B[b])
                al = self.rng.random(Th.shape[1])
                ct = al * Th[a] + (1 - al) * Th[b]
            else:
                cb, ct = B[a].copy(), Th[a].copy()
            flip = self.rng.random(B.shape[1]) < pm
            cb[flip] = 1 - cb[flip]
            ct = ct + self.rng.normal(0, self.sigma, ct.shape) * (self.rng.random(ct.shape) < 0.3)
            nB.append(cb)
            nTh.append(ct)
        return np.stack(nB), np.stack(nTh)


class GWOOptimizer(_Loop):
    name = "gwo"

    def step(self, B, Th, F, ctx, t):
        a = 2 - 2 * t / self.T
        lead = np.argsort(-F)[:3]
        pos = np.concatenate([B, Th], 1).astype(float)
        new = np.zeros_like(pos)
        for l in lead:
            A_ = 2 * a * self.rng.random(pos.shape) - a
            C = 2 * self.rng.random(pos.shape)
            D = np.abs(C * pos[l] - pos)
            new += pos[l] - A_ * D
        new /= 3
        d = B.shape[1]
        Bn = (self.rng.random(B.shape) < _sig(10 * (new[:, :d] - 0.5))).astype(int)
        return Bn, new[:, d:]


class ACOOptimizer(_Loop):
    name = "aco"

    def __init__(self, *a, rho=0.1, q=0.5, xi=0.85, **k):
        super().__init__(*a, **k)
        self.rho, self.q, self.xi = rho, q, xi
        self.tau = None

    def step(self, B, Th, F, ctx, t):
        if self.tau is None:
            self.tau = np.full(B.shape[1], 0.5)
        rank = np.argsort(-F)
        w = np.exp(-(np.arange(self.A) ** 2) / (2 * (self.q * self.A) ** 2))
        w = w / w.sum()
        self.tau = (1 - self.rho) * self.tau + self.rho * (w[:, None] * B[rank]).sum(0)
        Bn = (self.rng.random(B.shape) < np.clip(self.tau, 0.05, 0.95)).astype(int)
        # ACO_R: sample around archive members chosen by rank weight
        archive = Th[rank]
        sd = self.xi * np.abs(archive[:, None, :] - archive[None, :, :]).mean(1)
        pick = self.rng.choice(self.A, self.A, p=w)
        Thn = archive[pick] + sd[pick] * self.rng.standard_normal(Th.shape)
        return Bn, Thn


OPTIMIZERS = {"spider_swarm": None, "pso": PSOOptimizer, "ga": GAOptimizer, "gwo": GWOOptimizer,
              "aco": ACOOptimizer}


def get_optimizer(name: str):
    if name == "spider_swarm":
        from .spider_swarm import SpiderSwarmOptimizer
        return SpiderSwarmOptimizer
    return OPTIMIZERS[name]
