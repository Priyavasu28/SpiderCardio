"""Spider-Swarm Intelligence Optimization for joint feature selection and
hyperparameter adaptation (Section 3.3, Eqs. 9-12, Algorithm 2 steps 3-21).

Each spider agent encodes z = [b, theta]:

* **Continuous coordinates** (Eq. 9 + web-link term)::

      theta_i <- theta_i + r * (P_best,i - theta_i)
                 + c_web * sum_j w_ij (theta_j - theta_i)
                 + E_t * sigma_explore * N(0, 1)

  with link weight w_ij proportional to the fitness of agent j and inversely
  proportional to the Euclidean distance between agents i and j on the encoded
  web; only *more successful* agents (F_j > F_i) vibrate the web of agent i.

* **Binary coordinates** (sigmoid-thresholded web vibration)::

      b_ij <- 1  if  sigma(g * v_ij + xi) > 0.5,
      v_ij  = sum_k w_ik (2 b_kj - 1) + c_p (2 P_best,ij - 1)
              + c_g (1 - E_t)(2 G_best,j - 1) + c_in (2 b_ij - 1)

  where xi ~ N(0, E_t * noise0) is annealed noise.

* **Exploration coefficient** (Eq. 11): E(t) = 1 / (1 + exp(-k (t - t0))) with
  t0 = T/2; the exploration coefficient E_t = e_max - (e_max - e_min) E(t)
  moves from 0.9 to 0.2 and shrinks after the midpoint iteration. It is raised
  again (within [0.2, 0.9]) when the global best stagnates (adaptive range).

* **Local freeze**: a binary coordinate that has not changed for
  ``freeze_after`` (15) iterations can no longer flip (enforced after the
  midpoint iteration, when the search switches to exploitation).

* Population 40, 120 iterations, early termination when the global best has not
  improved for ``convergence_patience`` iterations.
"""
from __future__ import annotations

import time

import numpy as np

from .base import OptimResult, PopulationOptimizer


def _sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


class SpiderSwarmOptimizer(PopulationOptimizer):
    name = "spider_swarm"

    def __init__(self, *args, e_min: float = 0.2, e_max: float = 0.9, k: float = 0.1, freeze_after: int = 15,
                 c_web: float = 0.5, c_p: float = 0.4, c_g: float = 0.8, c_inertia: float = 0.3,
                 vibration_gain: float = 1.0, noise0: float = 1.0, sigma_explore: float = 0.1,
                 stagnation_boost: float = 0.15, **kw):
        super().__init__(*args, **kw)
        self.e_min, self.e_max, self.k = e_min, e_max, k
        self.freeze_after = freeze_after
        self.c_web, self.c_p, self.c_g, self.c_in = c_web, c_p, c_g, c_inertia
        self.gain, self.noise0, self.sig_x, self.boost = vibration_gain, noise0, sigma_explore, stagnation_boost

    def exploration(self, t: int, stagnation: int) -> float:
        E = 1.0 / (1.0 + np.exp(-self.k * (t - self.T / 2)))                      # Eq. (11)
        coef = self.e_max - (self.e_max - self.e_min) * E
        coef += self.boost * min(stagnation / 10.0, 1.0)
        return float(np.clip(coef, self.e_min, self.e_max))

    def web_weights(self, B, Th, F):
        pos = np.concatenate([B, Th], axis=1).astype(float)
        dist = np.sqrt(((pos[:, None, :] - pos[None, :, :]) ** 2).sum(-1))
        fit = F - F.min() + 1e-6
        W = fit[None, :] / (dist + 1e-6)
        W *= F[None, :] > F[:, None]                    # only more successful spiders vibrate the web
        np.fill_diagonal(W, 0.0)
        s = W.sum(1, keepdims=True)
        return np.divide(W, s, out=np.zeros_like(W), where=s > 0)

    def run(self) -> OptimResult:
        t0 = time.perf_counter()
        A = self.A
        B, Th = self.init_population()
        F = np.array([self.evaluate(B[i], Th[i]) for i in range(A)])
        PB, PTh, PF = B.copy(), Th.copy(), F.copy()
        g = int(np.argmax(F))
        GB, GTh, GF = B[g].copy(), Th[g].copy(), F[g]
        unchanged = np.zeros_like(B)
        contrib = np.zeros(self.space.d)
        hist, stagnation = [], 0

        for t in range(1, self.T + 1):
            E = self.exploration(t, stagnation)
            W = self.web_weights(B, Th, F)

            # ---- continuous coordinates (Eq. 9 + web-link term) -------------
            r = self.rng.random((A, 1))
            web = W @ Th - W.sum(1, keepdims=True) * Th
            Th = Th + r * (PTh - Th) + self.c_web * self.rng.random((A, 1)) * web \
                + E * self.sig_x * self.rng.standard_normal(Th.shape)
            Th = np.clip(Th, 0.0, 1.0)

            # ---- binary coordinates (sigmoid-thresholded web vibration) -----
            signs = 2 * B - 1
            v = W @ signs + self.c_p * (2 * PB - 1) + self.c_g * (1 - E) * (2 * GB[None] - 1) + self.c_in * signs
            xi = self.rng.normal(0.0, E * self.noise0, B.shape)
            B_new = (_sigmoid(self.gain * v + xi) > 0.5).astype(int)
            # local freeze (active in the exploitation phase, i.e. after the midpoint iteration)
            frozen = (unchanged >= self.freeze_after) & (t > self.T / 2)
            B_new[frozen] = B[frozen]
            unchanged = np.where(B_new == B, unchanged + 1, 0)
            B = np.stack([self.space.repair(b, self.rng) for b in B_new])

            # ---- evaluation and best-solution bookkeeping -------------------
            F = np.array([self.evaluate(B[i], Th[i]) for i in range(A)])
            imp = F > PF
            PB[imp], PTh[imp], PF[imp] = B[imp], Th[imp], F[imp]
            g = int(np.argmax(F))
            if F[g] > GF + 1e-9:
                GB, GTh, GF, stagnation = B[g].copy(), Th[g].copy(), F[g], 0
            else:
                stagnation += 1
            # fitness-weighted selection frequency = feature contribution across search cycles
            w = (F - F.min()) / (np.ptp(F) + 1e-9)
            contrib += (w[:, None] * B).sum(0)

            hist.append({"iteration": t, "best_fitness": GF, "mean_fitness": float(F.mean()),
                         "selected_features": int(GB.sum()), "exploration": E,
                         "convergence_rate": self.convergence_rate(B, Th, GB, GTh), "evaluations": self.n_evals})
            self._log(t, GF, GB)
            if self.patience and stagnation >= self.patience:
                break

        contrib = contrib / (contrib.max() + 1e-9)
        return self._result(GB, GTh, GF, hist, t0,
                            feature_contribution=dict(zip(self.space.feature_names, contrib.round(4))))
