"""Fitness function for the swarm (Eq. 10) and feature relevance (Eq. 12).

    F = alpha * Accuracy + beta * Recall + gamma * AUC  [- delta * Redundancy] [+ eta * Stability]

Accuracy, macro recall and macro one-vs-rest AUC are measured on the *validation*
partition after a short training run (``fitness_epochs``) of the SpiderCardio
network restricted to the agent's feature subset and hyperparameters. The
redundancy and stability terms are optional (weights default to 0 so the
default objective is exactly Eq. 10). Treatment-support concordance is NOT part
of the fitness: the cardiologist audit cases come from the untouched test set.
"""
from __future__ import annotations

import logging

import numpy as np
from sklearn.metrics import accuracy_score, recall_score, roc_auc_score

from ..data.sequences import SequenceData
from ..models.spidercardio import SpiderCardioConfig, SpiderCardioNet
from ..training.trainer import TrainConfig, fit, predict_proba

log = logging.getLogger(__name__)


def feature_relevance(X_last: np.ndarray, y: np.ndarray, feature_names: list[str]) -> dict[str, float]:
    """Eq. (12): R_f = Cov(X_f, Y) / (sigma_X sigma_Y) (Pearson correlation with the ordinal stage)."""
    out = {}
    yc = y - y.mean()
    for j, f in enumerate(feature_names):
        x = X_last[:, j] - X_last[:, j].mean()
        den = np.sqrt((x ** 2).sum() * (yc ** 2).sum())
        out[f] = float((x * yc).sum() / den) if den > 0 else 0.0
    return out


def safe_auc(y, proba, n_classes):
    try:
        return roc_auc_score(y, proba, multi_class="ovr", average="macro", labels=list(range(n_classes)))
    except ValueError:
        return 0.5


class SpiderCardioFitness:
    def __init__(self, train: SequenceData, val: SequenceData, feature_names: list[str], model_cfg: dict,
                 train_cfg: dict, weights: dict | None = None, fitness_epochs: int = 5,
                 subsample: float | None = 0.3, relevance: dict | None = None, seed: int = 0, device="auto"):
        self.feature_names = feature_names
        self.model_cfg, self.train_cfg = dict(model_cfg), dict(train_cfg)
        self.w = {"accuracy": 0.4, "recall": 0.3, "auc": 0.3, "redundancy": 0.0, "stability": 0.0, **(weights or {})}
        self.epochs, self.relevance, self.device = fitness_epochs, relevance, device
        rng = np.random.default_rng(seed)
        if subsample and subsample < 1:
            train = train.subset(rng.choice(len(train), max(256, int(subsample * len(train))), replace=False))
            val = val.subset(rng.choice(len(val), max(256, int(subsample * len(val))), replace=False))
        self.train, self.val, self.seed = train, val, seed
        self.corr = np.abs(np.nan_to_num(np.corrcoef(train.last.T)))

    def __call__(self, mask: np.ndarray, hyper: dict) -> float:
        cols = np.where(mask)[0]
        names = [self.feature_names[i] for i in cols]
        mc = {**self.model_cfg, "capsule_dim": hyper["capsule_dim"],
              "gru_hidden": (hyper["gru_hidden"], max(16, hyper["gru_hidden"] // 2)),
              "hyperscalar_dropout": hyper["dropout"], "routing_iterations": hyper["routing_iterations"]}
        model = SpiderCardioNet(names, SpiderCardioConfig.from_dict(mc), self.relevance)
        tc = TrainConfig.from_dict({**self.train_cfg, "lr": hyper["lr"], "batch_size": hyper["batch_size"],
                                    "optimizer": hyper["optimizer"], "max_epochs": self.epochs,
                                    "patience": self.epochs, "verbose": False, "seed": self.seed,
                                    "device": self.device})
        tr, va = self.train.select_features(cols), self.val.select_features(cols)
        res = fit(model, tr, va, tc)
        p = predict_proba(model, va, self.device)
        pred = p.argmax(1)
        n_cls = p.shape[1]
        acc = accuracy_score(va.y, pred)
        rec = recall_score(va.y, pred, average="macro", labels=list(range(n_cls)), zero_division=0)
        auc = safe_auc(va.y, p, n_cls)
        f = self.w["accuracy"] * acc + self.w["recall"] * rec + self.w["auc"] * auc
        if self.w["redundancy"]:
            sub = self.corr[np.ix_(cols, cols)]
            red = (sub.sum() - len(cols)) / max(1, len(cols) * (len(cols) - 1))
            f -= self.w["redundancy"] * red
        if self.w["stability"] and len(res.history) > 1:
            accs = [h["val_acc"] for h in res.history[-3:]]
            f += self.w["stability"] * (1 - np.std(accs))
        return float(f)


class XGBSurrogateFitness:
    """Cheap surrogate (feature mask only) for fast exploratory runs / CI."""

    def __init__(self, train: SequenceData, val: SequenceData, weights: dict | None = None, seed: int = 0):
        from ..models.factory import tabular_matrix
        self.Xtr, self.ytr = tabular_matrix(train.X, train.mask), train.y
        self.Xva, self.yva = tabular_matrix(val.X, val.mask), val.y
        self.F = train.X.shape[2]
        self.w = {"accuracy": 0.4, "recall": 0.3, "auc": 0.3, **(weights or {})}
        self.seed = seed

    def __call__(self, mask, hyper):
        from xgboost import XGBClassifier
        cols = np.concatenate([np.where(mask)[0], self.F + np.where(mask)[0]])
        n_cls = int(max(self.ytr.max(), self.yva.max()) + 1)
        m = XGBClassifier(n_estimators=150, max_depth=4, learning_rate=0.1, tree_method="hist",
                          objective="multi:softprob", num_class=n_cls, random_state=self.seed, n_jobs=-1, verbosity=0)
        m.fit(self.Xtr[:, cols], self.ytr)
        p = m.predict_proba(self.Xva[:, cols])
        pred = p.argmax(1)
        return (self.w["accuracy"] * accuracy_score(self.yva, pred)
                + self.w["recall"] * recall_score(self.yva, pred, average="macro", zero_division=0)
                + self.w["auc"] * safe_auc(self.yva, p, n_cls))
