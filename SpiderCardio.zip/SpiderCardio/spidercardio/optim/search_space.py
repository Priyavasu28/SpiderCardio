"""Mixed decision vector z = [b, theta] (Section 3.3).

b in {0,1}^d is a binary mask over the d candidate attributes; theta in [0,1]^h is
the continuous hyperparameter vector, decoded to: learning rate, capsule
dimension, GRU width, dropout, routing iterations, batch size and optimizer.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

DEFAULT_HYPER_SPACE = {
    "lr": ("log", 1e-4, 3e-3),
    "capsule_dim": ("choice", [8, 12, 16, 24, 32]),
    "gru_hidden": ("choice", [64, 96, 128, 192, 256]),
    "dropout": ("float", 0.10, 0.50),
    "routing_iterations": ("int", 1, 5),
    "batch_size": ("choice", [32, 64, 128]),
    "optimizer": ("choice", ["adamw", "rmsprop", "sgd"]),
}


@dataclass
class SearchSpace:
    feature_names: list[str]
    hyper: dict = field(default_factory=lambda: dict(DEFAULT_HYPER_SPACE))
    min_features: int = 5

    @property
    def d(self) -> int:
        return len(self.feature_names)

    @property
    def h(self) -> int:
        return len(self.hyper)

    def decode(self, theta: np.ndarray) -> dict:
        out = {}
        for t, (name, spec) in zip(np.clip(theta, 0, 1), self.hyper.items()):
            kind = spec[0]
            if kind == "log":
                lo, hi = np.log10(spec[1]), np.log10(spec[2])
                out[name] = float(10 ** (lo + t * (hi - lo)))
            elif kind == "float":
                out[name] = float(spec[1] + t * (spec[2] - spec[1]))
            elif kind == "int":
                out[name] = int(round(spec[1] + t * (spec[2] - spec[1])))
            elif kind == "choice":
                opts = spec[1]
                out[name] = opts[min(int(t * len(opts)), len(opts) - 1)]
            else:
                raise ValueError(kind)
        return out

    def encode(self, values: dict) -> np.ndarray:
        """Inverse of ``decode`` (used to seed agents with the manuscript configuration)."""
        th = []
        for name, spec in self.hyper.items():
            v, kind = values[name], spec[0]
            if kind == "log":
                lo, hi = np.log10(spec[1]), np.log10(spec[2])
                th.append((np.log10(v) - lo) / (hi - lo))
            elif kind in ("float", "int"):
                th.append((v - spec[1]) / (spec[2] - spec[1]))
            else:
                th.append((spec[1].index(v) + 0.5) / len(spec[1]))
        return np.clip(np.array(th, dtype=float), 0, 1)

    def repair(self, b: np.ndarray, rng) -> np.ndarray:
        """Guarantee at least ``min_features`` selected attributes."""
        b = b.copy()
        k = self.min_features - int(b.sum())
        if k > 0:
            off = np.where(b == 0)[0]
            b[rng.choice(off, k, replace=False)] = 1
        return b

    def selected(self, b: np.ndarray) -> list[str]:
        return [f for f, s in zip(self.feature_names, b) if s]
