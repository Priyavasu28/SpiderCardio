"""Rule-based clinician-facing treatment-SUPPORT suggestions (Section 3.6, Algorithms 2-3).

The predicted stage maps to one of four management categories used by the
cardiologist reference audit (Section 3.9):

    low -> C1  lifestyle modification and risk-factor counselling
    moderate -> C2  pharmacological optimisation (statin, BP and glycaemic control)
                    with cardiology consultation and monitoring
    high -> C3  specialist cardiovascular evaluation incl. angiographic assessment
    critical -> C4  urgent specialist referral / evaluation for coronary intervention

SHAP attributions identify dominant vs secondary risk factors (Algorithm 3 steps
4-11) and an adaptive clinical threshold raises the *priority* within a category
(e.g. high vessel-blockage score + severe ST depression + diabetes). Eq. (23)
gives a treatment-support confidence score.

IMPORTANT: these outputs are decision-support suggestions for clinician review.
Contraindications, comorbidities, patient preferences and guideline criteria are
NOT modelled, and the mapping has not undergone formal guideline validation.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass

import numpy as np

from ..data.schema import STAGE_NAMES, display

STAGE_TO_CATEGORY = {0: "C1", 1: "C2", 2: "C3", 3: "C4"}
CATEGORY_TEXT = {
    "C1": "Lifestyle modification: diet, physical activity / exercise plan, smoking cessation, "
          "risk-factor counselling and periodic cardiac monitoring.",
    "C2": "Consider statin therapy; optimise blood-pressure and diabetes control; cardiology "
          "consultation and monitoring.",
    "C3": "Specialist cardiovascular evaluation including angiographic assessment; consider "
          "medication intensification.",
    "C4": "Urgent specialist referral; evaluation for coronary intervention.",
}
DISCLAIMER = ("Decision-support suggestion only - requires clinician review. Not a treatment directive; "
              "contraindications, comorbidities and guideline criteria were not modelled.")

# Adaptive clinical thresholding (raw clinical units)
URGENCY_RULES = {"vessel_blockage_score": 0.66, "st_depression": 2.0, "diabetes": 1}


@dataclass
class Suggestion:
    record_id: str
    stage: int
    stage_name: str
    stage_probability: float
    category: str
    suggestion: str
    priority: str
    dominant_factors: list
    secondary_factors: list
    confidence_Tc: float
    disclaimer: str = DISCLAIMER

    def to_dict(self):
        return asdict(self)

    def to_markdown(self) -> str:
        dom = ", ".join(f"{display(f)} (+{v:.3f})" for f, v in self.dominant_factors) or "none above threshold"
        return (f"### Record {self.record_id}\n"
                f"* **Predicted stage:** {self.stage_name} (p = {self.stage_probability:.3f})\n"
                f"* **Management category:** {self.category} - {self.suggestion}\n"
                f"* **Priority within category:** {self.priority}\n"
                f"* **Dominant risk contributors (SHAP):** {dom}\n"
                f"* **Treatment-support confidence T_c (Eq. 23):** {self.confidence_Tc:.4f}\n"
                f"> {self.disclaimer}\n")


def dominant_factors(phi_row: np.ndarray, feature_names: list[str], critical_threshold: float | None = None,
                     quantile: float = 0.8):
    """Algorithm 3 steps 4-11: features whose positive contribution exceeds the critical
    threshold are dominant; others with positive contribution are secondary. With
    ``critical_threshold=None`` the threshold adapts per patient (``quantile`` of |phi|)."""
    thr = critical_threshold if critical_threshold is not None else float(np.quantile(np.abs(phi_row), quantile))
    order = np.argsort(-phi_row)
    dom = [(feature_names[j], float(phi_row[j])) for j in order if phi_row[j] > thr and phi_row[j] > 0]
    sec = [(feature_names[j], float(phi_row[j])) for j in order if 0 < phi_row[j] <= thr]
    return dom, sec


def confidence_score(phi_row: np.ndarray, weights: np.ndarray) -> float:
    """Eq. (23): T_c = sum_i w_i phi_i / N."""
    return float((weights * phi_row).sum() / len(phi_row))


def urgency(raw: dict, stage: int, rules: dict = URGENCY_RULES) -> str:
    hits = sum(1 for k, thr in rules.items() if raw.get(k) is not None and not np.isnan(raw.get(k)) and raw[k] >= thr)
    if stage >= 2 and hits >= 3:
        return "highest (combined vessel blockage, severe ST depression and diabetes)"
    if stage >= 2 and hits == 2:
        return "elevated"
    return "routine for category"


def suggest(record_id: str, proba: np.ndarray, phi_row: np.ndarray, feature_names: list[str],
            importance_weights: np.ndarray, raw_values: dict | None = None,
            critical_threshold: float | None = None) -> Suggestion:
    stage = int(np.argmax(proba))
    cat = STAGE_TO_CATEGORY[stage]
    dom, sec = dominant_factors(phi_row, feature_names, critical_threshold)
    return Suggestion(record_id, stage, STAGE_NAMES[stage], float(proba[stage]), cat, CATEGORY_TEXT[cat],
                      urgency(raw_values or {}, stage), dom, sec, confidence_score(phi_row, importance_weights))
