"""Post-hoc SHAP explanations (Section 3.6, Eq. 21) [45].

SHAP is strictly post hoc: it is not a training input, not a loss term and not
part of the forward path, so removing it cannot change predictive metrics
(Table 9, 'Without SHAP').

Explainer actually used for the Capsule-GRU network (resolves the author note in
Section 3.6 - TreeSHAP only applies to tree ensembles):

* ``method="gradient"`` (default): ``shap.GradientExplainer`` (expected gradients)
  on the softmax output, with ~500 background sequences drawn from the training
  partition. Attributions over the time steps of a feature are summed, giving one
  value per harmonized attribute.
* ``method="permutation"``: model-agnostic ``shap.PermutationExplainer`` on the
  attributes of the target (last) record, history held fixed - slower, used as a
  cross-check.
* ``tree_shap`` for the XGBoost / Random-Forest baselines.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import torch
import torch.nn as nn

from ..data.sequences import SequenceData
from ..training.trainer import resolve_device


class _ProbWrapper(nn.Module):
    """SHAP-friendly wrapper: input (N, T, F); a step is 'observed' if any value is non-zero."""

    def __init__(self, model):
        super().__init__()
        self.model = model

    def forward(self, x):
        mask = x.abs().sum(-1) > 0
        mask[:, -1] = True
        return torch.softmax(self.model(x, mask), dim=-1)


def _class_axis(sv, n_classes):
    """Normalise shap output to array (N, T, F, C)."""
    if isinstance(sv, list):
        return np.stack(sv, axis=-1)
    sv = np.asarray(sv)
    if sv.shape[-1] != n_classes:
        raise ValueError(f"unexpected SHAP shape {sv.shape}")
    return sv


def explain_gradient(model, background: SequenceData, data: SequenceData, n_background: int = 500,
                     nsamples: int = 200, seed: int = 0, device="auto", batch: int = 128) -> np.ndarray:
    """Return SHAP values of shape (N, F, C) (time steps summed)."""
    import shap

    dev = resolve_device(device)
    model.to(dev).eval()
    rng = np.random.default_rng(seed)
    bidx = rng.choice(len(background), min(n_background, len(background)), replace=False)
    bg = torch.from_numpy(background.X[bidx] * background.mask[bidx][..., None]).to(dev)
    wrapper = _ProbWrapper(model).to(dev).eval()
    # GradientExplainer needs gradients through the model in eval mode
    explainer = shap.GradientExplainer(wrapper, bg)
    n_classes = wrapper(bg[:2]).shape[1]
    out = []
    for s in range(0, len(data), batch):
        x = torch.from_numpy(data.X[s:s + batch] * data.mask[s:s + batch][..., None]).to(dev)
        sv = explainer.shap_values(x, nsamples=nsamples, rseed=seed)
        out.append(_class_axis(sv, n_classes).sum(axis=1))          # sum over time -> (n, F, C)
    return np.concatenate(out)


def explain_permutation(model, background: SequenceData, data: SequenceData, n_background: int = 100,
                        max_evals: int | None = None, seed: int = 0, device="auto") -> np.ndarray:
    """Last-record attributions (N, F, C) with the patient's history held fixed."""
    import shap

    dev = resolve_device(device)
    model.to(dev).eval()
    rng = np.random.default_rng(seed)
    bg = background.last[rng.choice(len(background), min(n_background, len(background)), replace=False)]
    F_ = data.X.shape[2]
    out = []
    for i in range(len(data)):
        hist, m = data.X[i], data.mask[i]

        def f(last_rows, hist=hist, m=m):
            X = np.repeat(hist[None], len(last_rows), 0).copy()
            X[:, -1] = last_rows
            with torch.no_grad():
                xt = torch.from_numpy(X.astype(np.float32)).to(dev)
                mt = torch.from_numpy(np.repeat(m[None], len(last_rows), 0)).to(dev)
                return torch.softmax(model(xt, mt), 1).cpu().numpy()

        ex = shap.PermutationExplainer(f, shap.maskers.Independent(bg), seed=seed)
        e = ex(data.last[i:i + 1], max_evals=max_evals or 2 * F_ + 1, silent=True)
        out.append(e.values[0])
    return np.stack(out)


def tree_shap(tree_model, X_tab: np.ndarray) -> np.ndarray:
    import shap
    sv = shap.TreeExplainer(tree_model).shap_values(X_tab)
    return np.stack(sv, -1) if isinstance(sv, list) else np.asarray(sv)


# ---------------------------------------------------------------------------
def select_class(shap_values: np.ndarray, classes: np.ndarray) -> np.ndarray:
    """(N, F, C) -> (N, F) attributions for the given (e.g. predicted) class of each sample."""
    return shap_values[np.arange(len(classes)), :, classes]


def global_importance(phi: np.ndarray, feature_names: list[str]) -> pd.DataFrame:
    """Table 7 'SHAP Importance Score': mean |SHAP| per feature over the test partition,
    scaled so that the largest feature equals 1."""
    imp = np.abs(phi).mean(0)
    df = pd.DataFrame({"feature": feature_names, "mean_abs_shap": imp,
                       "importance_score": imp / (imp.max() + 1e-12)})
    return df.sort_values("importance_score", ascending=False).reset_index(drop=True)


def top_k_features(phi: np.ndarray, feature_names: list[str], record_ids, k: int = 3,
                   positive_only: bool = False) -> dict[str, list[str]]:
    out = {}
    for rid, row in zip(record_ids, phi):
        score = row if positive_only else np.abs(row)
        out[rid] = [feature_names[j] for j in np.argsort(-score)[:k]]
    return out
