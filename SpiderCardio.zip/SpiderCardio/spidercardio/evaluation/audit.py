"""Cardiologist reference audit (Section 3.9).

Input: a CSV with one row per audited case and columns
``record_id, rater1, rater2, rater3`` (management categories C1-C4), optionally
``rater{k}_top3`` (semicolon-separated features each rater ranks as clinically
dominant) and ``rater{k}_dir_<feature>`` (+1 risk-raising / -1 protective).
Templates are in ``audit_templates/``.

Outputs: Fleiss' kappa (pre-adjudication) with bootstrap 95 % CI, majority-vote
reference category (unresolved cases flagged for consensus), treatment-support
concordance k/N with 95 % Wilson CI, Interpretation Reliability (top-3 overlap)
and Clinical Consistency per feature (Table 7).
"""
from __future__ import annotations

from collections import Counter

import numpy as np
import pandas as pd

from .metrics import wilson_ci

CATEGORIES = ["C1", "C2", "C3", "C4"]


def fleiss_kappa(ratings: np.ndarray, categories=CATEGORIES) -> float:
    """ratings: (n_cases, n_raters) array of category labels [52]."""
    n, r = ratings.shape
    counts = np.stack([(ratings == c).sum(1) for c in categories], axis=1).astype(float)
    p_j = counts.sum(0) / (n * r)
    P_i = ((counts ** 2).sum(1) - r) / (r * (r - 1))
    P_bar, P_e = P_i.mean(), (p_j ** 2).sum()
    return float((P_bar - P_e) / (1 - P_e)) if P_e < 1 else 1.0


def fleiss_kappa_ci(ratings, n_boot=2000, seed=0):
    rng = np.random.default_rng(seed)
    ks = [fleiss_kappa(ratings[rng.integers(0, len(ratings), len(ratings))]) for _ in range(n_boot)]
    return float(np.nanpercentile(ks, 2.5)), float(np.nanpercentile(ks, 97.5))


def majority_reference(ratings: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Majority (>= 2 of 3) vote; returns (reference, needs_consensus_flag)."""
    ref, flag = [], []
    for row in ratings:
        (cat, cnt), = Counter(row).most_common(1)
        ok = cnt >= (len(row) // 2 + 1)
        ref.append(cat if ok else None)
        flag.append(not ok)
    return np.array(ref, dtype=object), np.array(flag)


def treatment_concordance(suggested: pd.Series, audit: pd.DataFrame, consensus_col: str = "consensus") -> dict:
    raters = [c for c in audit.columns if c.startswith("rater") and c[5:].isdigit()]
    R = audit[raters].to_numpy(dtype=object)
    ref, flag = majority_reference(R)
    if consensus_col in audit:
        ref = np.where(flag, audit[consensus_col].to_numpy(dtype=object), ref)
    sug = suggested.reindex(audit["record_id"]).to_numpy(dtype=object)
    valid = np.array([r is not None and not (isinstance(r, float) and np.isnan(r)) for r in ref])
    k = int((sug[valid] == ref[valid]).sum())
    n = int(valid.sum())
    lo, hi = wilson_ci(k, n)
    kap = fleiss_kappa(R)
    klo, khi = fleiss_kappa_ci(R)
    return {"k": k, "N": n, "concordance": k / n if n else float("nan"), "wilson_95ci": (lo, hi),
            "fleiss_kappa": kap, "fleiss_kappa_95ci": (klo, khi),
            "n_without_majority": int(flag.sum()), "n_unresolved": int((~valid).sum())}


def interpretation_reliability(shap_top3: dict[str, list[str]], audit: pd.DataFrame, k: int = 3) -> dict:
    """Section 3.8.2 (6): % of SHAP top-k features that coincide with the panel's top-k
    (panel top-k = features named most often across raters for that case).
    Also returns per-feature reliability (Table 7 column)."""
    tops = [c for c in audit.columns if c.endswith("_top3")]
    overall_hits, overall_n = 0, 0
    per_feat_hits, per_feat_n = Counter(), Counter()
    for _, row in audit.iterrows():
        named = Counter()
        for c in tops:
            if isinstance(row[c], str):
                named.update([s.strip() for s in row[c].split(";") if s.strip()])
        panel = {f for f, _ in named.most_common(k)}
        model = shap_top3.get(row["record_id"], [])[:k]
        for f in model:
            per_feat_n[f] += 1
            hit = f in panel
            per_feat_hits[f] += hit
            overall_hits += hit
            overall_n += 1
    per = {f: (per_feat_hits[f], per_feat_n[f], per_feat_hits[f] / per_feat_n[f], wilson_ci(per_feat_hits[f], per_feat_n[f]))
           for f in per_feat_n}
    return {"overall": overall_hits / overall_n if overall_n else float("nan"),
            "overall_wilson_95ci": wilson_ci(overall_hits, overall_n), "k": overall_hits, "N": overall_n,
            "per_feature": per}


def clinical_consistency(shap_values: pd.DataFrame, audit: pd.DataFrame) -> dict:
    """Section 3.8.2 (7) - definition implemented here (authors to confirm):
    for each feature, the proportion of audited cases *in which the panel annotated a
    direction for that feature* where the sign of the model's SHAP value equals the
    majority panel direction (+1 risk-raising, -1 protective). Denominators reported."""
    out = {}
    feats = {c.split("_dir_", 1)[1] for c in audit.columns if "_dir_" in c}
    for f in feats:
        cols = [c for c in audit.columns if c.endswith(f"_dir_{f}")]
        hits = n = 0
        for _, row in audit.iterrows():
            vals = [row[c] for c in cols if pd.notna(row[c])]
            if not vals or row["record_id"] not in shap_values.index or f not in shap_values:
                continue
            panel = np.sign(np.sum(vals))
            if panel == 0:
                continue
            n += 1
            hits += np.sign(shap_values.loc[row["record_id"], f]) == panel
        out[f] = {"k": int(hits), "N": n, "value": hits / n if n else float("nan"), "wilson_95ci": wilson_ci(int(hits), n)}
    return out


def sample_audit_set(record_ids: np.ndarray, stages: np.ndarray, n: int = 200, seed: int = 0) -> pd.DataFrame:
    """Stratified random sample of the held-out test partition for the panel."""
    rng = np.random.default_rng(seed)
    df = pd.DataFrame({"record_id": record_ids, "stratum": stages})
    frac = n / len(df)
    parts = [g.sample(max(1, int(round(frac * len(g)))), random_state=int(rng.integers(1e9))) for _, g in df.groupby("stratum")]
    return pd.concat(parts).sample(frac=1, random_state=seed).head(n).reset_index(drop=True)
