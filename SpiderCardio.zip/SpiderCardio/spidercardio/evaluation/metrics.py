"""Standard classification metrics (Section 3.8.1) and Wilson confidence intervals [53].

Binary CAD prediction (Table 8): metrics computed directly with CAD = stage >= 1
and P(CAD) = 1 - P(low) from the stage softmax (Eq. 22).
Four-level staging: one-vs-rest per-class values macro-averaged, K-category MCC
(Gorodkin [47]) and macro one-vs-rest AUC.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.stats import norm
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score, matthews_corrcoef, precision_score,
                             recall_score, roc_auc_score)


def wilson_ci(k: int, n: int, alpha: float = 0.05) -> tuple[float, float]:
    if n == 0:
        return (float("nan"), float("nan"))
    z = norm.ppf(1 - alpha / 2)
    p = k / n
    den = 1 + z ** 2 / n
    c = (p + z ** 2 / (2 * n)) / den
    h = z * np.sqrt(p * (1 - p) / n + z ** 2 / (4 * n ** 2)) / den
    return (float(c - h), float(c + h))


def specificity_binary(y, pred) -> float:
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    return tn / (tn + fp) if (tn + fp) else float("nan")


def binary_metrics(y_cad: np.ndarray, p_cad: np.ndarray, threshold: float = 0.5) -> dict:
    pred = (p_cad >= threshold).astype(int)
    out = {
        "accuracy": accuracy_score(y_cad, pred),
        "precision": precision_score(y_cad, pred, zero_division=0),
        "recall": recall_score(y_cad, pred, zero_division=0),
        "specificity": specificity_binary(y_cad, pred),
        "f1": f1_score(y_cad, pred, zero_division=0),
        "mcc": matthews_corrcoef(y_cad, pred),
        "auc": roc_auc_score(y_cad, p_cad) if len(np.unique(y_cad)) == 2 else float("nan"),
    }
    out["confusion_matrix"] = confusion_matrix(y_cad, pred, labels=[0, 1]).tolist()
    return out


def staging_metrics(y: np.ndarray, proba: np.ndarray) -> dict:
    K = proba.shape[1]
    labels = list(range(K))
    pred = proba.argmax(1)
    cm = confusion_matrix(y, pred, labels=labels)
    spec = []
    for k in labels:
        tn = cm.sum() - cm[k].sum() - cm[:, k].sum() + cm[k, k]
        fp = cm[:, k].sum() - cm[k, k]
        spec.append(tn / (tn + fp) if (tn + fp) else np.nan)
    try:
        auc = roc_auc_score(y, proba, multi_class="ovr", average="macro", labels=labels)
    except ValueError:
        auc = float("nan")
    return {
        "accuracy": accuracy_score(y, pred),
        "precision": precision_score(y, pred, average="macro", labels=labels, zero_division=0),
        "recall": recall_score(y, pred, average="macro", labels=labels, zero_division=0),
        "specificity": float(np.nanmean(spec)),
        "f1": f1_score(y, pred, average="macro", labels=labels, zero_division=0),
        "mcc": matthews_corrcoef(y, pred),           # K-category (Gorodkin) generalisation
        "auc": auc,
        "per_class_recall": recall_score(y, pred, average=None, labels=labels, zero_division=0).tolist(),
        "confusion_matrix": cm.tolist(),
    }


def full_report(y_stage: np.ndarray, proba: np.ndarray) -> dict:
    p_cad = 1.0 - proba[:, 0]
    return {"binary": binary_metrics((y_stage >= 1).astype(int), p_cad), "staging": staging_metrics(y_stage, proba)}


def to_row(name: str, rep: dict, which: str = "binary", pct: bool = True) -> dict:
    r = rep[which]
    s = 100 if pct else 1
    return {"model": name, "accuracy": r["accuracy"] * s, "precision": r["precision"] * s, "recall": r["recall"] * s,
            "specificity": r["specificity"] * s, "f1": r["f1"] * s, "mcc": r["mcc"], "auc": r["auc"] * s}


def summarize_folds(rows: list[dict]) -> pd.DataFrame:
    df = pd.DataFrame(rows)
    num = df.select_dtypes("number")
    return pd.DataFrame({"mean": num.mean(), "sd": num.std(ddof=1)}).T
