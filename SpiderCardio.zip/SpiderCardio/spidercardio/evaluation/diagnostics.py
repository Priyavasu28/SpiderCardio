"""Study-specific diagnostic metrics (Section 3.8.2; Tables 4-6).

These are internal module diagnostics, NOT comparable with other studies and
NOT used for model selection. Where the manuscript leaves a definition open,
the implemented definition is stated in the docstring - keep the paper text and
this file in sync.
"""
from __future__ import annotations

import numpy as np
import torch

from ..data.sequences import SequenceData
from ..training.trainer import predict_proba, resolve_device


def _batches(data: SequenceData, bs, dev):
    for s in range(0, len(data), bs):
        yield (torch.from_numpy(data.X[s:s + bs]).to(dev), torch.from_numpy(data.mask[s:s + bs]).to(dev))


@torch.no_grad()
def representation_stability(model, data: SequenceData, batch_size: int = 64, device="auto") -> float:
    """(1) RS = 1 - sigma_e / mu_e, where mu_e, sigma_e are the mean and sd of cosine
    similarities between the mean hyperscalar embeddings of successive validation batches."""
    dev = resolve_device(device)
    model.to(dev).eval()
    means = []
    for x, m in _batches(data, batch_size, dev):
        _, aux = model(x, m, return_aux=True)
        means.append(aux["hyperscalar"].mean(0))
    sims = [torch.nn.functional.cosine_similarity(a, b, dim=0).item() for a, b in zip(means[:-1], means[1:])]
    sims = np.array(sims)
    return float(1 - sims.std() / (abs(sims.mean()) + 1e-12)) if len(sims) else float("nan")


@torch.no_grad()
def noise_resistance(model, data: SequenceData, sigma: float = 0.15, seed: int = 0, device="auto") -> dict:
    """(2) accuracy under additive N(0, sigma^2) noise on z-scored observed inputs, as % of clean accuracy."""
    rng = np.random.default_rng(seed)
    clean = (predict_proba(model, data, device).argmax(1) == data.y).mean()
    noisy = data.subset(np.arange(len(data)))
    noisy.X = (data.X + sigma * rng.standard_normal(data.X.shape).astype(np.float32) * data.mask[..., None]).astype(np.float32)
    acc_n = (predict_proba(model, noisy, device).argmax(1) == data.y).mean()
    return {"clean_acc": float(clean), "noisy_acc": float(acc_n), "noise_resistance": float(100 * acc_n / max(clean, 1e-12))}


@torch.no_grad()
def _capsule_response(model, data, feat_idx, delta, dev, n):
    x = torch.from_numpy(data.X[:n]).to(dev)
    m = torch.from_numpy(data.mask[:n]).to(dev)
    _, a0 = model(x, m, return_aux=True)
    x2 = x.clone()
    x2[:, :, feat_idx] += delta * m
    _, a1 = model(x2, m, return_aux=True)
    return (a1["capsules"] - a0["capsules"]).flatten(1).cpu().numpy()


def dependency_preservation(model, data: SequenceData, feature_names, pairs, n_random: int = 20,
                            delta: float = 1.0, n: int = 512, seed: int = 0, device="auto") -> dict:
    """(3) Implemented definition: for each feature f, the per-sample capsule-output
    response r_f to a +delta (1 SD) perturbation of f. rho(pair) = mean over samples of
    |Pearson(r_i, r_j)|. DP = clip((rho_known - rho_random) / (1 - rho_random), 0, 1),
    with rho_known averaged over the physiological pairs and rho_random over random pairs."""
    dev = resolve_device(device)
    model.to(dev).eval()
    idx = {f: i for i, f in enumerate(feature_names)}
    cache = {}

    def resp(f):
        if f not in cache:
            cache[f] = _capsule_response(model, data, idx[f], delta, dev, n)
        return cache[f]

    def rho(a, b):
        ra, rb = resp(a), resp(b)
        ra = ra - ra.mean(1, keepdims=True)
        rb = rb - rb.mean(1, keepdims=True)
        c = (ra * rb).sum(1) / (np.sqrt((ra ** 2).sum(1) * (rb ** 2).sum(1)) + 1e-12)
        return float(np.abs(c).mean())

    known = [rho(a, b) for a, b in pairs if a in idx and b in idx]
    rng = np.random.default_rng(seed)
    names = list(idx)
    rand = []
    while len(rand) < n_random:
        a, b = rng.choice(names, 2, replace=False)
        if (a, b) not in pairs and (b, a) not in pairs:
            rand.append(rho(a, b))
    rk, rr = float(np.mean(known)) if known else float("nan"), float(np.mean(rand))
    return {"rho_known": rk, "rho_random": rr, "dependency_preservation": float(np.clip((rk - rr) / (1 - rr + 1e-12), 0, 1))}


@torch.no_grad()
def feature_agreement(model, data: SequenceData, top: int = 5, n: int = 1024, device="auto") -> dict:
    """(4) Mean dynamic-routing coupling coefficient c_ij of the final routing iteration
    for the top-5 (primary i, higher j) capsule pairs, selected post hoc as the pairs with
    the highest mean coupling on high/critical records. Raw values (sum_j c_ij = 1) and
    values relative to uniform routing (c_ij * n_out) are both returned."""
    dev = resolve_device(device)
    model.to(dev).eval()
    sel = np.where(data.y[: n * 4] >= 2)[0][:n]
    if len(sel) == 0:
        sel = np.arange(min(n, len(data)))
    x = torch.from_numpy(data.X[sel]).to(dev)
    m = torch.from_numpy(data.mask[sel]).to(dev)
    _, aux = model(x, m, return_aux=True)
    c = aux["coupling"].mean(0).cpu().numpy()            # (n_in, n_out)
    flat = np.sort(c.ravel())[::-1][:top]
    return {"feature_agreement_raw": float(flat.mean()), "feature_agreement_vs_uniform": float(flat.mean() * c.shape[1])}


def progression_sensitivity(y: np.ndarray, pred: np.ndarray, prev_y: np.ndarray, source: np.ndarray | None = None,
                            restrict_source: str | None = "mimic") -> dict:
    """(5) Recall (correct stage) on records whose stage increased by >= 1 level since the
    patient's previous record. By default restricted to MIMIC-IV (longitudinal labels)."""
    sel = (prev_y >= 0) & (y > prev_y)
    if restrict_source is not None and source is not None and (source == restrict_source).any():
        sel &= source == restrict_source
    n = int(sel.sum())
    return {"n_transitions": n, "progression_sensitivity": float((pred[sel] == y[sel]).mean()) if n else float("nan")}


def sequence_stability(model, data: SequenceData, device="auto") -> float:
    """Table 6 'Sequence Stability' - implemented definition (authors to confirm):
    among records with >= 2 observed steps, the share whose predicted stage is unchanged
    when the oldest observed step is removed from the history."""
    multi = np.where(data.mask.sum(1) >= 2)[0]
    if len(multi) == 0:
        return float("nan")
    d = data.subset(multi)
    p_full = predict_proba(model, d, device).argmax(1)
    d2 = d.subset(np.arange(len(d)))
    first = d2.mask.argmax(1)
    d2.mask = d2.mask.copy()
    d2.X = d2.X.copy()
    d2.mask[np.arange(len(d2)), first] = False
    d2.X[np.arange(len(d2)), first] = 0
    p_trunc = predict_proba(model, d2, device).argmax(1)
    return float((p_full == p_trunc).mean())
