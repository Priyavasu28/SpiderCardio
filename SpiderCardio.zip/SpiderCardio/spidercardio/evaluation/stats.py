"""Paired significance tests between models (addresses Limitation vii).

* DeLong test for two correlated ROC AUCs (fast implementation, Sun & Xu 2014).
* McNemar test (exact binomial for small discordant counts, chi-square with
  continuity correction otherwise) for paired accuracy.
"""
from __future__ import annotations

import numpy as np
from scipy.stats import binomtest, chi2, norm


def _midrank(x):
    order = np.argsort(x)
    xs = x[order]
    n = len(x)
    T = np.zeros(n)
    i = 0
    while i < n:
        j = i
        while j < n and xs[j] == xs[i]:
            j += 1
        T[i:j] = 0.5 * (i + j - 1) + 1
        i = j
    out = np.empty(n)
    out[order] = T
    return out


def _fast_delong(preds_sorted, m):
    n = preds_sorted.shape[1] - m
    k = preds_sorted.shape[0]
    pos, neg = preds_sorted[:, :m], preds_sorted[:, m:]
    tx = np.stack([_midrank(p) for p in pos])
    ty = np.stack([_midrank(p) for p in neg])
    tz = np.stack([_midrank(p) for p in preds_sorted])
    aucs = tz[:, :m].sum(1) / m / n - (m + 1) / (2 * n)
    v01 = (tz[:, :m] - tx) / n
    v10 = 1 - (tz[:, m:] - ty) / m
    s = np.cov(v01) / m + np.cov(v10) / n
    return aucs, s.reshape(k, k)


def delong_test(y: np.ndarray, p1: np.ndarray, p2: np.ndarray) -> dict:
    """Two-sided DeLong test for H0: AUC1 == AUC2 (binary y)."""
    y = np.asarray(y).astype(int)
    order = np.argsort(-y, kind="mergesort")
    m = int(y.sum())
    preds = np.vstack([p1, p2])[:, order]
    aucs, cov = _fast_delong(preds, m)
    var = cov[0, 0] + cov[1, 1] - 2 * cov[0, 1]
    z = (aucs[0] - aucs[1]) / np.sqrt(var) if var > 0 else 0.0
    return {"auc1": float(aucs[0]), "auc2": float(aucs[1]), "z": float(z), "p_value": float(2 * norm.sf(abs(z)))}


def mcnemar_test(y: np.ndarray, pred1: np.ndarray, pred2: np.ndarray) -> dict:
    c1, c2 = pred1 == y, pred2 == y
    b = int((c1 & ~c2).sum())
    c = int((~c1 & c2).sum())
    if b + c < 25:
        p = binomtest(b, b + c, 0.5).pvalue if b + c else 1.0
        stat = float("nan")
    else:
        stat = (abs(b - c) - 1) ** 2 / (b + c)
        p = float(chi2.sf(stat, 1))
    return {"b_model1_only_correct": b, "c_model2_only_correct": c, "statistic": stat, "p_value": float(p)}
