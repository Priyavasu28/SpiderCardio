"""Model registry for SpiderCardio, its ablations and all baselines (Tables 8-9)."""
from __future__ import annotations

import numpy as np

from .baselines_nn import (CNN1D, DenseNet1D, EfficientNet1D, MLPBaseline, RecurrentBaseline, ResNet18_1D,
                           TransformerBaseline)
from .spidercardio import SpiderCardioConfig, SpiderCardioNet

# Table 9 ablation variants -> SpiderCardioConfig overrides
ABLATIONS = {
    "complete": {},
    "no_hyperscalar": {"use_hyperscalar": False},
    "no_capsule": {"use_capsules": False},
    "no_gru": {"use_gru": False},
    "capsule_only": {"use_hyperscalar": False, "use_gru": False},
    "gru_only": {"use_hyperscalar": False, "use_capsules": False},
    "hyperscalar_capsule": {"use_gru": False},
    "capsule_gru": {"use_hyperscalar": False},
}

NEURAL_BASELINES = {
    "cnn": CNN1D, "densenet": DenseNet1D, "resnet18_1d": ResNet18_1D, "efficientnet_1d": EfficientNet1D,
    "transformer": TransformerBaseline, "mlp": MLPBaseline,
    "lstm": lambda F, **k: RecurrentBaseline(F, cell="lstm", **k),
    "gru": lambda F, **k: RecurrentBaseline(F, cell="gru", **k),
    "cnn_lstm": lambda F, **k: RecurrentBaseline(F, cell="lstm", conv_front=True, **k),
}
TREE_BASELINES = ("random_forest", "xgboost")


def build_model(name: str, feature_names: list[str], model_cfg: dict | None = None,
                relevance: dict | None = None, n_classes: int = 4, wave_len: int = 1000):
    """Return an nn.Module for neural models (tree models are built in ``build_tree``)."""
    model_cfg = dict(model_cfg or {})
    if name == "spidercardio" or name in ABLATIONS:
        over = ABLATIONS.get(name, {})
        cfg = SpiderCardioConfig.from_dict({**model_cfg, **over, "n_classes": n_classes})
        return SpiderCardioNet(feature_names, cfg, relevance)
    if name == "capsule":              # standalone capsule network (Table 8)
        return build_model("capsule_only", feature_names, model_cfg, None, n_classes)
    if name == "capsule_gru_baseline":  # Capsule-GRU without hyperscalar / swarm (Table 8)
        return build_model("capsule_gru", feature_names, model_cfg, None, n_classes)
    if name in NEURAL_BASELINES:
        return NEURAL_BASELINES[name](len(feature_names), n_classes=n_classes, wave_len=wave_len)
    raise KeyError(f"unknown model '{name}'")


def tabular_matrix(X: np.ndarray, mask: np.ndarray) -> np.ndarray:
    """numpy twin of baselines_nn.tabular_summary for tree models."""
    m = mask[..., None].astype(np.float32)
    mean = (X * m).sum(1) / np.clip(m.sum(1), 1, None)
    return np.concatenate([X[:, -1], mean], axis=1)


def build_tree(name: str, params: dict | None = None, seed: int = 0, n_classes: int = 4):
    params = dict(params or {})
    if name == "random_forest":
        from sklearn.ensemble import RandomForestClassifier
        return RandomForestClassifier(**{"n_estimators": 500, "n_jobs": -1, "random_state": seed,
                                         "class_weight": None, **params})
    if name == "xgboost":
        from xgboost import XGBClassifier
        return XGBClassifier(**{"n_estimators": 600, "max_depth": 6, "learning_rate": 0.05, "subsample": 0.9,
                                "colsample_bytree": 0.8, "objective": "multi:softprob", "num_class": n_classes,
                                "tree_method": "hist", "random_state": seed, "n_jobs": -1,
                                "early_stopping_rounds": 50, "eval_metric": "mlogloss", **params})
    raise KeyError(name)


def count_parameters(model) -> int:
    return sum(p.numel() for p in model.parameters() if p.requires_grad)
