"""SpiderCardio network: Hyperscalar expansion -> hierarchical capsules -> stacked GRU
(+ temporal attention) -> softmax over the four CAD stages (Eq. 22).

Each *time step* (one harmonized record) is embedded independently by the
hyperscalar module and the capsule hierarchy; the resulting capsule vectors form
the per-step input of the GRU, so the GRU models the patient's longitudinal
timeline (Section 3.5). Single-visit records give sequences of length 1.

Ablation switches (Table 9): ``use_hyperscalar``, ``use_capsules``, ``use_gru``.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import torch
import torch.nn as nn

from ..data.schema import DEFAULT_CLINICAL_PAIRS
from .capsules import PrimaryCapsules, RoutingCapsules
from .hyperscalar import (FactorizationMachineLayer, HyperscalarExpansion, MLPEmbedding, PlainEmbedding,
                          PolynomialExpansion)
from .temporal import GRUTemporalEncoder


@dataclass
class SpiderCardioConfig:
    hyperscalar_hidden: tuple = (128, 256, 512)
    hyperscalar_dropout: float = 0.35
    pair_dim: int = 32
    clinical_pairs: list = field(default_factory=lambda: list(DEFAULT_CLINICAL_PAIRS))
    amplification_lambda: float = 1.0
    learnable_alpha: bool = False
    embedding: str = "hyperscalar"        # hyperscalar | plain | mlp | polynomial | fm
    primary_caps: int = 64
    primary_dim: int = 8
    higher_caps: int = 32
    capsule_dim: int = 16
    routing_iterations: int = 3
    routing_layernorm: bool = True
    capsule_dropout: float = 0.30
    gru_hidden: tuple = (128, 64)
    gru_dropout: float = 0.25
    temporal_attention: bool = True
    n_classes: int = 4
    use_hyperscalar: bool = True
    use_capsules: bool = True
    use_gru: bool = True

    @classmethod
    def from_dict(cls, d: dict) -> "SpiderCardioConfig":
        d = dict(d or {})
        for k in ("hyperscalar_hidden", "gru_hidden"):
            if k in d:
                d[k] = tuple(d[k])
        if "clinical_pairs" in d:
            d["clinical_pairs"] = [tuple(p) for p in d["clinical_pairs"]]
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


class SpiderCardioNet(nn.Module):
    def __init__(self, feature_names: list[str], cfg: SpiderCardioConfig | None = None,
                 relevance: dict[str, float] | None = None):
        super().__init__()
        cfg = cfg or SpiderCardioConfig()
        self.cfg, self.feature_names = cfg, list(feature_names)
        F_ = len(feature_names)
        emb_dim = cfg.hyperscalar_hidden[-1]
        if not cfg.use_hyperscalar or cfg.embedding == "plain":
            self.embed = PlainEmbedding(F_, emb_dim)
        elif cfg.embedding == "hyperscalar":
            self.embed = HyperscalarExpansion(F_, feature_names, cfg.clinical_pairs, cfg.hyperscalar_hidden,
                                              cfg.hyperscalar_dropout, cfg.pair_dim, relevance,
                                              cfg.amplification_lambda, cfg.learnable_alpha)
        elif cfg.embedding == "mlp":
            self.embed = MLPEmbedding(F_, cfg.hyperscalar_hidden, cfg.hyperscalar_dropout)
        elif cfg.embedding == "polynomial":
            self.embed = PolynomialExpansion(F_, emb_dim)
        elif cfg.embedding == "fm":
            self.embed = FactorizationMachineLayer(F_, emb_dim)
        else:
            raise ValueError(cfg.embedding)

        step_dim = cfg.higher_caps * cfg.capsule_dim
        if cfg.use_capsules:
            self.primary = PrimaryCapsules(self.embed.out_dim, cfg.primary_caps, cfg.primary_dim)
            self.routing = RoutingCapsules(cfg.primary_caps, cfg.primary_dim, cfg.higher_caps, cfg.capsule_dim,
                                           cfg.routing_iterations, cfg.routing_layernorm)
            self.caps_drop = nn.Dropout(cfg.capsule_dropout)
        else:
            self.dense = nn.Sequential(nn.Linear(self.embed.out_dim, step_dim), nn.GELU(),
                                       nn.Dropout(cfg.capsule_dropout))
        if cfg.use_gru:
            self.temporal = GRUTemporalEncoder(step_dim, cfg.gru_hidden, cfg.gru_dropout, cfg.temporal_attention)
            head_in = self.temporal.out_dim
        else:
            self.static = nn.Sequential(nn.Linear(step_dim, cfg.gru_hidden[-1]), nn.GELU())
            head_in = cfg.gru_hidden[-1]
        self.head = nn.Linear(head_in, cfg.n_classes)
        self.step_dim = step_dim

    # ------------------------------------------------------------------
    def encode_steps(self, x: torch.Tensor, mask: torch.Tensor, aux: dict | None = None):
        """Embed every observed step. Returns (N, T, step_dim)."""
        N, T, F_ = x.shape
        flat_mask = mask.reshape(-1)
        xf = x.reshape(N * T, F_)[flat_mask]
        e, parts = self.embed(xf, return_parts=True)
        if self.cfg.use_capsules:
            u = self.primary(e)
            v, c = self.routing(u)
            z = self.caps_drop(v).flatten(1)
            if aux is not None:
                aux.update(primary=u, capsules=v, coupling=c)
        else:
            z = self.dense(e)
        if aux is not None:
            aux.update(embedding=e, hyperscalar=parts["H"], pair_embeddings=parts["pairs"])
        out = x.new_zeros(N * T, z.shape[1])
        out[flat_mask] = z
        return out.view(N, T, -1)

    def forward(self, x: torch.Tensor, mask: torch.Tensor | None = None, wave=None, return_aux: bool = False):
        """``wave`` is accepted for interface compatibility with the baselines and ignored."""
        if x.dim() == 2:                       # single-record convenience
            x = x.unsqueeze(1)
        if mask is None:
            mask = torch.ones(x.shape[:2], dtype=torch.bool, device=x.device)
        aux = {} if return_aux else None
        steps = self.encode_steps(x, mask, aux)
        if self.cfg.use_gru:
            ctx, attn = self.temporal(steps, mask)
            if aux is not None:
                aux["attention"] = attn
        else:
            ctx = self.static(steps[:, -1])
        logits = self.head(ctx)
        if return_aux:
            aux["context"] = ctx
            return logits, aux
        return logits
