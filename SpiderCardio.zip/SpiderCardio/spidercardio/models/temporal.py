"""GRU temporal progression modelling with adaptive temporal attention (Section 3.5)."""
from __future__ import annotations

import torch
import torch.nn as nn


class PaperGRUCell(nn.Module):
    """GRU cell written exactly as Eqs. (17)-(20).

    z_t = sigma(W_z x_t + U_z h_{t-1})                         (17)
    r_t = sigma(W_r x_t + U_r h_{t-1})                         (18)
    h~_t = tanh(W_h x_t + U_h (r_t * h_{t-1}))                 (19)
    h_t = (1 - z_t) * h_{t-1} + z_t * h~_t                     (20)
    """

    def __init__(self, in_dim: int, hidden: int):
        super().__init__()
        self.W = nn.Linear(in_dim, 3 * hidden)
        self.U_zr = nn.Linear(hidden, 2 * hidden, bias=False)
        self.U_h = nn.Linear(hidden, hidden, bias=False)
        self.hidden = hidden

    def forward(self, x, h):
        wz, wr, wh = self.W(x).chunk(3, dim=-1)
        uz, ur = self.U_zr(h).chunk(2, dim=-1)
        z = torch.sigmoid(wz + uz)
        r = torch.sigmoid(wr + ur)
        h_tilde = torch.tanh(wh + self.U_h(r * h))
        return (1 - z) * h + z * h_tilde


class MaskedGRU(nn.Module):
    """Runs a PaperGRUCell over (N, T, D) with a step mask; padded steps keep the state."""

    def __init__(self, in_dim: int, hidden: int):
        super().__init__()
        self.cell = PaperGRUCell(in_dim, hidden)
        self.hidden = hidden

    def forward(self, x, mask):
        N, T, _ = x.shape
        h = x.new_zeros(N, self.hidden)
        outs = []
        for t in range(T):
            m = mask[:, t].unsqueeze(-1).to(x.dtype)
            h = m * self.cell(x[:, t], h) + (1 - m) * h
            outs.append(h)
        return torch.stack(outs, dim=1)


class TemporalAttention(nn.Module):
    """Additive attention over time steps (after the second GRU layer)."""

    def __init__(self, dim: int, attn_dim: int = 64):
        super().__init__()
        self.proj = nn.Linear(dim, attn_dim)
        self.v = nn.Linear(attn_dim, 1, bias=False)

    def forward(self, h, mask):
        e = self.v(torch.tanh(self.proj(h))).squeeze(-1)
        e = e.masked_fill(~mask, float("-inf"))
        a = torch.softmax(e, dim=1)
        return (a.unsqueeze(-1) * h).sum(1), a


class GRUTemporalEncoder(nn.Module):
    """Two stacked GRUs (128, 64) with temporal dropout 0.25 and temporal attention."""

    def __init__(self, in_dim: int, hidden: tuple[int, int] = (128, 64), dropout: float = 0.25,
                 attention: bool = True):
        super().__init__()
        self.gru1 = MaskedGRU(in_dim, hidden[0])
        self.drop = nn.Dropout(dropout)
        self.gru2 = MaskedGRU(hidden[0], hidden[1])
        self.attention = TemporalAttention(hidden[1]) if attention else None
        self.out_dim = hidden[1]

    def forward(self, x, mask):
        h = self.gru2(self.drop(self.gru1(x, mask)), mask)
        if self.attention is None:
            return h[:, -1], None
        return self.attention(h, mask)
