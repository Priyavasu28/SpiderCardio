"""Categorical focal loss used to train the capsule network on imbalanced stages (Section 3.4)."""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


class FocalLoss(nn.Module):
    def __init__(self, gamma: float = 2.0, alpha: torch.Tensor | None = None, label_smoothing: float = 0.0):
        super().__init__()
        self.gamma, self.ls = gamma, label_smoothing
        self.register_buffer("alpha", alpha if alpha is not None else torch.tensor([]))

    def forward(self, logits, target):
        logp = F.log_softmax(logits, dim=-1)
        ce = F.nll_loss(logp, target, reduction="none") if self.ls == 0 else \
            F.cross_entropy(logits, target, reduction="none", label_smoothing=self.ls)
        pt = logp.gather(1, target[:, None]).squeeze(1).exp()
        loss = (1 - pt) ** self.gamma * ce
        if self.alpha.numel():
            loss = loss * self.alpha.to(logits.device)[target]
        return loss.mean()
