"""Physiology-constrained Hyperscalar Cardiovascular Feature Expansion (Section 3.2).

* Eq. (5)  H   = phi(W X + b): three FC stages 128 -> 256 -> 512, each followed by
           BatchNorm, GELU and dropout (p = 0.35, Eq. 8).
* Eq. (6)  I_ij = X_i * X_j computed ONLY for clinically specified pairs (design choice i).
* Eq. (7)  H_a = alpha * H with a *per-pair* alpha derived from the Spider-Swarm
           relevance scores R_f (Eq. 12) of the two biomarkers (design choice ii):
           alpha_ij = 1 + lambda * sqrt(|R_i| |R_j|).
* The amplified pair embeddings are concatenated to H and fed directly to the
  primary capsule layer (design choice iii) - see ``spidercardio.py``.
"""
from __future__ import annotations

import torch
import torch.nn as nn


class HyperscalarExpansion(nn.Module):
    def __init__(self, n_features: int, feature_names: list[str], clinical_pairs: list[tuple[str, str]],
                 hidden: tuple[int, ...] = (128, 256, 512), dropout: float = 0.35, pair_dim: int = 32,
                 relevance: dict[str, float] | None = None, amplification_lambda: float = 1.0,
                 learnable_alpha: bool = False):
        super().__init__()
        layers, d = [], n_features
        for h in hidden:
            layers += [nn.Linear(d, h), nn.BatchNorm1d(h), nn.GELU(), nn.Dropout(dropout)]
            d = h
        self.projection = nn.Sequential(*layers)

        idx = {f: i for i, f in enumerate(feature_names)}
        self.pair_names = [(a, b) for a, b in clinical_pairs if a in idx and b in idx]
        pairs = torch.tensor([[idx[a], idx[b]] for a, b in self.pair_names], dtype=torch.long).reshape(-1, 2)
        self.register_buffer("pairs", pairs)
        n_pairs = len(self.pair_names)
        self.pair_encoders = nn.ModuleList(
            [nn.Sequential(nn.Linear(3, pair_dim), nn.BatchNorm1d(pair_dim), nn.GELU()) for _ in range(n_pairs)])
        rel = relevance or {}
        alpha = torch.tensor([1.0 + amplification_lambda * (abs(rel.get(a, 0.0)) * abs(rel.get(b, 0.0))) ** 0.5
                              for a, b in self.pair_names], dtype=torch.float32)
        if learnable_alpha:
            self.alpha = nn.Parameter(alpha)
        else:
            self.register_buffer("alpha", alpha)
        self.out_dim = hidden[-1] + n_pairs * pair_dim
        self.n_pairs = n_pairs

    def forward(self, x: torch.Tensor, return_parts: bool = False):
        """x: (N, F) -> (N, out_dim)."""
        H = self.projection(x)                                         # Eq. (5) + (8)
        parts = [H]
        pair_emb = []
        for k, enc in enumerate(self.pair_encoders):
            i, j = self.pairs[k]
            xi, xj = x[:, i:i + 1], x[:, j:j + 1]
            inter = xi * xj                                            # Eq. (6)
            e = self.alpha[k] * enc(torch.cat([xi, xj, inter], dim=1))  # Eq. (7)
            pair_emb.append(e)
        parts += pair_emb
        out = torch.cat(parts, dim=1)
        if return_parts:
            return out, {"H": H, "pairs": pair_emb}
        return out


class PlainEmbedding(nn.Module):
    """Ablation 'without hyperscalar expansion': one linear projection, no pair crosses."""

    def __init__(self, n_features: int, out_dim: int):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(n_features, out_dim), nn.GELU())
        self.out_dim = out_dim

    def forward(self, x, return_parts: bool = False):
        out = self.net(x)
        return (out, {"H": out, "pairs": []}) if return_parts else out


# --- matched-capacity comparators requested in Section 3.2 -------------------------------
class PolynomialExpansion(nn.Module):
    """Second-order polynomial expansion (all pairs) + projection to ``out_dim``."""

    def __init__(self, n_features: int, out_dim: int = 512):
        super().__init__()
        iu = torch.triu_indices(n_features, n_features)
        self.register_buffer("iu", iu)
        self.proj = nn.Sequential(nn.Linear(n_features + iu.shape[1], out_dim), nn.BatchNorm1d(out_dim), nn.GELU())
        self.out_dim = out_dim

    def forward(self, x, return_parts: bool = False):
        quad = (x.unsqueeze(2) * x.unsqueeze(1))[:, self.iu[0], self.iu[1]]
        out = self.proj(torch.cat([x, quad], 1))
        return (out, {"H": out, "pairs": []}) if return_parts else out


class FactorizationMachineLayer(nn.Module):
    """FM interaction layer [43]: linear term + factorised pairwise term, projected to ``out_dim``."""

    def __init__(self, n_features: int, out_dim: int = 512, k: int = 16):
        super().__init__()
        self.V = nn.Parameter(torch.randn(n_features, k) * 0.05)
        self.proj = nn.Sequential(nn.Linear(n_features + k, out_dim), nn.BatchNorm1d(out_dim), nn.GELU())
        self.out_dim = out_dim

    def forward(self, x, return_parts: bool = False):
        xv = x @ self.V
        inter = 0.5 * (xv ** 2 - (x ** 2) @ (self.V ** 2))
        out = self.proj(torch.cat([x, inter], 1))
        return (out, {"H": out, "pairs": []}) if return_parts else out


class MLPEmbedding(nn.Module):
    """Matched-capacity MLP embedding (same 128-256-512 stack, no pair crosses)."""

    def __init__(self, n_features: int, hidden=(128, 256, 512), dropout: float = 0.35):
        super().__init__()
        layers, d = [], n_features
        for h in hidden:
            layers += [nn.Linear(d, h), nn.BatchNorm1d(h), nn.GELU(), nn.Dropout(dropout)]
            d = h
        self.net = nn.Sequential(*layers)
        self.out_dim = d

    def forward(self, x, return_parts: bool = False):
        out = self.net(x)
        return (out, {"H": out, "pairs": []}) if return_parts else out
