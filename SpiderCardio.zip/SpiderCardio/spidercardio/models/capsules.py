"""Hierarchical capsule layers with dynamic routing (Section 3.4, Eqs. 13-16) [50]."""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


def squash(s: torch.Tensor, dim: int = -1, eps: float = 1e-8) -> torch.Tensor:
    """Eq. (14): v = ||s||^2 / (1 + ||s||^2) * s / ||s||."""
    n2 = (s * s).sum(dim=dim, keepdim=True)
    return (n2 / (1.0 + n2)) * s / torch.sqrt(n2 + eps)


class PrimaryCapsules(nn.Module):
    """Eq. (13): u_i = W_i X + b_i, reshaped to ``n_caps`` capsules of ``caps_dim`` and squashed."""

    def __init__(self, in_dim: int, n_caps: int = 64, caps_dim: int = 8):
        super().__init__()
        self.n_caps, self.caps_dim = n_caps, caps_dim
        self.fc = nn.Linear(in_dim, n_caps * caps_dim)

    def forward(self, x):
        return squash(self.fc(x).view(-1, self.n_caps, self.caps_dim))


class RoutingCapsules(nn.Module):
    """Higher-level cardiovascular capsules with routing-by-agreement.

    u_hat_{j|i} = W_ij u_i ; c_ij = softmax_j(b_ij) (Eq. 15) ; s_j = sum_i c_ij u_hat_{j|i};
    v_j = squash(s_j) (Eq. 14) ; b_ij += v_j . u_hat_{j|i} (agreement, Eq. 16).
    Layer normalisation is applied after every routing cycle (Section 3.4).
    """

    def __init__(self, n_in: int = 64, in_dim: int = 8, n_out: int = 32, out_dim: int = 16,
                 iterations: int = 3, layer_norm: bool = True):
        super().__init__()
        self.n_in, self.n_out, self.out_dim, self.iterations = n_in, n_out, out_dim, iterations
        self.W = nn.Parameter(0.05 * torch.randn(1, n_in, n_out, out_dim, in_dim))
        self.ln = nn.LayerNorm(out_dim) if layer_norm else nn.Identity()

    def forward(self, u: torch.Tensor):
        # u: (N, n_in, in_dim) -> u_hat: (N, n_in, n_out, out_dim)
        u_hat = (self.W @ u[:, :, None, :, None]).squeeze(-1)
        b = torch.zeros(u.shape[0], self.n_in, self.n_out, device=u.device, dtype=u.dtype)
        u_hat_detached = u_hat.detach()
        for r in range(self.iterations):
            c = F.softmax(b, dim=2)                                     # Eq. (15)
            uh = u_hat if r == self.iterations - 1 else u_hat_detached
            s = (c.unsqueeze(-1) * uh).sum(dim=1)                       # (N, n_out, out_dim)
            v = self.ln(squash(s))                                      # Eq. (14) + LayerNorm
            if r < self.iterations - 1:
                b = b + (uh * v.unsqueeze(1)).sum(-1)                   # Eq. (16)
        return v, c
