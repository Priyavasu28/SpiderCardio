"""Neural baselines evaluated on the same harmonized inputs as SpiderCardio (Section 3.7).

Input handling follows the manuscript:
* CNN / DenseNet / ResNet-18-1D / EfficientNet-1D / Transformer: z-scored ECG waveform
  segment (1-D) concatenated with the tabular vector at the embedding layer.
* LSTM / GRU / CNN-LSTM: waveform sequence as temporal input; tabular features
  supplied at the final classification layer. If a cohort has no waveforms
  (``wave is None``) these models fall back to the tabular history sequence.
* Capsule / Capsule-GRU baselines are ablated SpiderCardio networks (see factory.py).

All baselines share the signature ``forward(x, mask, wave=None) -> logits``.
"""
from __future__ import annotations

import torch
import torch.nn as nn


def tabular_summary(x, mask):
    """Last-record features + masked mean of the history -> (N, 2F)."""
    m = mask.unsqueeze(-1).float()
    mean = (x * m).sum(1) / m.sum(1).clamp(min=1)
    return torch.cat([x[:, -1], mean], dim=1)


class _WaveTabular(nn.Module):
    """Wraps a waveform encoder and fuses it with the tabular summary."""

    def __init__(self, n_features, wave_encoder: nn.Module, wave_dim: int, n_classes=4, wave_len=1000):
        super().__init__()
        self.wave_encoder, self.wave_len = wave_encoder, wave_len
        self.tab = nn.Sequential(nn.Linear(2 * n_features, 128), nn.GELU(), nn.Dropout(0.3))
        self.head = nn.Sequential(nn.Linear(wave_dim + 128, 128), nn.GELU(), nn.Dropout(0.3),
                                  nn.Linear(128, n_classes))

    def forward(self, x, mask, wave=None):
        if wave is None:
            wave = x.new_zeros(x.shape[0], self.wave_len)
        w = self.wave_encoder(wave.unsqueeze(1))
        return self.head(torch.cat([w, self.tab(tabular_summary(x, mask))], 1))


def _conv_bn(i, o, k=7, s=1):
    return nn.Sequential(nn.Conv1d(i, o, k, s, k // 2, bias=False), nn.BatchNorm1d(o), nn.ReLU(inplace=True))


class CNN1D(_WaveTabular):
    def __init__(self, n_features, n_classes=4, wave_len=1000):
        enc = nn.Sequential(_conv_bn(1, 32), nn.MaxPool1d(2), _conv_bn(32, 64), nn.MaxPool1d(2),
                            _conv_bn(64, 128), nn.MaxPool1d(2), _conv_bn(128, 128),
                            nn.AdaptiveAvgPool1d(1), nn.Flatten())
        super().__init__(n_features, enc, 128, n_classes, wave_len)


class _DenseLayer(nn.Module):
    def __init__(self, c, g):
        super().__init__()
        self.f = nn.Sequential(nn.BatchNorm1d(c), nn.ReLU(), nn.Conv1d(c, 4 * g, 1, bias=False),
                               nn.BatchNorm1d(4 * g), nn.ReLU(), nn.Conv1d(4 * g, g, 7, padding=3, bias=False))

    def forward(self, x):
        return torch.cat([x, self.f(x)], 1)


class DenseNet1D(_WaveTabular):
    def __init__(self, n_features, n_classes=4, wave_len=1000, growth=16, blocks=(4, 4, 4)):
        layers, c = [nn.Conv1d(1, 32, 7, 2, 3, bias=False)], 32
        for bi, n in enumerate(blocks):
            for _ in range(n):
                layers.append(_DenseLayer(c, growth))
                c += growth
            if bi < len(blocks) - 1:
                layers += [nn.BatchNorm1d(c), nn.ReLU(), nn.Conv1d(c, c // 2, 1, bias=False), nn.AvgPool1d(2)]
                c //= 2
        layers += [nn.BatchNorm1d(c), nn.ReLU(), nn.AdaptiveAvgPool1d(1), nn.Flatten()]
        super().__init__(n_features, nn.Sequential(*layers), c, n_classes, wave_len)


class _Res(nn.Module):
    def __init__(self, i, o, s):
        super().__init__()
        self.f = nn.Sequential(nn.Conv1d(i, o, 7, s, 3, bias=False), nn.BatchNorm1d(o), nn.ReLU(),
                               nn.Conv1d(o, o, 7, 1, 3, bias=False), nn.BatchNorm1d(o))
        self.sc = nn.Identity() if (i == o and s == 1) else nn.Sequential(nn.Conv1d(i, o, 1, s, bias=False),
                                                                          nn.BatchNorm1d(o))

    def forward(self, x):
        return torch.relu(self.f(x) + self.sc(x))


class ResNet18_1D(_WaveTabular):
    def __init__(self, n_features, n_classes=4, wave_len=1000):
        ch = [64, 128, 256, 512]
        layers = [nn.Conv1d(1, 64, 15, 2, 7, bias=False), nn.BatchNorm1d(64), nn.ReLU(), nn.MaxPool1d(3, 2, 1)]
        c = 64
        for i, o in enumerate(ch):
            layers += [_Res(c, o, 1 if i == 0 else 2), _Res(o, o, 1)]
            c = o
        layers += [nn.AdaptiveAvgPool1d(1), nn.Flatten()]
        super().__init__(n_features, nn.Sequential(*layers), 512, n_classes, wave_len)


class _MBConv(nn.Module):
    def __init__(self, i, o, s, e=4):
        super().__init__()
        h = i * e
        self.use_res = s == 1 and i == o
        self.f = nn.Sequential(nn.Conv1d(i, h, 1, bias=False), nn.BatchNorm1d(h), nn.SiLU(),
                               nn.Conv1d(h, h, 5, s, 2, groups=h, bias=False), nn.BatchNorm1d(h), nn.SiLU(),
                               nn.Conv1d(h, o, 1, bias=False), nn.BatchNorm1d(o))
        self.se = nn.Sequential(nn.AdaptiveAvgPool1d(1), nn.Conv1d(o, max(4, o // 4), 1), nn.SiLU(),
                                nn.Conv1d(max(4, o // 4), o, 1), nn.Sigmoid())

    def forward(self, x):
        y = self.f(x)
        y = y * self.se(y)
        return x + y if self.use_res else y


class EfficientNet1D(_WaveTabular):
    """EfficientNet-B0-style 1-D adaptation (MBConv + squeeze-excitation)."""

    def __init__(self, n_features, n_classes=4, wave_len=1000):
        cfg = [(32, 16, 1), (16, 24, 2), (24, 40, 2), (40, 80, 2), (80, 112, 1), (112, 192, 2)]
        layers = [nn.Conv1d(1, 32, 7, 2, 3, bias=False), nn.BatchNorm1d(32), nn.SiLU()]
        for i, o, s in cfg:
            layers += [_MBConv(i, o, s), _MBConv(o, o, 1)]
        layers += [nn.Conv1d(192, 256, 1), nn.SiLU(), nn.AdaptiveAvgPool1d(1), nn.Flatten()]
        super().__init__(n_features, nn.Sequential(*layers), 256, n_classes, wave_len)


class TransformerBaseline(nn.Module):
    """Patch tokens of the waveform + one tabular token + CLS -> TransformerEncoder."""

    def __init__(self, n_features, n_classes=4, wave_len=1000, patch=50, d=64, layers=2, heads=4):
        super().__init__()
        self.patch, self.wave_len = patch, wave_len
        n_tok = wave_len // patch
        self.patch_emb = nn.Linear(patch, d)
        self.tab_emb = nn.Linear(2 * n_features, d)
        self.cls = nn.Parameter(torch.zeros(1, 1, d))
        self.pos = nn.Parameter(torch.randn(1, n_tok + 2, d) * 0.02)
        enc = nn.TransformerEncoderLayer(d, heads, 4 * d, 0.1, batch_first=True, norm_first=True)
        self.encoder = nn.TransformerEncoder(enc, layers, enable_nested_tensor=False)
        self.head = nn.Sequential(nn.LayerNorm(d), nn.Linear(d, n_classes))

    def forward(self, x, mask, wave=None):
        if wave is None:
            wave = x.new_zeros(x.shape[0], self.wave_len)
        p = self.patch_emb(wave[:, : (self.wave_len // self.patch) * self.patch].reshape(x.shape[0], -1, self.patch))
        t = self.tab_emb(tabular_summary(x, mask)).unsqueeze(1)
        h = torch.cat([self.cls.expand(x.shape[0], -1, -1), t, p], 1) + self.pos
        return self.head(self.encoder(h)[:, 0])


class RecurrentBaseline(nn.Module):
    """LSTM / GRU / CNN-LSTM. Temporal input = waveform (as frames) or tabular history."""

    def __init__(self, n_features, n_classes=4, cell="lstm", conv_front=False, wave_len=1000, frame=10,
                 hidden=128, use_wave=True):
        super().__init__()
        self.cell, self.conv_front, self.frame, self.use_wave = cell, conv_front, frame, use_wave
        rnn = nn.LSTM if cell == "lstm" else nn.GRU
        if conv_front:
            self.front = nn.Sequential(_conv_bn(1, 32), nn.MaxPool1d(2), _conv_bn(32, 64), nn.MaxPool1d(2),
                                       _conv_bn(64, 64), nn.MaxPool1d(2))
            in_w = 64
        else:
            in_w = frame
        self.rnn_w = rnn(in_w, hidden, num_layers=2, batch_first=True, dropout=0.25)
        self.rnn_t = rnn(n_features, hidden, num_layers=2, batch_first=True, dropout=0.25)
        self.head = nn.Sequential(nn.Linear(hidden + 2 * n_features, 128), nn.GELU(), nn.Dropout(0.3),
                                  nn.Linear(128, n_classes))

    def forward(self, x, mask, wave=None):
        if wave is not None and self.use_wave:
            if self.conv_front:
                seq = self.front(wave.unsqueeze(1)).transpose(1, 2)
            else:
                L = (wave.shape[1] // self.frame) * self.frame
                seq = wave[:, :L].reshape(wave.shape[0], -1, self.frame)
            out, _ = self.rnn_w(seq)
            h = out[:, -1]
        else:                                    # tabular history fallback (left-padded)
            out, _ = self.rnn_t(x * mask.unsqueeze(-1))
            h = out[:, -1]
        return self.head(torch.cat([h, tabular_summary(x, mask)], 1))


class MLPBaseline(nn.Module):
    def __init__(self, n_features, n_classes=4, wave_len=1000):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(2 * n_features, 256), nn.GELU(), nn.Dropout(0.3),
                                 nn.Linear(256, 128), nn.GELU(), nn.Linear(128, n_classes))

    def forward(self, x, mask, wave=None):
        return self.net(tabular_summary(x, mask))
