"""Training loop (Sections 3.5, 3.7, 4).

AdamW (lr 3e-4) + cosine annealing, categorical focal loss, gradient clipping
1.0, early stopping on validation loss (patience 15, max 120 epochs) with the
best-validation checkpoint restored. Wall-clock time per epoch and single-sample
inference latency are measured with ``time.perf_counter`` after a warm-up epoch,
excluding data loading / host-to-device transfer (as described in Section 3.7).
"""
from __future__ import annotations

import copy
import logging
import time
from dataclasses import dataclass, field

import numpy as np
import torch
from torch.utils.data import DataLoader

from ..data.sequences import SequenceData, TorchSequenceDataset
from ..models.losses import FocalLoss

log = logging.getLogger(__name__)


@dataclass
class TrainConfig:
    lr: float = 3e-4
    weight_decay: float = 1e-2
    batch_size: int = 64
    max_epochs: int = 120
    patience: int = 15
    grad_clip: float = 1.0
    focal_gamma: float = 2.0
    optimizer: str = "adamw"          # adamw | rmsprop | sgd
    scheduler: str = "cosine"
    device: str = "auto"
    num_workers: int = 0
    seed: int = 0
    verbose: bool = True

    @classmethod
    def from_dict(cls, d):
        return cls(**{k: v for k, v in (d or {}).items() if k in cls.__dataclass_fields__})


@dataclass
class TrainResult:
    history: list = field(default_factory=list)
    best_epoch: int = -1
    best_val_loss: float = float("inf")
    epoch_times: list = field(default_factory=list)


def resolve_device(dev: str) -> torch.device:
    if dev == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device(dev)


def _optimizer(model, cfg: TrainConfig):
    if cfg.optimizer == "adamw":
        return torch.optim.AdamW(model.parameters(), lr=cfg.lr, weight_decay=cfg.weight_decay)
    if cfg.optimizer == "rmsprop":
        return torch.optim.RMSprop(model.parameters(), lr=cfg.lr, weight_decay=cfg.weight_decay)
    if cfg.optimizer == "sgd":
        return torch.optim.SGD(model.parameters(), lr=cfg.lr * 10, momentum=0.9, weight_decay=cfg.weight_decay)
    raise ValueError(cfg.optimizer)


def _to_device(batch, device):
    return {k: v.to(device, non_blocking=True) for k, v in batch.items()}


def _loader(data: SequenceData, bs, shuffle, cfg, seed=0):
    g = torch.Generator()
    g.manual_seed(seed)
    return DataLoader(TorchSequenceDataset(data), batch_size=bs, shuffle=shuffle, num_workers=cfg.num_workers,
                      drop_last=shuffle and len(data) > bs, generator=g)


@torch.no_grad()
def evaluate_loss(model, loader, loss_fn, device):
    model.eval()
    tot, n, correct = 0.0, 0, 0
    for b in loader:
        b = _to_device(b, device)
        logits = model(b["x"], b["mask"], b.get("wave"))
        tot += loss_fn(logits, b["y"]).item() * len(b["y"])
        correct += (logits.argmax(1) == b["y"]).sum().item()
        n += len(b["y"])
    return tot / max(n, 1), correct / max(n, 1)


def fit(model: torch.nn.Module, train: SequenceData, val: SequenceData, cfg: TrainConfig) -> TrainResult:
    torch.manual_seed(cfg.seed)
    device = resolve_device(cfg.device)
    model.to(device)
    opt = _optimizer(model, cfg)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=cfg.max_epochs) if cfg.scheduler == "cosine" else None
    loss_fn = FocalLoss(cfg.focal_gamma).to(device)
    tr_loader = _loader(train, cfg.batch_size, True, cfg, cfg.seed)
    va_loader = _loader(val, 512, False, cfg)
    res, best_state, bad = TrainResult(), None, 0
    for epoch in range(1, cfg.max_epochs + 1):
        model.train()
        tot, n, correct, t_compute = 0.0, 0, 0, 0.0
        for b in tr_loader:
            b = _to_device(b, device)
            if device.type == "cuda":
                torch.cuda.synchronize()
            t0 = time.perf_counter()
            logits = model(b["x"], b["mask"], b.get("wave"))
            loss = loss_fn(logits, b["y"])
            opt.zero_grad(set_to_none=True)
            loss.backward()
            if cfg.grad_clip:
                torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.grad_clip)
            opt.step()
            if device.type == "cuda":
                torch.cuda.synchronize()
            t_compute += time.perf_counter() - t0
            tot += loss.item() * len(b["y"])
            correct += (logits.argmax(1) == b["y"]).sum().item()
            n += len(b["y"])
        if sched:
            sched.step()
        vl, va = evaluate_loss(model, va_loader, loss_fn, device)
        rec = {"epoch": epoch, "train_loss": tot / max(n, 1), "train_acc": correct / max(n, 1),
               "val_loss": vl, "val_acc": va, "lr": opt.param_groups[0]["lr"], "epoch_time_s": t_compute}
        res.history.append(rec)
        if epoch > 1:                     # first epoch = warm-up, excluded from timing
            res.epoch_times.append(t_compute)
        if cfg.verbose:
            log.info("epoch %3d  train_loss %.4f  val_loss %.4f  val_acc %.4f", epoch, rec["train_loss"], vl, va)
        if vl < res.best_val_loss - 1e-6:
            res.best_val_loss, res.best_epoch, bad = vl, epoch, 0
            best_state = copy.deepcopy(model.state_dict())
        else:
            bad += 1
            if bad >= cfg.patience:
                break
    if best_state is not None:
        model.load_state_dict(best_state)
    return res


@torch.no_grad()
def predict_proba(model, data: SequenceData, device: str = "auto", batch_size: int = 512) -> np.ndarray:
    dev = resolve_device(device)
    model.to(dev).eval()
    out = []
    for b in DataLoader(TorchSequenceDataset(data), batch_size=batch_size, shuffle=False):
        b = _to_device(b, dev)
        out.append(torch.softmax(model(b["x"], b["mask"], b.get("wave")), 1).cpu().numpy())
    return np.concatenate(out)


@torch.no_grad()
def inference_latency(model, data: SequenceData, n: int = 200, device: str = "auto") -> tuple[float, float]:
    """Mean +/- sd single-sample latency in ms (tensors pre-loaded on device)."""
    dev = resolve_device(device)
    model.to(dev).eval()
    idx = np.random.default_rng(0).choice(len(data), min(n, len(data)), replace=False)
    xs = [(torch.from_numpy(data.X[i:i + 1]).to(dev), torch.from_numpy(data.mask[i:i + 1]).to(dev),
           None if data.wave is None else torch.from_numpy(data.wave[i:i + 1]).to(dev)) for i in idx]
    for x, m, w in xs[:10]:
        model(x, m, w)
    times = []
    for x, m, w in xs:
        if dev.type == "cuda":
            torch.cuda.synchronize()
        t0 = time.perf_counter()
        model(x, m, w)
        if dev.type == "cuda":
            torch.cuda.synchronize()
        times.append((time.perf_counter() - t0) * 1000)
    return float(np.mean(times)), float(np.std(times))
