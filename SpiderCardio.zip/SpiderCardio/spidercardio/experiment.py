"""Train / evaluate any registered model on prepared data (used by all scripts)."""
from __future__ import annotations

import logging
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from sklearn.metrics import log_loss

from .data.balancing import adasyn_sequences
from .data.sequences import SequenceData
from .data.splits import grouped_cv_folds
from .evaluation.metrics import full_report, summarize_folds, to_row
from .models.factory import TREE_BASELINES, build_model, build_tree, count_parameters, tabular_matrix
from .optim.fitness import feature_relevance
from .training.trainer import TrainConfig, fit, inference_latency, predict_proba

log = logging.getLogger(__name__)


def relevance_for(train: SequenceData, names: list[str]) -> dict:
    return feature_relevance(train.last, train.y.astype(float), names)


def run_model(name: str, train: SequenceData, val: SequenceData, test: SequenceData, names: list[str],
              model_cfg: dict, train_cfg: dict, relevance: dict | None = None, seed: int = 0,
              tree_params: dict | None = None, measure_latency: bool = False) -> dict:
    t0 = time.perf_counter()
    if name in TREE_BASELINES:
        model = build_tree(name, tree_params, seed, n_classes=4)
        Xtr, Xva, Xte = (tabular_matrix(d.X, d.mask) for d in (train, val, test))
        if name == "xgboost":
            model.fit(Xtr, train.y, eval_set=[(Xva, val.y)], verbose=False)
        else:
            model.fit(Xtr, train.y)
        proba = _pad_proba(model.predict_proba(Xte), model.classes_)
        val_proba = _pad_proba(model.predict_proba(Xva), model.classes_)
        hist, n_params, latency = [], None, None
    else:
        tc = TrainConfig.from_dict({**train_cfg, "seed": seed})
        model = build_model(name, names, model_cfg, relevance)
        res = fit(model, train, val, tc)
        proba = predict_proba(model, test, tc.device)
        val_proba = predict_proba(model, val, tc.device)
        hist, n_params = res.history, count_parameters(model)
        latency = inference_latency(model, test, device=tc.device) if measure_latency else None
    rep = full_report(test.y, proba)
    rep["val_logloss"] = float(log_loss(val.y, np.clip(val_proba, 1e-7, 1), labels=[0, 1, 2, 3]))
    rep["n_params"] = n_params
    rep["train_time_s"] = time.perf_counter() - t0
    if hist:
        rep["epochs_run"] = len(hist)
        rep["best_epoch"] = int(np.argmin([h["val_loss"] for h in hist]) + 1)
        rep["epoch_time_mean_s"] = float(np.mean([h["epoch_time_s"] for h in hist[1:]])) if len(hist) > 1 else None
    if latency:
        rep["latency_ms_mean"], rep["latency_ms_sd"] = latency
    rep["per_source"] = per_source(test, proba)
    return {"report": rep, "proba": proba, "history": hist, "model": model}


def _pad_proba(p, classes):
    out = np.zeros((len(p), 4))
    out[:, np.asarray(classes, int)] = p
    return out


def per_source(test: SequenceData, proba: np.ndarray) -> dict:
    out = {}
    for s in np.unique(test.source):
        sel = test.source == s
        if sel.sum() >= 10:
            r = full_report(test.y[sel], proba[sel])
            out[str(s)] = {"n": int(sel.sum()), "accuracy": r["binary"]["accuracy"], "f1": r["binary"]["f1"],
                           "auc": r["binary"]["auc"], "staging_accuracy": r["staging"]["accuracy"]}
    return out


def tune_baseline(name: str, prep, model_cfg, train_cfg, cfg, seed=0) -> tuple[dict, dict]:
    """Equal-budget random search on the validation partition (Section 3.7)."""
    bt = cfg.get("baseline_tuning", {})
    n = int(bt.get("n_trials", 20))
    rng = np.random.default_rng(seed)
    if n <= 1:
        return {}, {}
    best, best_loss = ({}, {}), np.inf
    for t in range(n):
        if name in TREE_BASELINES:
            tp = ({"n_estimators": int(rng.choice([200, 400, 800])), "max_depth": int(rng.choice([4, 6, 8])),
                   "learning_rate": float(10 ** rng.uniform(-2, -0.7))} if name == "xgboost" else
                  {"n_estimators": int(rng.choice([200, 500, 800])), "max_depth": rng.choice([None, 10, 20]),
                   "min_samples_leaf": int(rng.choice([1, 2, 5]))})
            r = run_model(name, prep.train, prep.val, prep.val, prep.feature_names, model_cfg, train_cfg,
                          seed=seed, tree_params=tp)
            cand = ({}, tp)
        else:
            lo, hi = bt.get("lr_range", [1e-4, 3e-3])
            tc = {**train_cfg, "lr": float(10 ** rng.uniform(np.log10(lo), np.log10(hi))),
                  "batch_size": int(rng.choice(bt.get("batch_sizes", [32, 64, 128]))), "verbose": False}
            r = run_model(name, prep.train, prep.val, prep.val, prep.feature_names, model_cfg, tc, seed=seed)
            cand = (tc, {})
        if r["report"]["val_logloss"] < best_loss:
            best_loss, best = r["report"]["val_logloss"], cand
        log.info("[tune %s] trial %d/%d val_logloss %.4f", name, t + 1, n, r["report"]["val_logloss"])
    return best


def cross_validate(name: str, prep, model_cfg, train_cfg, cfg, relevance=None, seed=0) -> pd.DataFrame:
    """Stratified, patient-grouped K-fold within the development (train) partition.

    Each fold: ADASYN on the K-1 training folds only; early stopping on the fixed 15 %
    validation partition; metrics on the held-out fold."""
    dev = prep.train_raw
    folds = grouped_cv_folds(dev.y, dev.patient_id, cfg["data"]["cv_folds"], seed)
    rows = []
    bal = cfg.get("balance", {})
    for k, (tr_idx, te_idx) in enumerate(folds):
        tr = dev.subset(tr_idx)
        if bal.get("method", "adasyn") == "adasyn":
            tr = adasyn_sequences(tr, bal.get("k", 5), bal.get("target", "max"), bal.get("majority_undersample", False), seed + k)
        r = run_model(name, tr, prep.val, dev.subset(te_idx), prep.feature_names, model_cfg, train_cfg,
                      relevance, seed + k)
        row = {"fold": k + 1, **{f"bin_{kk}": v for kk, v in to_row(name, r["report"], "binary").items() if kk != "model"},
               **{f"stage_{kk}": v for kk, v in to_row(name, r["report"], "staging").items() if kk != "model"}}
        rows.append(row)
        log.info("[cv %s] fold %d  acc %.4f  stage_acc %.4f", name, k + 1, row["bin_accuracy"], row["stage_accuracy"])
    df = pd.DataFrame(rows)
    return df, summarize_folds(rows)


def save_model(model, path: Path):
    if isinstance(model, torch.nn.Module):
        torch.save(model.state_dict(), path)
    else:
        import joblib
        joblib.dump(model, path.with_suffix(".joblib"))
